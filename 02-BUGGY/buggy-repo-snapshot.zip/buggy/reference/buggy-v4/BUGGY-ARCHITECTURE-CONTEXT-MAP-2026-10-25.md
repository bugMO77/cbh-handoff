# Buggy — Architecture Context Map & Source Reconciliation

**Prepared:** 2026-10-25  
**Purpose:** Re-establish the actual architecture and document state before more Phase 1 work.  
**Disposition:** Management/review artifact only. This report does not edit or supersede any locked contract, close a GAP, authorize a lock, claim repository transfer, or claim runtime verification.

---

## 1. Executive summary

Buggy's controlling principle is **AI proposes → Runtime proves → Human decides**. It is a human-in-the-loop bug-bounty research workspace for web applications and HTTP APIs, not an unbounded autonomous hacking system.

The currently authoritative structural baseline is `BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md`, locked for the intended tree, capability catalog, ownership boundaries, build phases, and repository workflow. That lock does **not** imply the repository exists, files have been transferred, runtime enforcement works, tests passed, or technical GAPs are closed.

The current stopping point is `architecture/agent-architecture-rules.md` **v1.3, Status: review, NOT LOCKED**. The previous `production v1.2` is the last production baseline. v1.3 repaired the core-workflow skill list and stale Blueprint citations, but preserved GAP-01 through GAP-11. The erroneous v1.3 lock claim was withdrawn by a reconciliation record. The current candidate’s SHA-256 is `c62c87c12f5f1fe47e54e0f7e0237564928b99e2780c56f9a24175824bdb103d`; the invalidated historical lock record lists a different hash (`ee0e9d086216d6180fbeeeb60e644e0e4e7aacf1162c05131ba8a0fe0a40b735`). The old lock record must not be treated as an effective lock.

The next task is **not** `validation-model.md`. First, reconcile GAP-01 through GAP-11 against the latest applicable contracts. Some items overlap GAPs in `knowledge-flow`, `learning-flow`, `validation-model`, `agent-security`, `runtime/tool-manifest`, and `runtime/redaction`. The correct answer may be a source-backed closure, a narrower unresolved remainder, or an explicit owner decision. It must not be a status-only change.

---

## 2. Source authority and lineage

### 2.1 Authority order to apply now

1. **Explicit project-owner decisions** control approvals, artifact-specific locks, freezes/reopenings, and choices that sources do not settle. A decision applies only to the named artifact/version and scope.
2. **`BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md` — LOCKED** is the current structural/catalog/build-order baseline. It replaces the older v3/v3.1 tree as the forward-looking project map. Changes to its structural or normative scope require an owner-approved successor version.
3. **`architecture/file-contracts.md` v1.4 — LOCKED** is the root file ownership/lifecycle/source-of-truth contract. Its current workspace copy matches the lock-record SHA-256 `2d914bca33f21a30568180efe2dd5656d3199611473efe0a57bba7ff3f9ea65d`.
4. **Architecture contracts** define component semantics and boundaries within their own scope. Their own exact version, review status, and lock evidence must be checked individually; the fact that a candidate exists or was independently reviewed does not make it locked.
5. **Runtime contracts** define operational policy and inventory, but a locked policy is not proof of runtime enforcement. Runtime implementation, tests, and integration evidence are separate.
6. **Templates, skills, commands, agents, target state, and run artifacts** implement/use the upstream contracts. They may not silently redefine them.
7. **Rules Producer / Architecture Builder prompts, roadmap, handoffs, reports, and ZIP manifests** are process/management aids. They are not higher authority than the locked Blueprint or a governing contract.

### 2.2 How to interpret the older uploaded documents

| Artifact supplied | Correct role today | Treatment |
|---|---|---|
| `BUGGY — MASTER BLUEPRINT` (48-section conceptual document inside `نص ملصق(20261025-061545).txt`) | Historical high-level architecture source. It establishes the core philosophy and conceptual subsystem boundaries. | Preserve its principles when consistent with current contracts; do not let its old skill list/path/order override Blueprint v4.0. |
| `BUGGY RULES PRODUCER` prompt (`نص ملصق (2)(9).txt`) | Source-analysis process: extract rules, mark explicit claim vs synthesis vs self-reported claim, classify NEW/CONFIRMS/REFINES/CONFLICT, and preserve provenance. | A source is not an approved rule just because the Producer suggests it. Conflicts and synthesis require review. |
| `BUGGY ARCHITECTURE BUILDER` prompt (`نص ملصق (3)(3).txt`) | Contract-authoring process: inspect upstream sources, identify conflicts, author one bounded file, verify, and report. | Its “do not invent / do not edit unrelated files / preserve locked baselines” discipline remains useful. Its generic repo-builder language is subordinate to the later v4 workflow and single-writer boundary. |
| `AI Bug Hunting System — Architecture v1` (`نص ملصق (4)(1).txt`) | Early synthesis of the sources: target workspace, knowledge/context, orchestrator, skills, runtime, observations, hypotheses, validator, findings, memory/learning. | Helpful conceptual history, not the canonical contract. Its old `ai-hunt/` tree and XSS-first MVP sequence do not override v4.0. |
| `BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md` | Current canonical intended tree, skill/command catalog, ownership, build order, repository/package discipline. | Locked. Implementation and GAP closure are explicitly outside the lock. |
| `BUGGY-BUILD-ROADMAP-v4.0.md` | Ordered intake and phase-exit workflow. | Current management aid, but its Phase 1 list references older versions in places; use the newer verified artifact records and this handoff to identify current versions. Do not silently rewrite its history. |
| `BUGGY-PHASE1-HANDOFF-2026-10-25.md` | Current Phase 1 continuity note. | Use as the immediate work pointer: resolve the 11 GAPs before advancing. |

### 2.3 A real internal ambiguity in the old Builder prompt

The old Builder prompt’s authority section says `Master Blueprint → Approved Architecture Rules → Existing Contracts`, but its final pipeline says `Sources → Rules Producer → Human Review → Approved Rules → Master Blueprint → Architecture Builder`. These are not the same ordering if read literally. The safe current interpretation is: source-derived rules remain proposals until reviewed; they cannot silently override the locked v4.0 Blueprint. Any structural/normative Blueprint change requires an explicit owner-approved successor. Current Phase 1 is contract reconciliation, not an invitation to reintegrate every older source prompt.

---

## 3. The architecture we are actually following

### 3.1 Design invariants

- **AI output is a hypothesis, not proof.** Security claims require reproducible runtime evidence and human judgment.
- **Runtime proves runtime claims.** Requests/responses, browser behavior, authorization differences, state transitions, callbacks, and reproducible results can support proof. LLM confidence cannot.
- **Human remains final authority** over scope, security-boundary interpretation, sufficient evidence, impact, reportability, and project architecture choices.
- **Few agents, many skills.** Agent is an isolated execution responsibility; skill is methodology; command is workflow entry point; Coordinator is an orchestration role; Solver is bounded/ephemeral; Detector is a narrow runtime/deterministic capability; Validator challenges the initial hypothesis independently where practical.
- **Function-centric testing.** Test security-relevant functions and trust boundaries, not just endpoint lists.
- **External durable state over giant context.** Keep target state, external source knowledge, concepts, hunting memory, reusable methodology, and execution artifacts distinct.
- **Deterministic-first.** Prefer repeatable tools/scripts for reliable mechanical checks; use models for hypothesis generation, interpretation, synthesis, prioritization, and other work that benefits from reasoning.
- **Explicit scope and least privilege.** Unknown scope means no active testing. Destructive/high-volume/persistent/third-party-impacting actions need explicit authorization and a bounded test plan.
- **No autonomous forever-hunting, blind payload blasting, agent swarm, model-output-as-confirmation, silent scope expansion, duplicated source of truth, or destruction of historical evidence.**
- **Completion is state/evidence-based.** “Done” in natural language does not establish that a deliverable, test, transfer, commit, or runtime behavior exists.

### 3.2 The functional loop

`Research → Scope verification → Identity setup → Surface discovery → Function mapping → Hypothesis generation → Targeted testing → Runtime validation → Evidence collection → Triage → Reporting → Regression → Learning`.

Knowledge answers “what is known from external material”; concepts capture synthesized/generalized understanding; memory records what the hunter/Buggy learned from real hunts; skills prescribe how methodology is executed; target state preserves the state of one program/target. These categories must not be collapsed into a single knowledge folder or one giant context.

### 3.3 Runtime and initial focus

The v4.0 direction is OpenCode, Burp Suite/Burp MCP, Playwright/Chromium where browser behavior matters, OOB tooling such as `interactsh` when scope/policy permits, and security CLI tools. Caido is not required by the core architecture. Current core target model is web applications and HTTP APIs (including REST, GraphQL, and authenticated multi-account SaaS); mobile is outside the current core target model.

The **11 core workflow skills** are `scope-bootstrap`, `program-research`, `recon`, `api-discovery`, `js-discovery`, `js-analyze`, `identities`, `session-search`, `validator`, `report-writer`, and `regression`. The initial vulnerability-skill MVP is separately `access-control` and `xss`. The canonical command set contains 13 commands: `hunt`, `recon`, `monitor`, `update`, `validate`, `report`, `research`, `understand`, `compare-runs`, `mindmap`, `scope-check`, `triage`, and `pickup`.

The early Master Blueprint mixed Access Control/XSS into the core workflow list and omitted API Discovery. The v1.3 bounded correction fixed that. The older Architecture v1 proposal suggested an XSS-first sequence; v4.0’s planned MVP/build order lists Access Control before XSS. Use v4.0 for the canonical catalog and order.

---

## 4. Working roles and repository boundary

| Role | Responsibility | Must not do |
|---|---|---|
| Project owner | Final decisions, explicit approvals, lock/freeze/reopen decisions, scope authority. | Have project decisions inferred from silence or a reviewer verdict. |
| ChatGPT architect/reviewer and phase-file keeper | Read exact sources, reconcile dependencies, draft bounded tasks, review full candidate content, save accepted phase artifacts and management records. | Claim repository writes, tests, commits, pushes, or runtime proof that did not happen; close an owner-controlled GAP by itself. |
| DeepSeek in ChatGPT (document author) | Return the full Markdown candidate and a concise change report for one bounded task. | Lock/approve, invent missing architecture, edit unrelated files, claim repository work. |
| OpenCode/DeepSeek in OpenCode (repository-side builder) | After an approved release package and bounded owner-authorized task, inspect the actual checkout, verify manifest/hash/path, transfer approved repository files, implement, test, and perform authorized Git operations. | Assume a remote/branch, overwrite the old repo, bypass package checks, edit approved source silently, or treat preflight as proof of actual dispatch. |

A new repository is intended. Use an isolated checkout such as `~/buggy-v4`; do not assume `bugMO77/buggy` is the new target. Repository owner/slug/visibility/default branch must be confirmed by the owner. Management prompts, roadmap, and handoff remain outside the source tree unless a release manifest explicitly marks a file `REPOSITORY`. No repository transfer is evidenced by the documents reviewed here.

---

## 5. Verified artifact state snapshot

The states below separate lifecycle `Status`, owner lock, work progress, repository transfer, tests, and runtime readiness.

| Artifact | State evidenced by current files | What it means / does not mean |
|---|---|---|
| `BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md` | **LOCKED** by owner request on 2026-10-15 | Locks tree/catalog/ownership/build order only. Does not close GAPs or imply implementation. |
| `architecture/file-contracts.md` v1.4 | **LOCKED**; current workspace copy SHA matches its adjacent lock record | Root file ownership/lifecycle contract. Not transferred or runtime-tested by the lock. Do not edit in place; any normative repair needs an authorized successor. |
| `architecture/agent-architecture-rules.md` v1.2 | Prior `production` baseline | Preserved historical/production baseline. |
| `architecture/agent-architecture-rules.md` v1.3 | **Status: review; NOT LOCKED**; current SHA `c62c87c12f5f1fe47e54e0f7e0237564928b99e2780c56f9a24175824bdb103d` | Current review candidate. Eleven GAPs remain. The older lock claim is invalidated by the reconciliation record; do not cite it as effective. |
| `architecture/review-discipline.md` v0.2 | **LOCKED** by explicit owner decision; lifecycle `Status: review` | Current process-governance baseline. Reviewer verdict is recommendation; only owner can approve/lock/freeze/reopen; GAP closure needs evidence and the proper authority. No repository transfer or runtime verification. |
| `architecture/validation-model.md` v1.1 | `Status: review`; GAP-VM-01 through GAP-VM-10 are listed | Candidate, not evidenced as locked. Exact FP/Evidence lists, Proof Gate wiring, coverage schema, Validator identity, and other items remain open. |
| `architecture/knowledge-flow.md` v1.1 | `Status: review`; GAP-KF-01 through GAP-KF-10 are listed | Candidate, not evidenced as locked. Includes a separate Program Knowledge Pack schema GAP-KF-03. |
| `architecture/learning-flow.md` v1.1 | `Status: review`; GAP-LF-01 through GAP-LF-10 are listed | Candidate, not evidenced as locked. Includes False Positive DB schema GAP-LF-01 and related memory/learning rules. |
| `architecture/agent-security.md` | Available copies include `review v1.0` and `review v1.1` candidate rounds 1–3 | **Authoritative current version is unresolved** in the available source set; v1.1 round 3 is still a candidate, and no corresponding explicit v1.1 lock record was found in this source inventory. The roadmap itself flags the version discrepancy. |
| `architecture/model-routing.md` v0.1 | Lock decision recorded; lifecycle `Status: draft` | Architecture-level philosophy/constraints only. The old reference to Blueprint v3 is a historical citation and is not permission to edit the locked file in place. |
| `runtime/tool-manifest.md` v1.5 | **LOCKED policy baseline**; runtime implementation incomplete; many GAP-TM entries remain OPEN | Its policy explicitly refuses tool invocations while GAP-TM-11 is OPEN. A lock here is a document/policy lock, not proof the runtime enforces it. Its `Status: LOCKED` header predates the v1.4 lifecycle-vs-lock clarification and should be treated as a metadata consistency issue for a future authorized successor, not edited in place. |
| `runtime/registry.json` v0.7-rev2 | **LOCKED / production**; SHA `460fbd1db1e569a6814a5ee90676887792b4ea29ebc2d9b39ac985644cc1771b` matches the lock record | Inventory is explicitly partial; the schema file does not exist, so schema validation was not performed. Registry lock does not close GAP-TM-11 or establish a safe invocation path. |
| `runtime/redaction.md` v1.2 | **LOCKED policy baseline**, lifecycle `Status: review`; SHA `f9b3ca2c564de8828c7e2b4ffb15ad2f3a636e151556ffdaaa1dc405a809aff1` matches the lock record | Defines redaction, constrained restoration, fail-closed rules and MCP response quarantine/release. No implementation/testing is claimed. Its lock record explicitly preserves GAP-AS-02 and GAP-AS-08 as OPEN. |
| `runtime/provider-failure-policy.md` v0.1 | **LOCKED policy** by explicit owner authorization; lifecycle `Status: draft` | Supporting policy for provider error classification/retry/escalation, not a routing authority or implementation. Owner-decision/numeric limits and tests remain proposed/unexecuted as recorded. |
| `runtime/model-routing.md` | v0.2 draft, v0.3 proposed lock record awaiting review/owner lock, and v0.5 review candidate exist | Do not treat v0.3 as locked: its own record says the lock is proposed/pending. v0.5 is a candidate, not an implemented routing engine. `GAP-VM-09` remains open and Validator assignment is deliberately unresolved. |

**Runtime safety consequence:** the locked tool manifest states that while `GAP-TM-11` remains OPEN, eligible-looking invocations are refused with `integrity_unverifiable`; a hash algorithm alone is not a trusted reference or proof that the executed definition matches the reviewed definition. This review did not test a real invocation path.

---

## 6. GAP-01 through GAP-11 — source-backed triage matrix

This is a reconciliation map, **not a closure record**. None of these rows is marked closed here. IDs and history must be preserved. Some legacy GAPs bundle several concerns that are now owned by separate contracts; the final repair should split resolved invariants from genuinely unresolved technical/policy work without erasing their history.

| ID | Original concern | Canonical owner / overlap found | Current source-backed finding | Required next step before closure |
|---|---|---|---|---|
| GAP-01 | Micro-agent execution contract: bounded input/task/tools/response/output and isolation | `architecture/agent-architecture-rules.md`; runtime behavior belongs in `runtime/opencode/ORCHESTRATION.md`/loader when authored | Master Blueprint establishes bounded Solver work and summarized results, but not the exact invocation payload/output schema. Runtime orchestration contracts are not yet evidenced as implemented. | Define the minimum architecture invariant separately from runtime wire format; identify exact output fields, allowed context/tools, isolation and failure behavior from source or present a bounded owner decision. Do not claim a runtime implementation exists. |
| GAP-02 | Program Knowledge Pack schema | `architecture/knowledge-flow.md` GAP-KF-03; possibly a Research Mode contract if approved | Knowledge flow explicitly confirms the same schema gap: fields, lifecycle, indexing and provenance are not specified. | Consolidate the overlap with GAP-KF-03; decide canonical file ownership and schema fields/lifecycle/provenance. Do not create both a duplicate GAP definition and an independent conflicting schema. |
| GAP-03 | False Positive DB schema/query/retention/provenance | `architecture/learning-flow.md` GAP-LF-01; related validation behavior in `validation-model.md` | Learning flow explicitly preserves this as OPEN. Validation model distinguishes FP Gate questions from the database schema. They are related but not identical. | Separate database schema/query/lifecycle from the literal FP validation questions. Define fields, provenance, query patterns and retention using owner-approved rules; do not conflate GAP-03 with GAP-05. |
| GAP-04 | Proof Gate implementation and runtime wiring | `architecture/validation-model.md` GAP-VM-04; later runtime/OpenCode interfaces and tests | Principle is established (`AI ≠ proof`), but the exact runtime capability/dispatch boundary and proof-gate integration are still open. Unit or preflight tests alone cannot prove dispatch enforcement. | Define what the gate accepts/returns and how state transitions are blocked; defer integration until an actual runtime interface exists, then require end-to-end refusal/allow tests before saying it is operational. |
| GAP-05 | Literal 10 False Positive Gate questions | `architecture/validation-model.md` GAP-VM-02 | Source confirms that the list itself was not supplied. A working FP taxonomy is not evidence of the final ten literal questions. | Draft a traceable, domain-appropriate proposal and identify what is source-derived versus proposed; obtain the hunter/owner’s decision where sources do not determine the list. Do not fabricate a source attribution. |
| GAP-06 | Literal 10 Evidence Standard requirements | `architecture/validation-model.md` GAP-VM-03 | The validation candidate has evidence principles, but explicitly says they are not the final ten requirements. | Produce a distinct proposal with acceptance criteria and trace each item to source or label it as a new project policy requiring approval. Keep evidence principles separate from the exact final list. |
| GAP-07 | Coverage Engine dimensions/schema/update procedure/prioritization link | `architecture/validation-model.md` GAP-VM-06; future `templates/coverage-map.md` | Dimensions are described, but the exact schema/update logic and link to prioritization are open; template is not yet authored. | Specify the record fields, update triggers, tested/untested/unknown states, evidence needed for updates, and target prioritization relationship. Then bind template and Validator/command consumers to one source of truth. |
| GAP-08 | Local redaction → cloud processing → local restoration details | `runtime/redaction.md` v1.2; `architecture/agent-security.md` GAP-AS-02/GAP-AS-08; `runtime/tool-manifest.md` GAP-TM-17 | A later locked **policy document** now defines redaction, constrained restoration, fail-closed behavior and response quarantine/release. However, its lock record explicitly says GAP-AS-02 and GAP-AS-08 remain OPEN, runtime implementation is not claimed, and the tool manifest still has integrity/redaction-related gaps. Therefore the legacy GAP is at least stale/overbroad, but not safely closable as written yet. | Compare each clause of GAP-08 with v1.2 policy and the authoritative security source; separate “policy/protocol specified” from “runtime implemented” and “inventory/coverage gaps.” Preserve GAP-08 history, and close only the part whose acceptance rule is actually satisfied by source evidence. |
| GAP-09 | Model-selection philosophy vs operational model IDs/fallbacks | Locked `architecture/model-routing.md` v0.1; candidate `runtime/model-routing.md`; `validation-model.md` GAP-VM-09; provider-failure policy | The architecture/operational separation is already explicitly described in the v0.1 architecture contract. However runtime routing versions v0.2/v0.5 are drafts/review candidates; the v0.3 lock record itself is only **PROPOSED**; Validator identity/fallback limits remain unresolved. | Reconcile the old broad GAP with what is already normatively settled. Preserve the split, record remaining runtime mapping/approval/fallback decisions precisely, and do not close GAP-VM-09 just because routing tables exist. |
| GAP-10 | MCP trust boundaries, observability/logging and privacy beyond redaction | `architecture/agent-security.md` GAP-AS-03/GAP-AS-07; `runtime/tool-manifest.md` GAP-TM-05 and other tool GAPs; redaction contract | Cross-cutting principles exist, but the concrete MCP trust-list registration/persistence/audit/revocation mechanism and observability record/retention/UI are still named as gaps in specialized contracts. They cannot be closed by generic cross-reference wording. | Build a sub-gap map of owner, source, persistence model, approval/revocation, log fields, sensitive-field redaction and retention. Resolve trust-list and logging policy at their canonical homes before updating GAP-10. |
| GAP-11 | Frontmatter schema stability and possible extra references | `architecture/agent-architecture-rules.md` §10; `file-contracts.md` per-type rules; templates/skills not yet built | Minimal Agent/Skill/Command formats are described, but the question of stable required fields vs optional forward-compatible fields remains open. Downstream production usage is not yet available as evidence. | Establish the minimum required fields, optional reference fields, schema-versioning/backward-compatibility rule, and who may revise them. Resolve before Phase 7 creates the 11 core skills and before command/agent consumers proliferate. |

### Important meaning of this table

- “The topic exists in another file” does **not** automatically close the GAP.
- Conversely, a GAP that predates a later contract may no longer accurately describe the remaining missing work. Reconcile it against the later contract and its lock record before preserving “OPEN” without qualification.
- Do not close any GAP by deletion, ID renaming, status relabeling, or writing “deferred.” A defensible closure needs the exact resolution, canonical destination, acceptance evidence, and explicit decision where required.
- GAP-01..GAP-11 are a different namespace from GAP-AS, GAP-KF, GAP-LF, GAP-TM, and GAP-VM. Preserve all IDs independently and record dependency relationships instead of merging identifiers.

---

## 7. Cross-file discrepancies and traps to avoid

1. **Roadmap version drift.** Phase 1 intake still lists `file-contracts.md` v1.3 and `agent-architecture-rules.md` v1.2, while the live management source set has locked v1.4 and v1.3 as the current review candidate. This should be reflected in a later roadmap/current-state update; do not falsify the old roadmap or assume it is the current artifact list.
2. **Invalid v1.3 lock history.** The old `agent-architecture-rules-v1.3-lock-record.md` claims LOCKED while listing GAP-01..GAP-11 as OPEN. The adjacent reconciliation expressly invalidates it. Current v1.3 is NOT LOCKED; do not send the old lock record as proof of approval.
3. **`agent-security.md` source identity.** `agent-security-final.md` and `agent-security.md` both show review v1.0, while several v1.1 candidate/review rounds exist. The roadmap explicitly asks for the intended authoritative copy and lock evidence. Resolve this source/version identity before claiming the security contract is locked or treating its GAP status as current.
4. **Policy lock is not implementation.** This applies to redaction, provider failures, tool manifest, registry and routing. Each lock record explicitly separates document/policy approval from repository transfer, tests and runtime readiness.
5. **Runtime model-routing v0.3 is not locked by its current record.** The file `model-routing-lock-record-v0.3.md` identifies itself as PROPOSED and says owner lock is pending. The later v0.5 is a review candidate. Do not infer that operational model routing is locked from the file name or ZIP.
6. **The tool-manifest's fail-closed posture matters.** `runtime/tool-manifest.md` v1.5 says that while GAP-TM-11 remains OPEN, invocations must be refused. It does not grant permission to operate based on a matching hash alone.
7. **Status values are separate.** Work progress uses `TODO`, `IN_PROGRESS`, `DONE`; lifecycle `Status`, owner lock, repository transfer, tests, and runtime readiness are different facts. The file-contracts v1.4 lock and `review-discipline` v0.2 spell this out.
8. **Do not confuse the three ledgers or state layers.** `templates/ledger.md`, per-target `testing/<root-domain>/ledger.md`, and `memory/CONTEXT_LEDGER.md` have separate owners and purposes. Target state, external knowledge, generalized concepts and learned memory are not interchangeable.
9. **Do not create future subsystems just to make the tree look complete.** Retrieval, learning engine, automation and broad script subsystem have phase boundaries. A zero-byte placeholder may be intentional; an empty folder is not evidence of broken transfer.
10. **The old Architecture v1 is not the work order.** Its XSS-first sequence and `ai-hunt/` example are historical synthesis. v4.0’s `buggy-v4/` structure and phase order govern the current build.

---

## 8. Current work state and next action

**Current phase:** Phase 1 architecture source reconciliation, in progress.  
**Current artifact under review:** `architecture/agent-architecture-rules.md` v1.3.  
**Current decision:** NOT LOCKED.  
**Do not move to:** `architecture/validation-model.md` yet.  
**Repository transfer/tests:** none claimed by this audit.

Recommended bounded next sequence:

1. Use the GAP matrix above to assemble the source-exact evidence packet for each of the 11 GAPs: exact definition, source date/version, owner, downstream effects, current later evidence, and closure criteria.
2. Resolve the portions settled by authoritative sources directly, without asking the owner to restate a decision that is already recorded.
3. For requirements not determined by source, present one bounded decision at a time with alternatives/trade-offs and label the proposal as project policy rather than source fact. Do not fabricate the “ten FP questions,” “ten Evidence requirements,” a schema, an implementation, or a runtime test result.
4. Update only the proper candidate/owner contract and its change report once the decision is settled. Do not edit locked baselines in place. Keep original GAP IDs/history and a separate closure-evidence entry.
5. Re-review the resulting candidate against Blueprint v4.0, file-contracts v1.4, review-discipline v0.2, and each cited owner contract. Only after applicable gaps are genuinely resolved should the owner decide whether to say `LOCKED` for that exact version.
6. Then proceed to the next architecture contract in dependency order, not before.

This report is an architecture-context map and source reconciliation aid. It is not a lock record, project-wide GAP register, release package, implementation artifact, or replacement for the authoritative source contracts.
