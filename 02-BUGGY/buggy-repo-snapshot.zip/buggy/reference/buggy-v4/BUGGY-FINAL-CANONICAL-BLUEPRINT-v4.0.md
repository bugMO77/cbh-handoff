# Buggy — Final Canonical Blueprint v4.0

> **Document type:** Canonical project structure, capability catalog, and dependency-aware build contract  
> **Version:** v4.0  
> **Decision:** **LOCKED** by explicit project-owner request in this conversation on 2026-10-15  
> **Scope of lock:** Project tree, intended capability catalog, file ownership boundaries, build phases, and repository workflow  
> **Implementation status:** Not implied by this lock. This document does not claim that files have been created, transferred, committed, tested, or made runtime-operational.  
> **Repository target:** A new repository is intended; its exact GitHub slug/URL must be confirmed by the owner during repository initialization. Do not assume the old `bugMO77/buggy` repository is the destination.

## 0. Purpose and effect of this lock

This is the canonical structural baseline for Buggy v4.0. It replaces the supplied v3 tree as the forward-looking project map and consolidates the previously prepared v3.1 working draft with the owner's file/GAP inventory and the additional security-domain catalog specified here.

The lock means the **planned shape and build discipline are settled**. It does not lock the contents of future files, resolve technical GAPs by declaration, authorize edits to separately locked contracts, or certify a working runtime. Existing documents remain governed by their own version and approval records.

A change to this Blueprint requires an explicit owner-authorized successor version. Small implementation choices that fit the existing tree do not require reopening this Blueprint. A genuine new capability, removed canonical path, ownership change, or phase-order change does.

### 0.1 What changed from v3/v3.1

- Preserves the existing Buggy v3 architecture and file paths unless explicitly consolidated below.
- Adds a canonical `governance/` area to track build state, GAPs, and owner decisions in one place instead of scattering project state across prompts.
- Adds `api-discovery` as a core workflow skill because Buggy explicitly targets web applications and HTTP APIs.
- Adds a full planned vulnerability-skill catalog while preserving **Access Control and XSS as the initial vulnerability-skill MVP**.
- Expands `concepts/vulnerability-classes/` into a defined catalog spanning web and HTTP API vulnerability families, including attack patterns observed during prior work in generalized, target-independent form.
- Makes file ownership, source-of-truth rules, progress states, package integrity, and the OpenCode repository boundary explicit.
- Defines a new-repository workflow that avoids overwriting the existing repository or assuming the destination remote.

## 1. Project invariants

- **Project:** Buggy, an AI-assisted, human-in-the-loop bug bounty workspace for web applications and HTTP APIs.
- **Operating principle:** `AI proposes → Runtime proves → Human decides.`
- **Initial MVP vulnerability focus:** Access Control / IDOR / BOLA / Broken Access Control (BAC) and XSS.
- **Research Mode:** Core workflow, from program intelligence and application understanding to concrete, testable hypotheses.
- **Human review:** Required for security-sensitive design decisions, scope changes, acceptance of findings, and explicit document locks where specified.
- **Evidence:** LLM confidence is not runtime proof. A suspected finding cannot be reported as confirmed without appropriate reproducible evidence.
- **Primary proxy:** Burp Suite and Burp MCP, according to the approved runtime/tool policy.
- **Browser:** Playwright/Chromium where browser behavior is required.
- **Out-of-band testing:** `interactsh` when allowed by scope and the approved runtime/tool policy.
- **Agent philosophy:** Few agents, many skills. Do not make one agent per vulnerability. Use an isolated/ephemeral solver only when isolation has a defensible purpose.
- **Scope:** Every target action must be bound to an explicit, owner-reviewed scope. Unknown scope means do not perform active testing.
- **Non-destructive default:** No destructive, high-volume, persistence, or third-party-impacting action without explicit authorization and a bounded test plan.
- **No autonomous forever-hunting:** Automation may monitor, snapshot, compare, and notify; it does not run an unbounded autonomous attack loop.
- **Three ledgers remain distinct:** `templates/ledger.md`, `testing/<root-domain>/ledger.md`, and `memory/CONTEXT_LEDGER.md` are different artifacts with different owners and purposes.
- **External knowledge types:** writeups, reports, blogs, tips-tricks, research, docs, and processed extractions. `posts`, `podcasts`, and `videos` are not canonical source directories unless the owner separately authorizes a change.
- **Empty content folders and zero-byte skeleton placeholders can be intentional.** Their emptiness alone is never evidence of a broken transfer and is not permission to recreate or delete them.
- **No hidden design decisions:** If a file depends on a missing source or unresolved decision, record the exact blocker and defer the affected portion. Do not invent a rule to make the file appear complete.

## 2. Progress vocabulary and artifact states

### 2.1 Project work progress

Only the following three values are allowed in the project progress register:

| Value | Meaning |
|---|---|
| `TODO` | The current bounded task has not started. The artifact may already exist. |
| `IN_PROGRESS` | Review, repair, authoring, transfer, or verification has started but its defined exit checks are not complete. If waiting on a dependency, name it in the note; do not add another progress state. |
| `DONE` | The artifact or task has passed the completion checks defined for its current scope. |

Do not use `BLOCKED`, `LOCKED`, `DRAFT`, `REVIEW`, or `PRODUCTION` as project work-progress values.

### 2.2 Keep these different facts separate

1. **Lifecycle metadata** belongs to the artifact's governing contract.
2. **Owner lock decision** is a governance decision for a specific named artifact/version.
3. **Work progress** uses only `TODO`, `IN_PROGRESS`, `DONE`.
4. **Repository transfer** states whether the exact content was copied to the intended repository.
5. **Tests** state which checks actually ran and their results.
6. **Runtime readiness** states what was proven in an integrated execution path.

None of these facts implies another. In particular, `DONE` does not automatically mean locked, transferred, committed, tested, or operational.

### 2.3 Owner command `LOCKED`

When the owner explicitly says `LOCKED` for a named artifact and version:

- record the explicit decision in that artifact's own decision/lock section or approved adjacent lock record;
- include the exact artifact path/name, version, decision date, owner authorization, and scope of the lock;
- update the project's progress register to `DONE` only if the artifact's completion checks have also passed;
- do not put `LOCKED` in the lifecycle `Status` field unless the artifact's governing contract explicitly permits it;
- do not silently alter the locked version later. Normative changes require an explicitly authorized versioned successor.

If the target artifact/version is ambiguous, ask one concise clarification rather than applying the lock to multiple files.

## 3. Source-of-truth and ownership boundaries

| Artifact type | Canonical owner / source of truth | Boundary |
|---|---|---|
| Architecture contract | Its versioned file under `architecture/` | Normative architecture rules; do not duplicate operational routing/config values here. |
| Runtime tool policy | `runtime/tool-manifest.md` | Invocation policy, gating, approval, failure, and definition-verification policy. |
| Tool inventory | `runtime/registry.json` plus its approved schema | Tool inventory, identity, path/type, and verification metadata. |
| Runtime routing | `runtime/model-routing.md` | Operational provider/model identifiers and mappings; do not duplicate those tables in architecture routing. |
| Provider failures | `runtime/provider-failure-policy.md` | Provider error classification, retry/escalation, stop behavior, and failure event shape. |
| Redaction policy | `runtime/redaction.md` at the owner-confirmed current version | Redaction behavior and trust-boundary requirements. Frozen historical versions stay historical. |
| Invocation/runtime integration | Runtime implementation and tests under `scripts/` and documented `runtime/opencode/` interfaces | Actual enforcement and dispatch. A Markdown policy alone does not enforce runtime behavior. |
| Reusable workflow | `.opencode/skills/<skill>/SKILL.md` | Methodology, sequencing, observations, validation and evidence expectations. Not target-specific state. |
| Workflow entry point | `.opencode/commands/<command>.md` | Inputs, required skills, orchestration sequence, outputs, and completion gates. Does not duplicate detailed methodology. |
| Reusable security knowledge | `concepts/` | Synthesized, source-backed and generalized knowledge. Must not contain target secrets or unredacted target-only state. |
| External source material | `knowledge/` | Provenance-preserving source material and structured extractions. Sources remain traceable. |
| Target state | `testing/<root-domain>/` | Scope, identities, runs, artifacts, hypotheses, findings and evidence for one target. |
| Lessons from actual hunts | `memory/` | General lessons from Buggy's own experience, with provenance where applicable. Not a substitute for source knowledge or architecture decisions. |
| Project progress/GAP/owner decisions | `governance/` | Coordination index and audit trail. This layer indexes and tracks authoritative artifacts; it cannot override them. |
| Phase delivery package | A separately prepared ZIP with a package manifest | Only files explicitly marked for repository transfer may be copied into the repo. Management prompts and handoff notes are not copied unless the manifest says so. |

## 4. Canonical project tree

This tree describes the **intended complete project**. Not every file should be created in the first commit. Work follows §8 build phases. Directories that hold target data, source material, learned content, or runtime state are populated only when real inputs exist; do not fill them with artificial placeholder content merely to make the tree look complete.

```text
buggy-v4/                                  # New isolated local checkout; suggested path ~/buggy-v4
├── README.md
├── AGENTS.md
├── prioritization.md
├── opencode.json
├── package.json
│
├── governance/
│   ├── BUILD-STATE.md                     # Single next-action pointer, current phase, progress
│   ├── GAP-REGISTER.md                    # Formal GAP IDs, authoritative source, impact, dependencies, closure evidence
│   └── DECISION-LOG.md                    # Append-only owner decisions, exceptions, freeze/reopen/supersession records
│
├── .opencode/
│   ├── skills/
│   │   ├── scope-bootstrap/SKILL.md
│   │   ├── program-research/SKILL.md
│   │   ├── recon/SKILL.md
│   │   ├── api-discovery/SKILL.md
│   │   ├── js-discovery/SKILL.md
│   │   ├── js-analyze/SKILL.md
│   │   ├── identities/SKILL.md
│   │   ├── session-search/SKILL.md
│   │   ├── validator/SKILL.md
│   │   ├── report-writer/SKILL.md
│   │   ├── regression/SKILL.md
│   │   ├── access-control/SKILL.md
│   │   ├── xss/SKILL.md
│   │   ├── auth-session/SKILL.md
│   │   ├── oauth-identity/SKILL.md
│   │   ├── business-logic/SKILL.md
│   │   ├── api-security/SKILL.md
│   │   ├── graphql-security/SKILL.md
│   │   ├── injection/SKILL.md
│   │   ├── ssrf-webhooks/SKILL.md
│   │   ├── file-handling/SKILL.md
│   │   ├── server-side-processing/SKILL.md
│   │   ├── csrf-cors/SKILL.md
│   │   ├── client-side-security/SKILL.md
│   │   ├── request-routing-cache/SKILL.md
│   │   ├── websocket-security/SKILL.md
│   │   ├── misconfiguration-exposure/SKILL.md
│   │   └── rate-limit-resource-control/SKILL.md
│   ├── agents/                             # Intentionally sparse; add only with a justified isolation need
│   └── commands/
│       ├── hunt.md
│       ├── recon.md
│       ├── monitor.md
│       ├── update.md
│       ├── validate.md
│       ├── report.md
│       ├── research.md
│       ├── understand.md
│       ├── compare-runs.md
│       ├── mindmap.md
│       ├── scope-check.md
│       ├── triage.md
│       └── pickup.md
│
├── automation/
│   ├── README.md
│   ├── monitor.sh
│   ├── snapshot.py
│   ├── diff.py
│   ├── notify.py
│   └── state/<root-domain>/
│       ├── subdomains-prev.json
│       └── urls-prev.json
│
├── knowledge/
│   ├── writeups/
│   ├── reports/
│   ├── blogs/
│   ├── tips-tricks/
│   ├── research/
│   ├── docs/
│   └── processed/
│
├── concepts/
│   ├── methodology/
│   ├── heuristics/
│   ├── attack-patterns/
│   ├── false-positives/
│   ├── prioritization/
│   └── vulnerability-classes/
│       ├── access-control/
│       ├── authentication-session/
│       ├── oauth-oidc-saml/
│       ├── business-logic-entitlements/
│       ├── race-conditions/
│       ├── api-security/
│       ├── graphql/
│       ├── xss/
│       ├── injection/
│       ├── ssrf/
│       ├── webhook-integrations/
│       ├── file-upload-processing/
│       ├── path-traversal-file-access/
│       ├── ssti-template-injection/
│       ├── xxe-deserialization/
│       ├── csrf/
│       ├── cors/
│       ├── clickjacking-ui-redress/
│       ├── open-redirect-host-header/
│       ├── request-smuggling-http-desync/
│       ├── cache-poisoning-deception/
│       ├── prototype-pollution-dom/
│       ├── websocket-security/
│       ├── information-disclosure-secrets/
│       ├── security-misconfiguration/
│       ├── rate-limits-resource-exhaustion/
│       ├── multitenant-isolation/
│       └── identity-normalization/
│
├── memory/
│   ├── FALSE_POSITIVE_DB.md
│   ├── patterns.md
│   ├── methodology.md
│   ├── report-lessons.md
│   ├── CONTEXT_LEDGER.md
│   └── lessons/
│
├── learning_engine/
│   ├── engine.py
│   ├── core/
│   │   ├── config.py
│   │   ├── schema.py
│   │   ├── validation.py
│   │   └── storage.py
│   ├── ingestion/
│   │   ├── finding.py
│   │   └── triage.py
│   ├── analytics/patterns.py
│   ├── run_comparison/
│   │   ├── compare.py
│   │   └── miss_analysis.py
│   ├── retrieval/README.md
│   ├── research/
│   │   ├── graph/TODO.md
│   │   └── scoring/TODO.md
│   ├── scripts/audit_learning_engine.py
│   └── memory/learning.db              # Generated runtime database; never commit real target secrets/data
│
├── retrieval/
│   ├── search/
│   ├── metadata/
│   └── index/
│
├── runtime/
│   ├── registry.json
│   ├── registry.schema.json
│   ├── tool-manifest.md
│   ├── redaction.md
│   ├── provider-failure-policy.md
│   ├── model-routing.md
│   └── opencode/
│       ├── loader.md
│       ├── ORCHESTRATION.md
│       └── manifest.md
│
├── scripts/
│   ├── update.sh
│   ├── runtime_preflight.py
│   ├── skill_registry.py
│   ├── fetch/
│   ├── process/
│   ├── index/
│   ├── learn/
│   ├── test_skill_registry.py
│   └── test_runtime_contract.py
│
├── templates/
│   ├── ledger.md
│   ├── target-config.md
│   ├── notes-funnel.md
│   ├── coverage-map.md
│   ├── hypothesis.md
│   ├── finding.md
│   ├── run-report.md
│   ├── validation-report.md
│   └── prompts/vulnerability-skill-template.md
│
├── testing/<root-domain>/
│   ├── scope.md
│   ├── agent-briefing.md
│   ├── target-config.md
│   ├── ledger.md
│   ├── notes-funnel.md
│   ├── coverage-map.md
│   ├── identities/
│   │   ├── anonymous.md
│   │   ├── user-a.md
│   │   ├── user-b.md
│   │   └── admin.md
│   ├── research/
│   │   ├── reports/
│   │   ├── writeups/
│   │   ├── technologies.md
│   │   ├── subdomains.md
│   │   └── business.md
│   ├── recon/
│   ├── app-map/
│   ├── endpoints/
│   ├── urls/
│   ├── subdomains/
│   ├── runs/
│   │   ├── run-<id>/
│   │   │   ├── run-report.md
│   │   │   └── coverage-snapshot.md
│   │   └── comparison.md
│   ├── oob/
│   │   ├── callbacks/
│   │   └── correlation.md
│   ├── regression/
│   │   ├── registry.md
│   │   ├── schedules.md
│   │   └── history/
│   ├── requests/
│   ├── responses/
│   ├── screenshots/
│   ├── scripts/
│   ├── scans/
│   ├── wordlists/
│   ├── hypotheses/
│   ├── evidence/
│   └── findings/<finding-id>/
│       ├── candidate.md
│       ├── validation-report.md
│       ├── finding.md
│       ├── finding.json
│       ├── poc/
│       └── regression.md
│
├── wordlists/
├── logs/
└── .github/workflows/                    # Add only when CI checks and commands are defined
```

## 5. Skill catalog and scope

All skill paths below are part of the intended catalog. Inclusion in the Blueprint does **not** mean every skill is implemented in the first release. Skills are written only after their dependencies, templates, runtime interfaces, and acceptance criteria are ready.

### 5.1 Core workflow skills

| Skill | Responsibility |
|---|---|
| `scope-bootstrap` | Explicit scope intake, scope boundaries, initial target state, and safe stopping conditions. |
| `program-research` | Program policy and public intelligence → sourced hypotheses. |
| `recon` | Authorized asset/DNS/HTTP/port/crawl/technology reconnaissance. |
| `api-discovery` | REST/GraphQL/API route inventory, schemas, versions, authentication contexts, and endpoint relationships. New canonical skill added for the Web + HTTP API target focus. |
| `js-discovery` | Discover and retrieve JavaScript assets only; no implied vulnerability conclusion. |
| `js-analyze` | Analyze sources/sinks, routes, auth logic, feature flags, and frontend workflows. |
| `identities` | Track identity/session contexts and account-to-request relationships without storing raw secrets. |
| `session-search` | Search authorized proxy/session history for relevant requests and behavior. |
| `validator` | Skeptical independent validation, evidence quality, alternative explanations, and the Validation Model gates. Depends on its design GAPs being resolved. |
| `report-writer` | Turn a validated finding into a concise, reproducible report; cannot upgrade a hypothesis to confirmed on its own. |
| `regression` | Retest known findings/fixes safely and record regressions with traceable evidence. |

### 5.2 Initial MVP vulnerability skills

1. `access-control`: IDOR, BOLA, BAC, BFLA, BOPLA, horizontal/vertical authorization, object ownership, tenant boundaries, role/membership state, invites, and cross-account verification.
2. `xss`: reflected, stored, DOM-based and context-specific XSS investigation, with browser proof and safe evidence collection.

These remain the first vulnerability skills in implementation order.

### 5.3 Planned specialist vulnerability skills

| Skill | Included workflow families |
|---|---|
| `auth-session` | Registration, login, password reset/recovery, session lifecycle, MFA/2FA, account linking, session fixation, token/session invalidation. |
| `oauth-identity` | OAuth/OIDC/SAML flow integrity, redirect/issuer/audience/state/nonce handling, account linking and identity confusion. |
| `business-logic` | Workflow/state-machine abuse, invite/member lifecycle, role changes, pricing, subscription entitlements, credits, coupon/refund/payment paths, and safe race-condition analysis. |
| `api-security` | REST/API authorization contexts, property-level exposure, mass assignment, method/content-type differences, versioning, pagination/filtering and inconsistent enforcement. |
| `graphql-security` | GraphQL schema and operation mapping, resolver authorization, field exposure, batching/depth limits and authorization consistency. |
| `injection` | SQL/NoSQL/command/LDAP/XPath and other interpreter-boundary injection families, chosen according to stack evidence. |
| `ssrf-webhooks` | Server-side fetches, URL validators, redirects, webhook callbacks, allowlist bypass classes and safe evidence-based SSRF validation. |
| `file-handling` | Upload/download authorization, content-type and parser behavior, filename/path handling, archive extraction, storage access, and safe file processing tests. |
| `server-side-processing` | SSTI, XXE, unsafe deserialization and adjacent server-side parser/processor boundaries where in-scope and supported by evidence. |
| `csrf-cors` | CSRF preconditions and impact, CORS origin/credential policy, cross-origin trust boundaries. |
| `client-side-security` | DOM clobbering, prototype pollution, unsafe client-side state/URL sinks and browser-side trust boundaries not already covered by the XSS skill. |
| `request-routing-cache` | Open redirect, Host-header trust, request parsing/desynchronization, cache poisoning/deception and intermediary discrepancies. High-risk tests require explicit bounded authorization. |
| `websocket-security` | WebSocket handshake/session binding, authorization, message-level object access, origin checks and state changes. |
| `misconfiguration-exposure` | Debug/admin surface exposure, sensitive metadata, unintended public resources, security headers and deployment/configuration mistakes. |
| `rate-limit-resource-control` | Rate-limit bypass and abuse controls, quotas and resource limits using low-impact test plans; no unbounded load. |

**Skill creation gate:** a skill is built when it provides a reusable multi-step methodology, specific environment/tool requirements, or a deterministic validation flow. A vulnerability name alone is not enough. If two skills would duplicate most of their logic, consolidate them or keep the distinction in Concepts until a separate workflow is justified. No one-agent-per-vulnerability design.

## 6. Concept catalog: all planned vulnerability classes

`concepts/vulnerability-classes/` is the reusable knowledge catalog. Each class directory uses the same seven-file schema:

```text
<class>/
├── methodology.md
├── patterns.md
├── scenarios.md
├── edge-cases.md
├── false-positives.md
├── validation.md
└── sources.md
```

The schema is mandatory when a class is populated to the full reusable-concept standard. Directories are populated from source-backed or validated material; do not generate empty seven-file sets merely to satisfy a tree.

| Canonical class directory | Coverage |
|---|---|
| `access-control/` | IDOR, BOLA, BAC, BFLA, BOPLA, ownership and role/tenant authorization. |
| `authentication-session/` | Authentication failures, session lifecycle, MFA, recovery, token/session invalidation. |
| `oauth-oidc-saml/` | Federated identity and account-linking flow flaws. |
| `business-logic-entitlements/` | Business workflow, plan/feature entitlement, pricing, subscription, credit and payment state. |
| `race-conditions/` | Concurrent state changes, double actions and workflow races, with safe bounded proof. |
| `api-security/` | API-specific access, schemas, versions, object/property exposure and mass assignment. |
| `graphql/` | Resolver authorization, field exposure, batching, introspection context and query resource controls. |
| `xss/` | Reflected, stored, DOM and context-specific cross-site scripting. |
| `injection/` | SQL, NoSQL, command, LDAP, XPath and interpreter-boundary injection families. |
| `ssrf/` | Server-side request forgery, URL parsing, resolution, redirect and egress controls. |
| `webhook-integrations/` | Webhook verification, destinations, callback handling, retries and server-side fetch boundaries. |
| `file-upload-processing/` | Upload validation, content-type/parser disagreement, storage access and processing pipeline issues. |
| `path-traversal-file-access/` | Path traversal, unintended file read/write, archive extraction and download-path authorization. |
| `ssti-template-injection/` | Server-side template injection and template evaluation boundaries. |
| `xxe-deserialization/` | XML external entities and unsafe object deserialization. |
| `csrf/` | Cross-site request forgery prerequisites, token/origin protections and impact. |
| `cors/` | Cross-origin policy errors and credentialed origin trust. |
| `clickjacking-ui-redress/` | Framing and UI-redress weaknesses. |
| `open-redirect-host-header/` | Redirect destination validation, Host-header trust and URL construction. |
| `request-smuggling-http-desync/` | HTTP parser discrepancy and request desynchronization; high-impact testing gates apply. |
| `cache-poisoning-deception/` | Cache key inconsistency, unkeyed input, deception and cache-boundary issues. |
| `prototype-pollution-dom/` | JavaScript prototype pollution, DOM clobbering and client-side object trust. |
| `websocket-security/` | WebSocket origin, session, message authorization and state-change flaws. |
| `information-disclosure-secrets/` | Sensitive data exposure, secrets/tokens in artifacts, excessive responses and metadata leakage. |
| `security-misconfiguration/` | Debug exposure, unsafe defaults, weak deployment configuration and unintended public surfaces. |
| `rate-limits-resource-exhaustion/` | Quotas, throttling, abuse resistance and bounded resource-control checks. |
| `multitenant-isolation/` | Cross-tenant data and operation isolation, tenant context binding and boundary mistakes. |
| `identity-normalization/` | Unicode, case/whitespace/canonicalization and identity-equivalence issues. |

### 6.1 Additional concept libraries

- `concepts/methodology/`: repeatable hunting workflows spanning multiple vulnerability classes.
- `concepts/heuristics/`: evidence-backed prioritization hints, not hard security facts.
- `concepts/attack-patterns/`: reusable patterns derived from multiple sources or validated experiences; retain provenance.
- `concepts/false-positives/`: recurring false-positive explanations and discriminating tests.
- `concepts/prioritization/`: attack-surface and business-context prioritization rules aligned with `prioritization.md`.

### 6.2 Generalize past lessons without copying target data

The following patterns have appeared in prior Buggy discussions and should inform reusable concepts after careful sanitization and evidence review:

- authorization bypass through membership/approval state transitions;
- invite, revoke, pending-membership and role lifecycle inconsistencies;
- Unicode/canonicalization-based identity duplication or mismatch;
- paid-plan/feature entitlement checks that differ between UI, API and backend authorization;
- webhook destination validation and redirect/SSRF boundary behavior;
- status/response manipulation that changes presentation without proving server-side authorization;
- the distinction between a preflight check and a real tool invocation path;
- hash/checksum design that fails to establish a trustworthy reference or the identity of the artifact actually executed.

Only generalized methodology and verified lessons belong in `concepts/` or `memory/`. Target-specific hostnames, account IDs, tokens, secrets, raw evidence and confidential program details stay in the relevant target workspace with appropriate redaction.

## 7. Commands, runtime and implementation boundaries

### 7.1 Canonical commands

All thirteen command entry points are included:

`hunt`, `recon`, `monitor`, `update`, `validate`, `report`, `research`, `understand`, `compare-runs`, `mindmap`, `scope-check`, `triage`, `pickup`.

Commands orchestrate existing skills and tools. They specify inputs, dependencies, ordered steps, output locations and completion conditions. They do not become giant prompt containers, duplicate full skill methodologies, or silently mutate target state outside authorized delegates.

### 7.2 Runtime files

- `runtime/registry.json`: current owner-reported baseline is v0.7-rev2. Any successor such as v0.8 is a separately reviewed artifact.
- `runtime/registry.schema.json`: canonical schema for registry validation, to be created before claiming schema validation.
- `runtime/tool-manifest.md`: current owner-reported baseline is v1.5. Any v1.6 successor requires the relevant design decisions and bounded review.
- `runtime/redaction.md`: current owner-reported baseline is v1.2. Historical frozen v1.0/v1.1 stay separate and are not casually reopened.
- `runtime/provider-failure-policy.md`: v0.1 per owner inventory; operational behavior must match the approved policy.
- `runtime/model-routing.md`: v0.5 per owner inventory; preserves operational model/provider mappings separately from `architecture/model-routing.md`.
- `runtime/opencode/loader.md`, `ORCHESTRATION.md`, and `manifest.md`: document real interfaces and orchestration only after those interfaces are defined and testable.

### 7.3 Critical runtime safeguards

- `GAP-TM-11` remains open until a real owner-approved definition-integrity design is implemented and tested. A hash algorithm alone is not a trust model.
- Do not claim real tool execution from `runtime_preflight.py` or a `NoOpBackend` alone. The actual invocation choke point and executable dispatch path must be identified and tested.
- Keep MCP trust policy, egress rules, redirect behavior, normalization, binding and provider-failure behavior aligned across policy, registry, code and tests.
- Preserve fail-closed behavior where the governing locked policy requires refusal. A document edit cannot enable tools by itself.
- Treat CLI executable identity, configuration/templates/wrappers, MCP tool definitions and OpenCode built-ins as different artifact types. The integrity design must explicitly say what is covered and what cannot be independently attested.
- The trusted reference/anchor must itself have a defensible trust path. A mutable hash file sitting beside the target is not, by itself, proof of integrity.
- Hash-before-use and execute-after-check can have a time-of-check/time-of-use gap. Design must bind verification to the executable artifact/path actually invoked or explicitly document the remaining threat boundary.
- Test expected refusal cases as well as positive paths, including tampered/unknown definitions, missing mandatory tools, disallowed scope, provider failures, redirects and authorization failures.

### 7.4 `architecture/model-routing.md` vs `runtime/model-routing.md`

- `architecture/model-routing.md` owns routing philosophy, role-level constraints, principles and exclusions. It must not be reduced to a vague “reference only” page.
- `runtime/model-routing.md` owns operational provider/model identifiers, role-to-model mappings and runtime settings.
- Do not duplicate operational route tables in the architecture file.
- Preserve `GAP-VM-09` until Validator independence and the relevant operational routing policy are explicitly resolved with adequate evidence and owner approval.

## 8. Dependency-aware build phases

Phases run in order. Some independent artifacts within a phase may proceed in parallel only when their upstream requirements are already stable. Discovery of a dependency does not automatically start a new phase.

### Phase 0 — Intake and exact source identity

- Gather the exact old documents, review reports, change reports, lock decisions, test reports and owner inventory.
- Record canonical path, exact version, current file lifecycle value, separate owner lock decision, source identity, dependent artifacts and the evidence available.
- Reconcile version/status discrepancies without silently editing locked content.
- Confirm the new remote repository slug and intended local location before initialization. Use a separate directory such as `~/buggy-v4`; do not overwrite or repurpose an existing checkout by assumption.

**Exit checks:** the sources required for the next artifact are identifiable; discrepancies that affect its meaning are explicitly listed; the next bounded task is named.

### Phase 1 — Architecture contracts, in dependency order

1. `architecture/file-contracts.md` v1.3.
2. `architecture/agent-architecture-rules.md` v1.2.
3. `architecture/validation-model.md` v1.1.
4. `architecture/knowledge-flow.md` v1.1.
5. `architecture/learning-flow.md` v1.1.
6. `architecture/agent-security.md` exact owner-authorized version.
7. `architecture/model-routing.md` v0.1.
8. `architecture/review-discipline.md` exact owner-authorized version (inventory says v0.2).

The named order is a practical dependency order, not permission to rewrite any contract. Review each exact source, identify every declared GAP and downstream dependency, and use a versioned successor when a normative change is necessary.

### Phase 2 — Runtime policies and complete GAP extraction

9. `runtime/tool-manifest.md` v1.5.
10. `runtime/registry.json` v0.7-rev2.
11. `runtime/redaction.md` v1.2 and its lock record; retain frozen v1.0/v1.1 as history.
12. `runtime/provider-failure-policy.md` v0.1.
13. `runtime/model-routing.md` v0.5.
14. Build/verify the complete `governance/GAP-REGISTER.md` from every authoritative source, not only the abbreviated owner inventory.
15. Group GAPs by shared decision, impacted files, acceptance evidence, and downstream dependencies. Preserve each original GAP ID.

### Phase 3 — Shared runtime/security design blockers

Resolve, in dependency groups, before touching dependent implementation:

1. `GAP-TM-11` — definition integrity, trust anchor, invocation choke point, CLI/MCP/built-in handling and TOCTOU boundary.
2. MCP trust-list relationship, including `GAP-AS-03` and `GAP-TM-05`.
3. Egress classification and related redirect, URL normalization, request binding and redirect-chain requirements, preserving the exact ID-to-description mapping from the sources (`GAP-TM-18`, `GAP-TM-22` through `GAP-TM-26` and related open entries).
4. Remaining security/runtime GAPs from the complete manifest/security contracts, including `GAP-AS-01`, `GAP-AS-04` through `GAP-AS-10`, and the source-recorded `GAP-TM-*` entries.
5. Validator independence/routing (`GAP-VM-09`) remains separate from tool-definition integrity; do not tie them together unless a source-backed dependency requires it.

**Important:** these are work clusters, not new GAP IDs. Do not invent closure criteria. Each design needs a documented owner decision if the underlying contract requires one.

### Phase 4 — Runtime implementation and proof

- Inspect `scripts/runtime_preflight.py` and `scripts/test_runtime_contract.py` exact contents and prior test reports.
- Define the actual invocation/dispatch boundary; implement the smallest coherent slice after Phase 3 decisions.
- Create `runtime/registry.schema.json` and validate the registry against it before claiming schema validation.
- Only then draft and review successor artifacts such as `runtime/tool-manifest.md` v1.6 and `runtime/registry.json` v0.8, if required by the approved design.
- Add tests for allowed path, refusal path, tamper/path substitution, unknown/untrusted MCP definitions, scope failures, missing required tools, provider failures, redirects, and appropriate type-specific definition checks.
- Run the tests in the intended Kali/OpenCode environment and preserve exact commands/results. No runtime readiness claim without an end-to-end path and evidence.

### Phase 5 — Validation requirements and templates

Resolve the relevant design requirements before finalizing dependent templates:

- `GAP-VM-03` before `templates/finding.md` and associated evidence requirements.
- `GAP-VM-05` before `templates/validation-report.md` and the Validator skill.
- `GAP-VM-06` before `templates/coverage-map.md`.
- `GAP-VM-04` before claiming Proof Gate implementation or wiring to runtime.
- `GAP-VM-01` and `GAP-VM-09` before treating Validator workflow/routing as final.

Template order:
1. `templates/ledger.md`
2. `templates/target-config.md`
3. `templates/notes-funnel.md`
4. `templates/hypothesis.md`
5. `templates/run-report.md`
6. `templates/finding.md` after its upstream GAP criteria.
7. `templates/validation-report.md` after its upstream GAP criteria.
8. `templates/coverage-map.md` after its upstream GAP criteria.
9. `templates/prompts/vulnerability-skill-template.md` after its schema/dependencies are reconciled.

### Phase 6 — Project steering and environment configuration

1. `README.md` — project purpose and high-level workflow only.
2. `AGENTS.md` — persistent steering, safety, scope, evidence, human-in-the-loop and non-destructive defaults.
3. `prioritization.md` — impact, likelihood, attack surface, confidence, effort and business context. Never infer severity from type alone.
4. `opencode.json` — only after actual permissions, MCP access, model routing and intended local environment are known. No secrets in the committed configuration.
5. `package.json` — only dependencies required by approved implementation, not speculative dependencies.
6. `governance/BUILD-STATE.md`, `GAP-REGISTER.md`, `DECISION-LOG.md` — initialize from evidence and maintain as the single navigation/decision index without overriding governing documents.

### Phase 7 — Core workflow skills

Build the core workflow skills in dependency order after templates/runtime interfaces are ready:

1. `scope-bootstrap`
2. `program-research`
3. `recon`
4. `api-discovery`
5. `js-discovery`
6. `js-analyze`
7. `identities`
8. `session-search`
9. `validator` only after its validation GAPs and runtime interfaces are resolved
10. `report-writer`
11. `regression`

### Phase 8 — Initial vulnerability skills and reusable concepts

- Build and validate `access-control` and `xss` first, using `templates/prompts/vulnerability-skill-template.md`.
- Build concepts for these two families first using the seven-file concept schema.
- Add the highest-value concept groups next based on the owner's real hunting experience and source evidence: business logic/entitlements, authentication/session, API/GraphQL authorization, SSRF/webhooks, file handling/path traversal, injection, OAuth/identity normalization, request/cache behavior, client-side security, CSRF/CORS, WebSocket authorization, misconfiguration/exposure, resource controls, and races.
- Specialist skill files from §5.3 are then implemented in bounded groups. The catalog is complete at Blueprint level, but no skill may be marked `DONE` without its own acceptance checks.

### Phase 9 — Commands and OpenCode orchestration

- Implement the 13 commands after the skills and callable interfaces they orchestrate exist.
- Build `runtime/opencode/loader.md`, `runtime/opencode/ORCHESTRATION.md`, and `runtime/opencode/manifest.md` after runtime interfaces and refusal/failure behavior are documented and testable.
- Add `.opencode/agents/` only for justified isolation needs.
- Keep command implementation simple; commands orchestrate skills/runtime rather than duplicating methodology.

### Phase 10 — Deferred subsystems, content and automation

Build only when the core workflow is stable and a concrete use case exists:

- `automation/` monitoring, snapshot/diff and notifications, with no autonomous indefinite active testing.
- `scripts/update.sh`, `skill_registry.py`, and the `fetch/`, `process/`, `index/`, `learn/` helpers.
- `learning_engine/` ingestion, validation, pattern analytics, run comparison and audit.
- `retrieval/` search/metadata/index.
- Populate `knowledge/`, `concepts/`, `memory/`, `wordlists/`, `logs/` and `testing/<root-domain>/` from real sources or target work.
- Add `.github/workflows/` only after the test/lint commands and CI requirements are specified.

**Phase exit rule:** each phase finishes with an inventory of intended artifacts, review evidence, actual test results where applicable, unresolved blockers, and a phase ZIP. Do not claim the whole repository is complete because a phase package exists.

## 9. Standard requirements for every skill and concept

### 9.1 Skill requirements

Every `SKILL.md` must, as relevant to its function, state:

- purpose and boundaries;
- required inputs and prerequisites;
- allowed scope and stop conditions;
- workflow steps and branching decisions;
- tools/interfaces invoked and required preconditions;
- expected observations and negative/alternative explanations;
- evidence requirements and output paths;
- safe testing constraints, rate/impact limits and cleanup requirements;
- explicit distinction among hypothesis, tested, demonstrated and report-ready states;
- dependencies on templates/concepts/runtime contracts;
- failure behavior and how to record skipped/blocked work without inventing results.

The skill template owns the shared schema; individual skills must reference reusable concepts rather than copy large source material or payload libraries into themselves.

### 9.2 Concept requirements

- Keep provenance in `sources.md`; record source date/context where available.
- Separate verified claims, source-derived patterns, and hypotheses.
- Include edge cases and likely false positives, not just successful attack narratives.
- State validation steps and what evidence would disprove the hypothesis.
- Do not store target-specific identifiers, raw secrets, or private target findings in general concepts.

### 9.3 Finding/evidence requirements

A finding must be reproducible from its target evidence folder, correlated to test context, and reviewed for scope and alternative explanations. Evidence may include request/response pairs, account-context comparisons, state transitions, browser observations, approved OOB callbacks, and supporting screenshots/HARs. Secret values must be appropriately redacted while preserving the evidence needed for reproduction.

## 10. Repository and Git operating contract

### 10.1 New repository boundary

- A new repository is intended; exact owner and remote slug/URL are **not yet specified in this Blueprint**.
- Use a separate local directory (suggested: `~/buggy-v4`) to avoid overwriting an older checkout.
- OpenCode/DeepSeek in OpenCode is the sole repository-side writer for approved build tasks: initializes the repo when authorized, lays down the tree, imports phase packages, writes implementation files, runs approved tests, and handles Git commits/pushes.
- The owner supplies/approves the exact new remote identity and authorizes remote creation/push. If authenticated tooling is unavailable, OpenCode reports the blocker rather than inventing success.

### 10.2 Package transfer

Each phase ZIP must include a manifest with:

- canonical relative path;
- exact artifact version where applicable;
- content hash for each file;
- intended destination (`REPOSITORY` or `MANAGEMENT_ONLY`);
- dependency/phase identifier;
- current-pass progress (`TODO`, `IN_PROGRESS`, `DONE`);
- validation performed and not performed.

OpenCode copies only entries marked `REPOSITORY`. Blueprint, prompts, handoff notes and roadmap files are management artifacts unless explicitly listed for repository inclusion. It must not copy every ZIP member blindly into the repo.

### 10.3 Git safety

Before any Git operation, inspect branch, working tree, repository root, remotes and destination. Preserve uncommitted changes. Never run destructive reset/clean, force-push, history rewrite or branch deletion as a shortcut. Commit only the verified task scope. Push only to the exact owner-approved remote and branch. No secret files, tokens, cookies, browser profiles, private evidence or local provider credentials are to be committed.

### 10.4 Single-writer rule

After an approved release package is delivered, OpenCode is responsible for repository edits; no second agent independently edits the same repository in parallel. ChatGPT can review diffs/reports but does not claim to have written to the user's repository. Repository changes are not trusted solely because the Builder says they are done: the exact diff and actual checks are reviewed.

## 11. Per-file completion and GAP closure

Every file/task needs a bounded acceptance checklist before authoring or implementation. A typical completion check includes:

1. Required upstream sources present and exact versions known.
2. All source-backed requirements for the file traced to the candidate.
3. Declared dependencies exist or are explicitly preserved as unresolved dependencies.
4. No unsupported claims, invented decisions, or silent scope expansion.
5. Cross-references point to canonical paths and correct versions.
6. Required review findings addressed and change report provided.
7. Required tests/checks actually run; unrun checks clearly stated.
8. The owner decision recorded when required.

A GAP is closed only using its authoritative closure rule and evidence. A textual mention, candidate proposal, successful syntax parse, reviewer verdict, file transfer, or a passing unrelated unit test does not close a GAP. If a GAP has no explicit acceptance rule, first derive a proposal from authoritative sources and obtain the required owner decision; do not guess.

## 12. Initial owner-supplied GAP index (not exhaustive until source extraction)

The following list is an intake starting point from the 2026-10-15 owner inventory. During Phase 2, the complete authoritative source files must be scanned to capture the full set and exact definitions.

### Runtime/security

- `GAP-TM-11` — canonical hash storage/trusted reference/definition integrity.
- `GAP-AS-03` and `GAP-TM-05` — MCP trust-list ownership/verification relationship.
- `GAP-TM-18` — egress classifier.
- `GAP-TM-22` through `GAP-TM-26` — redirect/normalization/binding group; exact per-ID wording must come from its source.
- `GAP-AS-01`, `GAP-AS-04` through `GAP-AS-10`.
- `GAP-TM-02`, `GAP-TM-06`, `GAP-TM-07`, `GAP-TM-09`, `GAP-TM-14`, `GAP-TM-15`, `GAP-TM-16`, `GAP-TM-17`, `GAP-TM-19`, `GAP-TM-20`, `GAP-TM-21`, `GAP-TM-24`.

### Validation/templates/runtime wiring

- `GAP-VM-01`, `GAP-VM-03`, `GAP-VM-04`, `GAP-VM-05`, `GAP-VM-06`, `GAP-VM-09`.

Do not interpret this abbreviated index as the full GAP register. Preserve all additional OPEN GAPs found in the governing sources and the original IDs/descriptions.

## 13. Build governance and continuity

- `governance/BUILD-STATE.md` contains one current pointer: active phase, current artifact, last confirmed result, next exact input/action, and known blocker note. It must not become a second architecture document.
- `governance/GAP-REGISTER.md` indexes authoritative GAPs with ID, canonical source and section, summary, affected files, dependencies, acceptance evidence, decision needed and closure evidence. It must not rewrite the source definition.
- `governance/DECISION-LOG.md` is append-only for explicit owner decisions. Each record states what was decided, what was not decided, affected artifacts/versions, scope, date, and follow-up consequences.
- The external roadmap and release manifest govern phase packaging. A repo-side progress update must not silently claim that an external ZIP was delivered or tested unless that fact is evidenced in the current release record.
- At the end of every authoring session, the current phase workspace and its handoff state are saved as real files. Do not rely on chat memory as the sole storage mechanism.

## 14. Known design lessons to enforce

1. **No prompt treadmill:** one bounded artifact/task per prompt, exact source inputs, exact allowed modifications, completion criteria and a stop rule.
2. **No planning-without-building:** every phase should produce a verifiable artifact or testable implementation slice, not only additional recommendations.
3. **No hidden dependencies:** each file names upstream artifacts, and the roadmap respects that dependency graph.
4. **No empty-file false alarms:** distinguish intentional placeholder, missing artifact, and authored content. Never overwrite a zero-byte placeholder just because it is empty.
5. **No status conflation:** `DONE`, `LOCKED`, transferred, tests passed and runtime-ready remain distinct facts.
6. **No hash theater:** cryptographic hashes only establish equality to a value. Trust in the reference and binding to the executed artifact must be designed separately.
7. **No preflight-as-dispatcher confusion:** preflight checks do not prove that a real runtime invocation uses the checked result.
8. **No self-approval:** a builder's claim does not replace independent review or actual tests.
9. **No invisible transfer errors:** package manifests, expected paths and checksums are checked before copy and after copy when feasible.
10. **No accidental repo takeover:** the new repository identity and local destination are explicit; old repo data is preserved.
11. **No target leakage into reusable knowledge:** generalized lessons are separated from target-specific testing state.
12. **No unbounded cleanup:** unrelated refactors and file renames are excluded from bounded tasks.

## 15. External project-management artifacts (not automatically part of repository)

The following files are coordination/release artifacts and are stored outside the `buggy-v4/` source tree by default:

- `BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md` — this locked structural baseline.
- `BUGGY-BUILD-ROADMAP-v4.0.md` — ordered file intake and build phases.
- `BUGGY-CHAT-HANDOFF-AND-DECISIONS.md` — current handoff and owner workflow rules.
- `BUGGY-DEEPSEEK-CHAT-AUTHOR-PROMPT.md` — persistent prompt for the chat-side author role.
- `BUGGY-OPENCODE-REPO-OPERATOR-PROMPT.md` — persistent prompt for repository-side execution.
- Phase ZIPs and their manifests/checksums.

These management artifacts are not copied to the repository unless an explicit release manifest lists them as `REPOSITORY` files.

## 16. Owner lock record

- **Decision:** LOCKED.
- **Decision date:** 2026-10-15.
- **Authority:** Explicit owner request in the conversation to make the final Blueprint complete and locked.
- **Locked artifact:** `BUGGY-FINAL-CANONICAL-BLUEPRINT-v4.0.md`.
- **Scope:** Canonical intended tree, catalog of planned workflow/vulnerability skills and concepts, ownership boundaries, governance/index files, safe repository operating rules, and phase order.
- **Not covered by this lock:** implementation status, actual repository creation, artifact transfer, any individual contract's lock, any technical GAP closure, any test result, or runtime readiness.
- **Change rule:** A structural or normative change to this Blueprint requires a versioned successor and explicit owner approval. It must not be edited in place under the same locked version.

---

**End of canonical Blueprint v4.0.**
