# redaction.md

> **Status:** review
> **Version:** v1.2
> **Scope:** Defines the operational policy for detecting, transforming, handling failures of, and releasing data that may contain secrets or sensitive material before that data crosses a protected boundary. Establishes the redaction inventory, the output transformation rules, the invocation-scoped round-trip protocol, the constrained inbound-restoration criteria, the fail-closed behavior, the release/audit separation, and the post-response quarantine and release-approval control for untrusted MCP responses. Depends on runtime implementation.
> **Authority:** Runtime contract (per `architecture/file-contracts.md` §4.2). Operationalizes `architecture/agent-security.md` §7 (secret exposure) and §8.2 (untrusted MCP quarantine/release) and consumes `runtime/tool-manifest.md` v1.5 §3.5 steps 11–12, §6.3.I, and §7.3. Also consumes **Owner Decision A (2026-10-13)** as a constrained interpretation of `architecture/agent-security.md` §7.2. Does not redefine trust tiers or sensitive-operation approval.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-security.md` §3, §5.2, §7.1–7.3, §8.2–8.3, §12, `runtime/tool-manifest.md` v1.5 (LOCKED policy baseline), `architecture/agent-architecture-rules.md`, **Owner Decision A (2026-10-13)**.
> **Depended on by:** every caller that invokes a tool with `redaction_required: true`; every caller that receives a response from an untrusted or unknown MCP server; the output-boundary enforcement layer; the observability layer; the future `runtime/opencode/ORCHESTRATION.md` when implemented.
> **Related OPEN GAPs:** `GAP-AS-02` (redaction protocol/implementation), `GAP-AS-08` (canonical secret inventory), `GAP-TM-17` (fail-closed redaction in all failure modes), `GAP-TM-11` (definition integrity — all invocations remain refused while OPEN).

> **Lock decision (2026-10-13): LOCKED by explicit project-owner authorization** following the independent review disposition `PASS — READY TO LOCK` on the corrected v1.2 candidate. This is a **document/policy lock only**. It does not claim implementation, tests, runtime verification, repository transfer, or operational readiness. The lifecycle `Status: review` above remains separate from the LOCKED decision.
>
> **Version line.**
> - v1.0 of this file remains **FREEZE / unapproved**.
> - v1.1 of this file remains **FREEZE / unapproved** (independent review 2, 2026-10-13; blocker B-01 unresolved).
> - v1.2 is a new, owner-authorized version cycle prepared under **Owner Decision A (2026-10-13)**, which records a constrained interpretation of `architecture/agent-security.md` §7.2 for the safe restoration of placeholders.
> - Preparing v1.2 does not unfreeze, overwrite, approve, or promote v1.0 or v1.1.
> - v1.2 was **LOCKED by explicit project-owner decision on 2026-10-13** as a document/policy baseline only. The lifecycle `Status: review` is retained separately from the lock decision. See `BUGGY-REDACTION-v1.2-LOCK-RECORD.md`.

---

## 1. Purpose and Ownership

### 1.1 Purpose

This contract defines:

- the categories of sensitive data the runtime is expected to redact;
- the boundaries across which redaction is required;
- the deterministic transformation applied to matched sensitive values on the outbound leg;
- the constrained inbound-restoration criteria under which a returned placeholder may be replaced by its original value, per Owner Decision A (2026-10-13);
- the invocation-scoped, local-only round-trip map required when data is sent to an external model, MCP server, or third-party tool;
- the fail-closed behavior when redaction success or inbound-handling safety cannot be established;
- the separation between raw tool output, redaction processing, validated redaction result, pre-invocation authorization, post-response quarantine and release approval, and audit metadata;
- the control that keeps untrusted or unknown MCP server responses quarantined until the operator separately approves their release into model reasoning context;
- how future patterns, categories, and formats are added without weakening fail-closed behavior;
- the failure codes reused from `runtime/tool-manifest.md` and the cross-references to other contracts.

### 1.2 What this file owns

- the **outbound redaction policy** — what must be redacted on the way out, when, and with what transformation semantics;
- the **inbound restoration policy** — the constrained criteria under which a returned placeholder may be replaced by the original value, and the conditions under which automatic restoration is prohibited;
- the **redaction inventory** — the categories of sensitive material the runtime is expected to detect (subject to §9 GAPs);
- the **invocation-scoped, local-only map** — the placeholder-to-secret mapping used for restoration where permitted;
- the **fail-closed behavior** for redaction failures and for unsafe restoration attempts;
- the **release/audit separation** — including the distinct control for post-response quarantine and operator-approved release of untrusted MCP responses.

### 1.3 What this file does not own

- the **tool inventory** — owned by `runtime/registry.json` v0.7-rev2;
- the **tool gating and approval policy**, including the single pre-invocation authorization step and the post-response release decision — owned by `runtime/tool-manifest.md` v1.5 (LOCKED) §3.5 step 11;
- the **trust tier definitions** and the list of protected boundaries — owned by `architecture/agent-security.md` §3, §7, and §8;
- the **target scope** — owned by `testing/<target>/scope.md`;
- **model routing** — owned by `runtime/model-routing.md` (when implemented);
- the **text of `architecture/agent-security.md` §7.2** — locked and unamended. This contract consumes Owner Decision A as a **constrained interpretation** of that section, not as an amendment to it. A future need to change §7.2 itself requires a separate versioned governance cycle for that locked contract;
- the **concrete implementation** of detection, transformation, mapping, restoration, quarantine, or release — deferred; see §9;
- **operator authorization** as a flow — the single pre-invocation step and the post-response release decision are both owned by `runtime/tool-manifest.md` v1.5 §3.5 step 11. This file does not introduce a second invocation prompt.

### 1.4 Consumers

Any caller that invokes a tool whose effective `redaction_required: true` (per `runtime/tool-manifest.md` §3.4 / §3.2) MUST route the tool's output through the redaction policy defined here before that output crosses a protected boundary.

Additionally:

- Any data sent from the local runtime to an external model, an untrusted MCP server, or a third-party tool MUST be redacted per `architecture/agent-security.md` §7.2, regardless of the tool's `redaction_required` flag.
- Any response from an untrusted or unknown MCP server MUST remain quarantined per `architecture/agent-security.md` §8.2 and MUST NOT enter model reasoning context until the operator separately approves its release as required by `runtime/tool-manifest.md` v1.5 §3.5 step 11, **and** the redaction gate at §3.5 step 12 (and every other applicable control) has passed.
- Restoration of a placeholder to its original value is **not** a consequence of a placeholder's presence in returned output. It is governed by §4.4 and the constrained criteria recorded in Owner Decision A.

---

## 2. Data Classification and Sensitive-Data Inventory

### 2.1 Classification approach

The inventory is split into three detection confidence bands:

- **Pattern-anchored** — values whose shape is a strong signal (e.g. a JWT-shaped token, a PEM-formatted private key header, an `Authorization: Bearer <token>` header).
- **Contextual** — values identified by their position or key name in a known structure (e.g. a JSON field named `password`, `api_key`, `secret`, `token`; a query parameter named `password`, `access_token`, `api_key`).
- **Heuristic** — high-entropy strings, long base64-like values, or cookie values that do not carry a pattern anchor.

**This contract does not promise universal secret discovery.** A redacted output means that the runtime applied the policies below to the extent the runtime can currently detect. It does not mean the output is guaranteed secret-free.

### 2.2 Sensitive-data categories

Proposed categories the runtime is expected to handle when detection is available:

| Category ID | Description | Detection band (proposed) | Source mapping |
|---|---|---|---|
| `CREDENTIAL` | Passwords and password-like values (login passwords, basic-auth passwords). | Pattern-anchored + contextual | `agent-security.md` §7.1 account credentials |
| `API_KEY` | Provider API keys and long-lived service tokens (cloud provider keys, SaaS keys). | Pattern-anchored + contextual | `agent-security.md` §7.1 API keys |
| `BEARER_TOKEN` | Bearer / OAuth-style access tokens. | Pattern-anchored (`Authorization: Bearer …`) + contextual | `agent-security.md` §7.1 account credentials |
| `REFRESH_TOKEN` | Refresh tokens, long-lived session tokens. | Contextual + heuristic | `agent-security.md` §7.1 account credentials |
| `SESSION_COOKIE` | Session identifier cookies and session-like values. | Contextual (cookie header, `Set-Cookie` names) | `agent-security.md` §7.1 account credentials |
| `COOKIE_VALUE` | Non-session cookie values that may carry secrets (CSRF tokens, auth cookies). | Contextual + heuristic | `agent-security.md` §7.1 account credentials |
| `AUTHORIZATION_HEADER` | Values inside `Authorization`, `Proxy-Authorization`, and similar headers. | Pattern-anchored | `agent-security.md` §7.1 account credentials |
| `PRIVATE_KEY` | PEM-formatted private keys, SSH private keys, other secret material with a recognizable header. | Pattern-anchored | `agent-security.md` §7.1 account credentials |
| `PII` | Personal or identifying information already protected by the existing policy in `agent-security.md` §7.3 (emails, phone numbers, payment info when under a redaction policy). | Contextual | `agent-security.md` §7.1 operator PII; §7.3 PII |
| `URL_EMBEDDED_CREDENTIAL` | Credentials embedded in URLs (`scheme://user:pass@host`). | Pattern-anchored | `agent-security.md` §7.1 account credentials |
| `SENSITIVE_QUERY_PARAM` | Query-string parameters whose names indicate secret semantics (`password`, `token`, `api_key`, `access_token`, `secret`). | Contextual | `agent-security.md` §7.1 account credentials |
| `STRUCTURED_SECRET_FIELD` | Values under JSON/query keys whose names indicate secret semantics. | Contextual | `agent-security.md` §7.1 account credentials |
| `TARGET_IDENTIFIER` | Target real domains and target-identifying information **when working under an active redaction policy**. | Contextual + pattern-anchored | `agent-security.md` §7.1 target identifying information; §7.3 target real domain (when redaction policy is active) |
| `INTERNAL_HOST_IP` | Internal hostnames and IP addresses. | Pattern-anchored + contextual | `agent-security.md` §7.1 internal hostnames; §7.3 internal hostnames and IPs |
| `CUSTOMER_ACCOUNT_ID` | Customer IDs, account IDs, and similar tenant/account identifiers. | Contextual | `agent-security.md` §7.1 customer IDs |
| `WEBHOOK` | Webhook URLs and webhook identifiers. | Pattern-anchored + contextual | `agent-security.md` §7.1 webhooks |
| `INTERNAL_SERVICE_URL` | Internal service URLs and internal endpoints. | Pattern-anchored + contextual | `agent-security.md` §7.1 internal service URLs |
| `PROXY_HISTORY_IDENTIFIER` | Proxy-history identifiers that link to the operator or a specific request. | Contextual | `agent-security.md` §7.1 proxy history identifiers; §7.3 proxy history identifiers |
| `THIRD_PARTY_IDENTIFIER` | Third-party platform usernames, report IDs, and similar identifiers when working under a redaction policy. | Contextual | `agent-security.md` §7.1 third-party identifiers |

**Categories the runtime is NOT expected to reliably detect in the first candidate:**

- secrets inside compressed payloads that the runtime does not decode;
- secrets inside arbitrary user-defined encodings the runtime does not recognize;
- secrets that appear as ordinary-looking short strings (e.g. a 6-digit PIN without any anchor or context);
- secrets inside non-text binary media.

### 2.3 Boundary types redacted

Per `architecture/agent-security.md` §7.3, the boundary types below are redacted before crossing the local → external boundary.

- **Target real domain** — the §7.3 condition "when redaction policy is active" applies specifically to the target real domain. When the redaction policy is not active, the target real domain is not added to the category set for that reason alone.
- **Account identifiers (cookies, tokens, session IDs), PII, internal hostnames and IPs, API keys and webhooks, proxy history identifiers** — per §7.3 these are redacted before the local → external boundary is crossed, independent of whether a tool's output-leg `redaction_required` flag happens to be `true` or `false`. The outbound protection is required by `agent-security.md` §7.2 and is separate from the tool-manifest output-leg flag (see §3.2 and §5.6).
- Additional categories carried into this candidate for completeness of the inventory (see §2.2): `TARGET_IDENTIFIER`, `CUSTOMER_ACCOUNT_ID`, `INTERNAL_SERVICE_URL`, `THIRD_PARTY_IDENTIFIER`.

This wording deliberately avoids conditioning every listed category on "an active redaction policy". A false or absent output-leg `redaction_required` flag does not waive the source contract's outbound protection. `GAP-AS-08` remains OPEN; the canonical per-deployment inventory is not fixed by this contract.

### 2.4 Where sensitive material may appear

- plain-text tool output;
- HTTP request/response bodies;
- headers and cookies;
- structured payloads (JSON, form-encoded, XML if the runtime supports it);
- URL query strings and fragments;
- configuration dumps returned by tools (e.g. project/user option dumps);
- error messages and diagnostic strings;
- OOB callback payloads and metadata;
- data sent to external models, MCP servers, or third-party tools;
- responses returned from untrusted or unknown MCP servers (see §6).

### 2.5 Honest limits

This contract distinguishes **exact, recognizable secret patterns** from **heuristic detection**. It does not promise that every listed category is fully covered. Coverage of each category is subject to the implementation state recorded in §9. `GAP-AS-08` remains OPEN; the canonical inventory for any given deployment is not fixed here.

---

## 3. Data-Flow Boundaries

### 3.1 Boundaries

Using the trust-tier definitions in `architecture/agent-security.md` §3 and §7, the MCP-trust boundary in §8, and the tool policy in `runtime/tool-manifest.md` v1.5:

- **Local runtime context** — the in-process environment where the tool executes, its output is parsed, and structured analysis is performed. No redaction is required strictly inside this context for operational use; redaction is required when the output crosses outward.
- **Local → external boundary** — any transfer of data from the local runtime to an external model, an untrusted MCP server, a third-party tool, an external service, or a cloud model. Per `agent-security.md` §7.2, the local runtime MUST redact data before it is sent. On return, the constrained restoration rules in §4.4 govern whether any returned placeholder may be replaced by its original value.
- **Tier-3 → destination write path** — any attempt to write derived artifacts into a canonical location. The destination artifact's own trust tier governs: a Concept is tier 3, a memory lesson is tier 2, and a Skill revision is tier 1. This file does not authorize such writes; the canonical update mechanism is owned by `knowledge-flow.md` and `learning-flow.md`. Raw tier-3 output MUST NOT be written directly to any canonical artifact. Redaction is applied at the applicable protected output/write boundary, before the data crosses into its destination. Canonical write authorization remains owned by the proper existing contracts.
- **Untrusted MCP response boundary** — the boundary across which a response from an untrusted or unknown MCP server would otherwise enter model reasoning context. This boundary has its own separate control: the post-response quarantine and release-approval gate (see §6), distinct from pre-invocation authorization and from redaction-pipeline success.
- **Operator-facing observability logs** — must not contain tier-1 secrets or raw untrusted content (per `agent-security.md` §5.2 and §12). Redaction applies before log emission. For logs, restoration is not intended; category-only redaction is sufficient. `runtime/tool-manifest.md` v1.5 §7.3 requires that **raw request/response bodies and other untrusted content MUST NOT be placed in the observability log**; only the untrusted MCP server's identity and non-content audit metadata may be recorded.

### 3.2 When redaction is required

Redaction is required in two distinct cases:

1. **Outbound data to external model / MCP / third-party tool** — required by `architecture/agent-security.md` §7.2. This requirement applies regardless of the tool's `redaction_required` flag. The local runtime MUST redact before sending.
2. **Tool output crossing a protected boundary when the tool's effective `redaction_required: true`** — required by `runtime/tool-manifest.md` §3.4 / §3.2 and §3.5 step 12. This is the manifest's existing output-leg behavior.

A false or absent output-leg `redaction_required` flag does not waive the separate outbound redaction requirement in case 1.

### 3.3 Success, error, and partial paths

The redaction policy applies to:

- **successful tool responses** — the normal path;
- **error responses** — error bodies may embed request echoes, stack traces, or diagnostic metadata that carries secrets;
- **timeouts** — a timeout may return a partial body that still contains sensitive content;
- **retries** — each attempt's output is independently subject to redaction; a failed redaction on any attempt is treated as a failure for that attempt;
- **truncated output** — partial output is redacted under the same rules; the release decision treats truncation as a "cannot establish full redaction success" condition per §5.

Redaction is not bypassed by the tool call having executed. A tool's execution success is orthogonal to whether the output is safe to release.

### 3.4 Outbound redaction and inbound handling are separate concerns

This contract deliberately separates two processes that must not be conflated:

**Outbound redaction (send path).** Before data crosses the local → external boundary, the local runtime replaces matched sensitive values with placeholders (round-trip) or category labels (non-round-trip), according to the boundary. This is where the invocation-scoped, local-only map is created (see §4.2).

**Inbound handling (return path).** When output returns from an external model, MCP server, or third-party tool, the returned content is treated as externally controlled data. Presence of a placeholder in returned content is **not** sufficient authorization to replace it with the original value. Inbound handling is governed by §4.4 under the constrained criteria recorded in Owner Decision A (2026-10-13).

Explicit consequences:

1. The invocation-scoped map exists to enable restoration only in locally authorized slots that satisfy the §4.4 criteria. It does not exist to enable mass restoration of placeholders found anywhere in returned content.
2. Outbound redaction MUST NOT be weakened on the assumption that any inbound occurrence of a placeholder will be safely handled.
3. Failure to satisfy §4.4 on the inbound leg is a fail-closed condition (§5), not a fallback to automatic restoration.

---

## 4. Redaction Transformations

### 4.1 Replacement representations

Two representations are defined:

- **Round-trip placeholder** — `[REDACTED:<CATEGORY_ID>:<OPAQUE_TOKEN>]`
  - Used when data is sent to an external model, MCP server, or third-party tool and may, under §4.4, be replaced by its original value inside a narrowly authorized local slot.
  - `<CATEGORY_ID>` is one of the categories in §2.2.
  - `<OPAQUE_TOKEN>` is an invocation-scoped, non-stable, opaque identifier generated locally. It MUST NOT be derived from the original secret in a reversible or predictable way. It MUST be unique per matched occurrence within the invocation.
- **Non-round-trip category label** — `[REDACTED:<CATEGORY_ID>]`
  - Used for protected outputs where restoration is not intended (e.g. operator-facing audit logs, final derived artifacts that are not sent back to an external system).
  - It identifies the category, not the original value. Raw sensitive values MUST NOT be copied into the label.

### 4.2 Invocation-scoped local-only map

For each invocation that sends data to an external system:

- The runtime creates a **local-only map** from each issued round-trip placeholder to the original sensitive value.
- The map is **invocation-scoped**: it is created for one invocation, used for inbound handling of that invocation's returned output under §4.4, and then discarded or expired.
- The map MUST NOT be transmitted to the external system.
- The map MUST NOT be written to any log, audit record, diagnostic, or canonical artifact.
- The map MUST NOT be exposed to the model as reasoning context.
- The opaque tokens MUST be non-stable across invocations. The same secret in two different invocations MUST NOT receive the same opaque token.
- The map MAY map multiple placeholders to the same original value if the same secret appears multiple times.
- The map's existence and any lookup operations MUST NOT be exposed in any externally observable path.

The map is an **inbound-handling aid**, not an inbound-handling authorization. Its presence enables §4.4 to check the invocation binding and the placeholder value; it does not enable automatic restoration.

### 4.3 What the outbound transformation does

For each matched occurrence:

- the matched value is replaced by a round-trip placeholder or a non-round-trip category label according to the boundary;
- the length of the surrounding non-sensitive text is preserved where practical, so structural analysis of the redacted output remains possible;
- JSON keys, header names, and structural delimiters are preserved;
- a value matched under multiple categories is labeled with the most specific category (e.g. `AUTHORIZATION_HEADER` before `BEARER_TOKEN`).

### 4.4 Inbound handling and constrained restoration

The following rules govern the return path. They apply to any output returned by an external model, MCP server, or third-party tool after a redacted outbound request. They implement the constrained interpretation of `architecture/agent-security.md` §7.2 recorded in Owner Decision A (2026-10-13).

#### 4.4.1 Prohibition of automatic restoration in free-form and untrusted content

Automatic restoration of a returned placeholder to its original value is **prohibited**:

- in any free-form text within returned content;
- inside any response from an untrusted or unknown MCP server;
- inside any field whose identity, purpose, or scope was not declared locally **before** the outbound request was dispatched.

The mere presence of an exact placeholder in returned content is **not** authorization to restore it. The external party can echo the placeholder exactly, in any position, in any field, or in free-form text, because the placeholder was transmitted across the boundary.

#### 4.4.2 Constrained local-slot restoration criteria

Under Owner Decision A, a returned placeholder may be restored to its original value **only** inside a locally defined, pre-authorized structured slot, and only when **all** of the following criteria are satisfied for that occurrence:

1. **Pre-declaration.** The target slot — its field identity, its purpose, and the placeholder it is authorized to receive — was declared locally **before** the outbound request was dispatched. A slot is not created after the response arrives in reaction to content the response contains.
2. **Invocation binding.** The slot is bound to the **same invocation** that issued the placeholder. A placeholder issued by invocation X MUST NOT be restored into a slot declared by invocation Y.
3. **Structured, locally authored location.** The target is a locally defined structured field (for example, a specifically named field of a locally authored structure) — not free-form text, not an externally authored field, and not a field whose identity was chosen by the external party.
4. **Exact full-field match.** The value returned at the slot matches the placeholder exactly and unmodified. Partial matches, embedded occurrences, or the same placeholder appearing in a **different** field do not qualify.
5. **Map validity.** The invocation-scoped local-only map (§4.2) is present, intact, and contains the placeholder paired with its original value.

If any of the five criteria is not satisfied for a given occurrence, restoration fails closed for that occurrence (§5.3). Criteria 1, 3, and 4 collectively exclude free-form text and externally chosen fields; criterion 2 excludes cross-invocation restoration; criterion 5 excludes restoration under map corruption or mismatch.

**Scope of this rule.** This is a **constrained interpretation** of `architecture/agent-security.md` §7.2 recorded as an owner decision (Owner Decision A, 2026-10-13). It is **not** a claim that these criteria are stated verbatim in that locked source, and it does **not** amend that source. A future need to change §7.2 itself requires a separate versioned governance cycle for the locked architecture contract.

#### 4.4.3 Requirements applicable to any permitted restoration

When restoration is permitted under §4.4.2, the runtime MUST at minimum:

- restore only exact, unmodified placeholders issued by the same invocation and present in that invocation's valid map;
- fail closed if the map is missing, corrupt, mismatched, expired, or if any §4.4.2 criterion is not satisfied for the occurrence;
- refuse to restore unknown, forged, changed, malformed, expired, or unmapped placeholders;
- not make the external system's output authoritative;
- not promote untrusted tool output into instruction;
- not authorize writing raw output to canonical artifacts;
- not bypass any trust-tier or canonical update rule;
- not authorize release of a quarantined untrusted MCP response into model reasoning context (see §6).

Restoration (where permitted) is a substitution of a placeholder by its mapped original inside a specific, locally authored slot that satisfies §4.4.2. It is **not** a substitution of a placeholder by its mapped original inside arbitrary externally controlled text or fields.

### 4.5 Nested and structured handling (outbound)

- **JSON**: keys are preserved; string values under sensitive keys (per §2.2 contextual rules) are replaced; nested objects and arrays are processed recursively.
- **Form-encoded bodies**: parameter values under sensitive keys are replaced; parameter names are preserved.
- **URL query strings**: query parameter names are preserved; values under sensitive parameter names are replaced; the URL structure remains parseable.
- **Headers**: header names are preserved; sensitive header values are replaced.
- **Cookies**: cookie names are preserved; sensitive cookie values are replaced.
- **Plain text**: matched substrings are replaced in place; the surrounding text is preserved.

These rules describe the outbound transformation. Inbound handling is governed by §4.4.

### 4.6 Repeated occurrences

When the same logical secret appears multiple times in one response, each occurrence is replaced independently with a unique invocation-scoped placeholder on the outbound leg. The runtime is **not** required to produce a stable cross-occurrence identifier.

**This contract does not claim** stable cross-run identifiers, cryptographic pseudonymization, irreversible transformation, or determinism beyond the intra-invocation rules above. Any such capability is subject to a separate implementation decision and is not required by this contract.

### 4.7 Malformed and unsupported inputs (outbound)

- **Malformed JSON**: the runtime MUST fail closed (§5) rather than attempt partial redaction on ambiguous structure.
- **Unsupported encodings** (e.g. compressed payloads the runtime does not decode): the runtime MUST fail closed.
- **Partial parse success** with ambiguity about structure: the runtime MUST fail closed.
- **Unknown structured formats**: the runtime MAY apply plain-text pattern redaction over the raw output if, and only if, the runtime can establish that no structural reinterpretation is required. Otherwise fail closed.

### 4.8 False positives and uncertain matches (outbound)

- A pattern-matched value that turns out to be benign is redacted anyway (conservative default).
- A heuristic match with low confidence is treated as sensitive for the purpose of redaction. An uncertain **individual candidate match** is conservatively redacted.
- Uncertainty about **processing completeness/coverage**, parse ambiguity, a skipped required stage, or inability to prove the required pipeline completed is a separate condition and triggers fail-closed per §5.
- Uncertain match outcomes at the boundary of a detection rule are treated as matched for redaction and do not by themselves fail the release; only uncertainty about whether the required pipeline completed triggers fail-closed (§5).
- Low-confidence individual matches MUST NOT be surfaced as a "successful detection count" in audit metadata beyond an aggregated category count (§6).

### 4.9 Prohibited transformations and prohibited inbound operations

The runtime MUST NOT:

- copy the raw secret into the replacement label, placeholder, error message, exception string, or log record;
- transmit or log the local-only map;
- use a placeholder token that is derived from the secret in a reversible or predictable way;
- **restore a returned placeholder inside free-form text or inside any untrusted or unknown MCP response** (§4.4.1);
- **restore a returned placeholder unless every §4.4.2 criterion is satisfied for that occurrence**;
- restore a placeholder that is not an exact, unmodified placeholder from the same invocation map;
- use hash-of-secret values that are reversible in practice without a documented mechanism;
- emit a partial redacted output that still contains a matched raw secret in an unaudited field.

---

## 5. Fail-Closed Behavior

### 5.1 Principle

When a tool's effective `redaction_required: true`, output MUST NOT cross a protected boundary unless redaction success can be established under this contract.

When data is sent to an external model, MCP server, or third-party tool, outbound redaction MUST succeed before dispatch.

A tool call having executed successfully does not mean its output is safe to release.

Redaction success on a response from an untrusted or unknown MCP server does not authorize release of that response into model reasoning context. A separate operator-approved release gate applies (§6).

### 5.2 Pipeline success criteria (outbound)

Redaction-pipeline success means, at minimum, all of the following:

1. complete, non-truncated input was available in a supported format;
2. every required configured detection/transformation stage completed;
3. no required stage failed or timed out;
4. every recorded match was transformed;
5. output serialization/format validation succeeded;
6. every required post-transform integrity check passed.

This proves completion of the declared outbound pipeline. It does **not** prove universal absence of all possible unknown secrets, and it does **not** authorize release of an untrusted MCP response into model reasoning context.

### 5.3 Failure conditions that trigger fail-closed

At minimum:

| Condition | Behavior |
|---|---|
| Redaction implementation is absent. | Refuse release; emit `redaction_unavailable` on the output leg. |
| A required detector for an applicable category fails. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Processing times out before completion. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Output is truncated or partial. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Input contains an unsupported type or encoding. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Parsing fails. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Processing completeness/coverage is uncertain, structure is ambiguous, a required stage was skipped, or completion cannot be proven. | Refuse release; emit `redaction_unavailable` on the output leg. |
| One processing stage succeeds but a required later stage fails. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Caller cannot establish that the declared outbound pipeline completed. | Refuse release; emit `redaction_unavailable` on the output leg. |
| Outbound redaction to an external model/MCP/third-party tool fails or cannot be proven. | Do not dispatch the outbound data. This is distinct from the output-leg `redaction_unavailable` code; see §5.5. |
| A returned placeholder is present in free-form text or in an untrusted/unknown MCP response, or any §4.4.2 criterion (pre-declaration, invocation binding, structured locally authored location, exact full-field match, valid map) is not satisfied for the occurrence. | Do not restore for that occurrence; fail closed for that occurrence. The affected returned content MUST NOT be applied to local state as if it had been safely handled. |
| The local-only map is missing, corrupt, mismatched, expired, or contains no exact match for a placeholder whose restoration would otherwise be considered. | Fail closed before applying the affected response to local state. |
| Returned output contains unknown, forged, changed, malformed, or unmapped placeholders. | Do not restore those placeholders; fail closed before applying the affected response to local state. |
| An untrusted or unknown MCP server's response is present and the operator has not separately approved its release into model reasoning context. | The response remains quarantined; it MUST NOT enter model reasoning context. See §6. |
| The redaction gate at `runtime/tool-manifest.md` v1.5 §3.5 step 12 has not been satisfied for a released response destined for model reasoning context. | The response MUST NOT enter model reasoning context. See §6.2. |

### 5.4 Reused error code

The refusal/error code for a redaction failure on the **output leg** is `redaction_unavailable`, as already defined in `runtime/tool-manifest.md` v1.5 §6.3.I. This contract reuses that code; it does not define a conflicting code.

### 5.5 Outbound redaction failure

Outbound redaction failure is governed by `architecture/agent-security.md` §7.2. If outbound redaction fails or cannot be proven, the outbound data MUST NOT be sent.

`redaction_unavailable` retains its existing output-leg meaning from the locked tool-manifest. It is not silently redefined as the same code for outbound redaction failure. Any code integration that would assign a distinct outbound failure code requires a future versioned contract decision and is explicitly left OPEN.

### 5.6 Output leg vs input leg

Per `runtime/tool-manifest.md` §3.5 step 12, `redaction_unavailable` applies to the **output leg**: the tool call may proceed; the output handling fails closed. This contract preserves that boundary.

The outbound redaction requirement for external model/MCP/third-party data is an independent security rule from `agent-security.md` §7.2. It can block dispatch even when the tool-manifest output-leg flag is false.

### 5.7 Diagnostics must not expose the secret

Failure diagnostics (error records, alerts, human-readable explanations) MUST NOT contain the original secret value. Safe diagnostic content includes:

- tool identifier (`registry_id`);
- processing stage at which the failure occurred;
- failure category (from §5.3);
- aggregated category counts (e.g. "3 `BEARER_TOKEN` occurrences matched before failure");
- timestamps;
- a correlation ID linking the failure to the originating invocation.

The local-only map and raw values MUST NOT appear in any diagnostic path.

### 5.8 Tool call success ≠ release approval

A tool whose invocation succeeded under `runtime/tool-manifest.md` §3.5 does not have release approval for its output. Release approval is the outcome of the redaction pipeline plus, where applicable, the operator-approved post-response release control for untrusted or unknown MCP responses (§6). This contract does not introduce a second invocation prompt.

---

## 6. Output Release, Quarantine, and Audit Policy

### 6.1 Six-stage separation

The runtime MUST keep the following six concerns separate:

1. **Pre-invocation authorization** — the single operator authorization prompt required by `runtime/tool-manifest.md` v1.5 §3.5 step 11, when the effective approval class is `per_call`. This governs whether the invocation is allowed to proceed. It is owned by the locked manifest. **It is not the same control as the post-response release decision in item 5**, even though the locked manifest references both under the same numbered step 11.
2. **Raw tool output** — the bytes returned by the tool. Treated as tier-3 data (per `agent-security.md` §3). Not released; not logged in raw form.
3. **Redaction processing** — the deterministic outbound transformation applied to the raw output using the rules in §4.1–§4.3, §4.5–§4.8, including creation of the invocation-scoped local-only map when round-trip is required.
4. **Redaction result and validation** — the redacted output plus a validation outcome (success / failure category per §5.3). Validation is a state, not a model judgment. Inbound handling per §4.4 is a separate concern.
5. **Post-response release decision** — for responses from untrusted or unknown MCP servers, the response remains quarantined per `architecture/agent-security.md` §8.2 and MUST NOT enter model reasoning context until the operator separately records a release decision, as required by `runtime/tool-manifest.md` v1.5 §3.5 step 11. **This control is not part of the pre-invocation authorization decision in item 1**, occurs only after the call returns, is not satisfied by the pre-invocation authorization prompt, and is not a second invocation prompt. For other outputs, this stage is not applicable.
6. **Audit metadata** — the operator-facing record of the processing (see §6.5).

### 6.2 Post-response quarantine, release decision, and the source-ordered sequence

This section operationalizes `architecture/agent-security.md` §8.2 and `runtime/tool-manifest.md` v1.5 §3.5 step 11 for the untrusted/unknown MCP case, and reflects the sequence defined by the locked manifest at §3.5 steps 11–12. It does **not** introduce a second invocation authorization prompt and does **not** modify the manifest's single-prompt-per-invocation rule.

**Two distinct controls referenced under step 11.** The locked manifest's numbered step 11 references two controls that are not the same control and do not occur at the same time:

- **(a) Pre-invocation authorization prompt.** When the effective approval class requires it, exactly one operator prompt is issued before invocation. This is the single-prompt-per-invocation control.
- **(b) Post-response release decision.** After the call returns, and only for responses from untrusted or unknown MCP servers, a release decision is required before the response may proceed toward model reasoning context.

The fact that the locked manifest describes both controls under the same numbered section (step 11) does not make them the same control. They occur at different times (before vs. after the call), govern different objects (the invocation vs. the returned response), and are not satisfiable by each other. A recorded pre-invocation authorization prompt does not satisfy the post-response release decision, and a recorded post-response release decision is not an invocation authorization prompt.

**Source-ordered sequence (per `runtime/tool-manifest.md` v1.5 §3.5):**

1. **Step 11 — two distinct controls, referenced in the same numbered section.**
   - **11(a) — Pre-invocation authorization prompt.** Issued before the call, when the effective approval class requires it. It governs whether the invocation is allowed to proceed.
   - **11(b) — Post-response release decision.** Recorded after the call returns, and only for responses from untrusted or unknown MCP servers. It governs whether the quarantined response may proceed toward model reasoning context.
2. **Step 12 — redaction fail-closed check on the output leg.** If the redaction requirement applies and redaction success cannot be proven, the output MUST NOT cross the applicable boundary. For a released response destined for model reasoning context, step 12 governs whether that response may actually enter that context. If step 12 fails, the response MUST NOT enter model reasoning context even if the step 11(b) release decision was recorded.

All applicable controls are necessary. The order is fixed by the locked manifest; this contract does not reorder it.

**Operative rules:**

- **Scope.** The quarantine and release control applies to responses from MCP servers that are untrusted or unknown per `runtime/tool-manifest.md` v1.5 §7.3. Trusted-server responses remain subject to any other applicable policy in the locked contracts; this contract does not expand or reduce their handling.
- **Quarantine.** A response from an untrusted or unknown MCP server is held outside model reasoning context. It MUST NOT be supplied to the model's reasoning path until the step 11(b) release decision, the step 12 redaction gate, and every other applicable control have all been satisfied.
- **Redaction success is necessary but not sufficient.** Where redaction is required by policy, successful redaction is a precondition to entry into model reasoning context; but successful redaction alone does not authorize entry. The step 11(b) release decision is separately required.
- **Operator release approval is not a substitute for redaction.** A step 11(b) decision to release does not waive any required redaction under §3, §4, or §5. A release does not make the response authoritative instruction and does not authorize raw-output writes to canonical artifacts.
- **Failure of any control blocks the effect.** If redaction cannot be established (§5), the response cannot enter model reasoning context. If the step 11(b) release decision has not been recorded, the response remains quarantined regardless of redaction outcome.

**Resulting concrete invariant.** Under the locked sequence, "operator approval recorded at step 11(b)" does **not** by itself permit entry into model reasoning context. Entry is only permitted when the step 11(b) release decision has been recorded **and** the step 12 redaction gate has been satisfied **and** every other applicable control has passed. This candidate states the sequence exactly as the locked manifest defines it and does not characterize it as undefined.

### 6.3 Logging constraint for quarantined responses

Per `runtime/tool-manifest.md` v1.5 §7.3 and `architecture/agent-security.md` §5.2 and §12:

- The observability log MAY record the untrusted MCP server's identity, the non-content request/response metadata required to audit the call, the quarantine decision, and the step 11(b) release-decision outcome.
- **Raw request/response bodies and any other untrusted content MUST NOT be placed in the observability log.** The reviewable request/response record consists of non-content audit metadata, not raw bodies. This reconciles the observability expectation in `architecture/agent-security.md` §8.2 with the logging constraint in `runtime/tool-manifest.md` v1.5 §7.3.
- The log is operator-facing and is not readable by the model in normal operation.

This contract does not weaken or reinterpret these constraints. It records only that they apply to the quarantine path as well.

### 6.4 No second invocation prompt

This contract does not introduce a second operator **invocation** prompt. The single pre-invocation authorization prompt is owned by `runtime/tool-manifest.md` v1.5 §3.5 step 11(a) and is exactly one prompt per invocation when the effective approval class requires it.

The post-response release decision described in §6.2 is a **separate control referenced under the same numbered step 11(b)**. It is:
- not the pre-invocation authorization prompt;
- not satisfied by the pre-invocation authorization prompt;
- not a second invocation prompt;
- a decision about the returned response, recorded only after the call returns.

The fact that both controls are referenced under the same numbered section in the locked manifest does not merge them. This contract preserves the manifest's structure exactly: one invocation prompt, one separate post-response release control, and the step 12 redaction gate.

### 6.5 Safe audit metadata

The following are safe to log (subject to the operator log being operator-facing per `agent-security.md` §12):

- `registry_id` of the tool;
- invocation correlation ID;
- redaction processing outcome (`success` / `failure`);
- on failure: the failure category from §5.3;
- aggregated category counts on success (e.g. "N `BEARER_TOKEN` occurrences redacted; M `SESSION_COOKIE` occurrences redacted");
- whether round-trip placeholders were issued;
- whether restoration was permitted under §4.4.2 for a given occurrence (permitted / not permitted), without recording the original value;
- whether the response was quarantined (untrusted/unknown MCP case only);
- the step 11(b) release-decision outcome (approved / not approved) for a quarantined response;
- timestamps;
- whether the output crossed a protected boundary.

The following MUST NOT be logged:

- any raw sensitive value;
- any full raw tool output;
- the local-only map;
- any error message that embeds a raw secret;
- any partial redacted output that still contains a matched raw secret in a field not covered by the redaction rules;
- raw request/response bodies or other untrusted content from a quarantined MCP response;
- tier-1 secrets of any kind.

### 6.6 Correlation

Every audit metadata record SHOULD carry a correlation ID that ties the redaction processing to the invocation that produced the output and, where applicable, to the quarantine decision and the step 11(b) release-decision outcome. Correlation is used for post-hoc analysis of redaction and quarantine behavior, not for releasing the raw output or the local-only map.

### 6.7 Ordering of the release decision and the redaction gate

The ordering is fixed by the locked `runtime/tool-manifest.md` v1.5 §3.5: the step 11(b) post-response release decision is recorded after the call returns; the redaction fail-closed check on the output leg is step 12. This contract reflects that sequence and does not treat it as undefined.

The **criteria** for permitted inbound restoration are defined in §4.4.2 by Owner Decision A (2026-10-13). The **implementation mechanism** that enforces those criteria at runtime remains deferred (§7.2, §9.2) and is an implementation concern, not an ordering concern.

---

## 7. Configuration and Extensibility

### 7.1 Policy requirements (fixed by this contract)

The following MUST be preserved when adding categories, patterns, or formats:

- the fail-closed behavior in §5 for `redaction_required: true` tools;
- the outbound redaction requirement in §3.2 and §5.5;
- the invocation-scoped, local-only map in §4.2;
- the prohibition on automatic restoration in free-form text and in untrusted/unknown MCP responses (§4.4.1);
- the constrained §4.4.2 criteria for permitted local-slot restoration;
- the separation between the step 11(a) pre-invocation authorization prompt and the step 11(b) post-response release decision;
- the post-response quarantine and release-decision control in §6.2, following the source-fixed step 11 → step 12 sequence;
- the prohibition on copying raw secrets into labels, placeholders, errors, logs, or diagnostics (§4.9, §5.7);
- the six-stage separation in §6.1;
- the safe-audit-metadata rule in §6.5;
- the logging constraint on quarantined responses in §6.3.

### 7.2 Implementation/configuration details (deferred)

The following are implementation details not fixed by this contract:

- the exact pattern library used for pattern-anchored detection;
- the exact heuristics for high-entropy detection;
- the exact parser used for structured inputs;
- the exact list of sensitive key names;
- the exact length or entropy thresholds;
- the exact format of correlation IDs;
- the exact generation mechanism for opaque placeholder tokens;
- the exact storage and lifecycle mechanism for the invocation-scoped map;
- the exact mechanism by which the runtime associates a quarantined response with the step 11(b) release decision;
- **the implementation mechanism that enforces the §4.4.2 restoration criteria** — how the runtime declares, tracks, and verifies locally authorized slots, and how it enforces the invocation binding and full-field-match requirements. The **criteria** themselves are defined in §4.4.2 by Owner Decision A (2026-10-13) and are not deferred.

### 7.3 Extending the inventory

New categories or patterns may be added as proposed work by:

1. extending §2.2 with a new category ID and its detection band;
2. updating §10 test matrix with at least one case per new category;
3. documenting the change in a future revision of this document.

**No new category is added silently.** An addition that weakens fail-closed behavior for any existing category requires an explicit decision and a revision of this contract.

### 7.4 No invented configuration files

This contract does not name an existing configuration file, implementation registry, or environment allowlist for redaction. If a future mechanism is needed (e.g. a pattern registry, a per-environment secret inventory), it is proposed work and recorded as an OPEN GAP (§9) rather than declared as existing.

---

## 8. Failure Codes and Cross-References

### 8.1 Reused code

| Code | Meaning | Source |
|---|---|---|
| `redaction_unavailable` | The redaction requirement could not be satisfied on the output leg; release is refused. | `runtime/tool-manifest.md` v1.5 §6.3.I |

This contract does not define new refusal codes. If, during implementation, a failure mode requires a distinct code not covered by the existing set, that code will be proposed in a future revision and reconciled with `runtime/tool-manifest.md` §6.3 before being referenced anywhere.

### 8.2 Cross-references

- `runtime/tool-manifest.md` v1.5 — defines `redaction_required` (per tool), the single pre-invocation authorization prompt at §3.5 step 11(a), the separate post-response release decision referenced under §3.5 step 11(b), the output-leg redaction fail-closed check at §3.5 step 12, the `redaction_unavailable` code (§6.3.I), the untrusted-MCP invocation rule (§7.3), and the logging constraint at §7.3.
- `architecture/agent-security.md` §7 — defines the secret-exposure threat (T6), the redaction principle, and the boundary types that are redacted.
- `architecture/agent-security.md` §7.2 — locked; this contract consumes **Owner Decision A (2026-10-13)** as a constrained interpretation of that section, not as an amendment to it.
- `architecture/agent-security.md` §8.2 — defines the untrusted MCP response quarantine and the operator-approved release requirement.
- `architecture/agent-security.md` §3 — defines the trust tiers this contract references.
- `architecture/file-contracts.md` §4.2 — defines the runtime contract per-type boundaries; this file respects them.

This contract does not redefine anything owned by those files.

### 8.3 Outbound redaction code integration (pending)

Outbound redaction failure for external model/MCP/third-party data is a distinct condition from the output-leg `redaction_unavailable` refusal. This contract:

- preserves `redaction_unavailable` with its existing output-leg meaning;
- requires outbound failure to block dispatch;
- does not assign a new code;
- records that any code integration requiring a distinct outbound failure code is a future versioned contract decision.

### 8.4 Quarantine/release control code integration (pending)

The post-response quarantine and step 11(b) release-decision control in §6.2 is a policy statement; this contract does not assign a new failure code for it. If a distinct code is later required to represent "quarantined, release not yet approved" or "step 11(b) recorded, step 12 not satisfied," that integration requires a future versioned contract decision and is explicitly left OPEN.

### 8.5 Inbound restoration criterion failure codes (pending)

The §4.4.2 criteria are policy statements; this contract does not assign new failure codes for their individual failure modes. If a distinct code is later required for "restoration refused: criterion not satisfied," that integration requires a future versioned contract decision and is explicitly left OPEN.

---

## 9. Open GAPs, Owner Decisions, and Limitations

### 9.1 Preserved OPEN GAPs

- **GAP-AS-02** (redaction protocol/implementation) — remains OPEN. This contract specifies policy; it does not implement detection, parsing, transformation, mapping, restoration, quarantine, or release.
- **GAP-AS-08** (canonical secret inventory) — remains OPEN. §2.2 proposes categories; the canonical inventory for any given deployment is not fixed here.
- **GAP-TM-17** (fail-closed redaction in all failure modes) — remains OPEN. §5 specifies the policy; the runtime enforcement mechanism is deferred.
- **GAP-TM-11** (definition integrity) — remains OPEN. While OPEN, all tool invocations remain refused per `runtime/tool-manifest.md` §6.6.

### 9.2 Owner Decision A — constrained restoration interpretation (2026-10-13)

**Status:** Recorded owner decision. Not a registered project GAP. Not an amendment to any locked source.

**Decision.** The project owner has recorded a constrained interpretation of `architecture/agent-security.md` §7.2, defining the criteria for permitted local restoration of placeholders. The full criteria are stated in §4.4.2.

**What is resolved.**

- The criteria that distinguish a locally authorized restoration slot from ordinary returned content: pre-declaration, invocation binding, structured locally authored location, exact full-field match, valid map (§4.4.2).
- The prohibition on automatic restoration in free-form text and in untrusted/unknown MCP responses (§4.4.1).
- The interaction of restoration with the quarantine/release control in §6.2: restoration does not authorize entry into model reasoning context for an untrusted response.

**What remains deferred.**

- The **implementation mechanism** that enforces §4.4.2's criteria at runtime. This contract does not prescribe how the runtime declares, tracks, and verifies slots, or how it enforces the invocation binding and full-field-match requirements. These are implementation details (see §7.2) and remain subject to a future implementation contract. Until implemented, the fail-closed behavior in §5.3 governs.

**Scope of the interpretation.** Owner Decision A is an interpretation of §7.2, not an amendment to `architecture/agent-security.md`. The locked source remains unchanged. If a future need arises to change §7.2 itself, that requires a separate versioned governance cycle for the locked architecture contract.

### 9.3 Other new proposed dependencies

- **Detection library composition** — the exact composition of pattern-anchored detection, contextual detection, and heuristics, and how they compose under structured parsing.
- **Structured input parser** — which parser is authoritative for JSON, form-encoded, XML, and other supported formats, and what happens when the parser disagrees with the transport representation.
- **Opaque token generation and map lifecycle** — the exact mechanism for generating non-stable opaque tokens and for storing, expiring, and discarding the invocation-scoped map.
- **Quarantine/release wiring** — the exact mechanism by which the runtime holds a quarantined response, records the step 11(b) release decision, and integrates it with the step 12 redaction gate.
- **Release-layer wiring** — where in the runtime the release decision is enforced (caller, boundary layer, or both), and how the enforcement is proven.
- **Audit log persistence and retention** — how long audit metadata is retained, at what sensitivity, and under what operator permissions.
- **Outbound redaction failure code** — if a distinct code is required for outbound redaction failure, it requires a future versioned contract decision with `runtime/tool-manifest.md`.
- **Quarantine/release failure code** — if a distinct code is required to represent "quarantined, release not yet approved" or "step 11(b) recorded, step 12 not satisfied," it likewise requires a future versioned contract decision with `runtime/tool-manifest.md`.
- **Inbound restoration enforcement mechanism** — the mechanism by which §4.4.2's criteria are enforced at runtime (see §9.2 deferred items).

These are recorded as proposed work, not as contracts.

### 9.4 Cross-dependency with `runtime/tool-manifest.md`

While `GAP-TM-11` is OPEN, no tool invocation reaches the redaction pipeline through the normal path because all invocations are refused at step 7 of `runtime/tool-manifest.md` §3.5. This contract therefore currently governs **policy text**, not operational behavior.

---

## 10. Test and Validation Matrix

Every test below is **`PROPOSED — NOT EXECUTED`**. No test in this section has been run against an implementation. The matrix specifies the intended behavior; it is a design artifact.

The "May output cross protected boundary?" column is **conditional on all applicable gates**. Where a protected boundary is the untrusted/unknown-MCP boundary, the answer is "Yes" only if the redaction gate (§5) and the step 11(b) release decision and the step 12 gate (§6.2), and every other applicable control, have passed. A "Yes" in this column never authorizes releasing an untrusted MCP response into model reasoning context merely because redaction succeeded.

| ID | Input shape / condition | Expected output or failure result | May output cross protected boundary (conditional on all gates)? | Security invariant being tested |
|---|---|---|---|---|
| T-01 | Plain text containing a recognizable password value. | Matched value replaced with a round-trip placeholder or category label. | Yes, subject to applicable gates. | `CREDENTIAL` pattern-anchored detection and replacement. |
| T-02 | `Authorization: Bearer <JWT-shaped value>` header. | Value replaced with `[REDACTED:AUTHORIZATION_HEADER:<opaque>]` or `[REDACTED:AUTHORIZATION_HEADER]`; header name preserved. | Yes, subject to applicable gates. | `AUTHORIZATION_HEADER` + `BEARER_TOKEN` specificity. |
| T-03 | URL with `?access_token=...&user=alice`. | Token value replaced; `user` value preserved. | Yes, subject to applicable gates. | `SENSITIVE_QUERY_PARAM` handling without losing non-sensitive context. |
| T-04 | Nested JSON with `user.password` and `user.tokens[0].value`. | Both values replaced; structure preserved. | Yes, subject to applicable gates. | Recursive structured redaction. |
| T-05 | Response contains `api_key` and `session_id` values. | Both replaced with their respective category labels. | Yes, subject to applicable gates. | Multi-category response handling. |
| T-06 | Response contains the same token value three times. | All three occurrences replaced independently with unique invocation-scoped placeholders. | Yes, subject to applicable gates. | Repeated-occurrence handling. |
| T-07 | A long text value embeds a secret substring among benign prose. | Substring replaced; surrounding prose preserved. | Yes, subject to applicable gates. | Substring matching in plain text. |
| T-08 | A benign string that resembles a token but is not one (e.g. a documentation example). | Conservatively replaced; category count reflects it. | Yes, subject to applicable gates. | Conservative default; FP tolerance. |
| T-09 | Malformed JSON. | Release refused; `redaction_unavailable` on output leg. | No. | Fail-closed on malformed structured input. |
| T-10 | Unsupported encoding (compressed body). | Release refused; `redaction_unavailable` on output leg. | No. | Fail-closed on unsupported input. |
| T-11 | A required detector raises an error or times out. | Release refused; `redaction_unavailable` on output leg. | No. | Fail-closed on detector failure. |
| T-12 | Truncated response body. | Release refused; `redaction_unavailable` on output leg. | No. | Partial-output fail-closed. |
| T-13 | One processing stage returns uncertain coverage/completeness. | Release refused; `redaction_unavailable` on output leg. | No. | Uncertainty about pipeline completion fail-closed. |
| T-14 | An exception message embeds a raw secret. | Exception rewritten or suppressed; raw secret not emitted. | No for the raw secret. | Diagnostics must not expose secrets. |
| T-15 | `redaction_required: true` and the implementation is absent. | Release refused; `redaction_unavailable` on output leg. | No. | Absent-implementation fail-closed. |
| T-16 | Successful redaction of a full response before external release. | Redacted output released to the applicable boundary; audit metadata records category counts. | Yes, subject to applicable gates. Redaction success alone does not authorize entry of an untrusted MCP response into model reasoning context. | Successful outbound path. |
| T-17 | Processing succeeds initially, a later required stage fails. | Release refused; `redaction_unavailable` on output leg. | No. | Partial-stage fail-closed. |
| T-18 | Instruction-like text alongside secrets in untrusted content. **Cross-contract integration test.** | This test is a cross-contract integration test for the instruction/data-handling invariant owned by `architecture/agent-security.md`. This contract's scope for this test is limited to: secrets are replaced on the outbound path. The invariant "instruction-like text is preserved as data and no instruction is followed" is owned by the trust/instruction-handling layer and is not proved by the redaction transform alone. | Per `architecture/agent-security.md`. Redaction alone does not authorize entry into model reasoning context for an untrusted response. | Cross-contract integration: outbound secret transformation (this contract) + instruction/data-handling (`agent-security.md`). |
| T-19 | Deeply nested arrays/objects with repeated structured secret fields. | All occurrences replaced; structure preserved. | Yes, subject to applicable gates. | Nested/repeated structured handling. |
| T-20 | Audit metadata emitted for a successful redaction. | Metadata contains category counts, outcome, correlation ID, timestamps; contains no raw secret and no map. | Yes (the metadata only). | Audit-metadata safety. |
| T-21 | Two different secrets in one invocation sent to an external model. | Each receives a unique invocation-scoped opaque placeholder; local-only map stores both mappings. | Yes, placeholders only. | Separate secrets in one invocation. |
| T-22 | External system returns the exact placeholders issued by the same invocation inside a slot that satisfies all §4.4.2 criteria. | Restoration is permitted only inside that slot. Otherwise no restoration. | Local slot only; subject to applicable gates. | Restoration is restricted to locally authorized slots meeting all §4.4.2 criteria. |
| T-23 | External system returns an unknown or forged placeholder. | Placeholder is not restored; fail closed before applying the affected response to local state. | No. | Unknown/forged placeholder is not restored. |
| T-24 | External system returns a placeholder that was modified or malformed. | Placeholder is not restored; fail closed before applying the affected response to local state. | No. | Changed/malformed placeholder is not restored. |
| T-25 | Local-only map is missing, corrupt, or mismatched. | Fail closed before applying the affected response to local state. | No. | Missing mapping fails closed (criterion 5). |
| T-26 | Round-trip processing to an external model. | The map and raw values are not sent externally and are not logged. | Yes, placeholders only. | No map/raw values sent or logged. |
| T-27 | Tool output with `redaction_required: true` and redaction cannot be proven. | Output must not cross external boundary; `redaction_unavailable` on output leg. | No. | Output-leg fail-closed semantics. |
| T-28 | Outbound data to an external model/MCP/third-party tool with `redaction_required: false`. | Outbound redaction is still required by `agent-security.md` §7.2; failure blocks dispatch. | No if outbound redaction fails. | `redaction_required` does not waive outbound protection. |
| T-29 | Concept, memory lesson, and Skill revision destination write paths. | Raw tier-3 output is not written; redaction occurs before crossing the applicable protected write boundary; destination tiers remain Concept = tier 3, memory lesson = tier 2, Skill revision = tier 1. | Only derived, authorized artifacts. | Trust-tier destination correctness. |
| T-30 | Inventory contains `TARGET_IDENTIFIER`, `INTERNAL_HOST_IP`, `CUSTOMER_ACCOUNT_ID`, `WEBHOOK`, `INTERNAL_SERVICE_URL`, `PROXY_HISTORY_IDENTIFIER`, `THIRD_PARTY_IDENTIFIER`. | Each is replaced with its category label or round-trip placeholder on the outbound path. | Yes, subject to applicable gates. | Inventory category mapping completeness. |
| T-31 | Low-confidence individual match. | Conservatively redacted. | Yes, subject to applicable gates. | Low-confidence individual match behavior. |
| T-32 | Uncertain processing completeness/coverage. | Fail closed; `redaction_unavailable` on output leg. | No. | Processing uncertainty fails closed. |
| T-33 | Declared outbound pipeline completes all required stages successfully. | Success is recorded as completion of the declared pipeline, not universal absence of secrets. | Yes, subject to applicable gates. | Pipeline-success criteria. |
| T-34 | Declared pipeline cannot prove all required stages completed. | Fail closed; `redaction_unavailable` on output leg. | No. | Inability to prove completion fails closed. |
| T-35 | Untrusted MCP server returns a response. Redaction succeeds. Operator has not yet recorded a step 11(b) release decision. Pre-invocation authorization prompt (step 11(a)) may or may not have occurred; it does not substitute for step 11(b). | Response remains quarantined; it does not enter model reasoning context. | No. | Step 11(a) pre-invocation authorization does not satisfy step 11(b) post-response release. Redaction success alone does not authorize release. |
| T-36 | Untrusted MCP server returns a response. Redaction cannot be established. Operator recorded a step 11(b) release decision. | Step 12 redaction gate fails; the response MUST NOT enter model reasoning context. | No. | Step 11(b) release decision does not waive the step-12 redaction gate. |
| T-37 | Untrusted MCP server returns a response. Operator recorded a step 11(b) release decision. Step 12 redaction gate succeeded. Every other applicable control passed. | Response may enter model reasoning context in its redacted form. | Yes, only after step 11(b), step 12, and every other applicable control have all passed. Both are necessary; neither substitutes for the other. | The step 11(b) post-response release and the step 12 redaction gate are independent and both required. |
| T-38 | Trusted MCP server returns a response. | This contract's §6.2 quarantine/release control does not apply; any other applicable policy in the locked contracts governs. | Per applicable locked contracts. | Scope of the quarantine control is untrusted/unknown MCP responses only. |
| T-39 | Audit metadata emitted for a quarantined untrusted MCP response. | Metadata records server identity and non-content audit fields, quarantine decision, and the step 11(b) release-decision outcome; contains no raw request/response body or other untrusted content. | Yes (the metadata only). | §6.3 logging constraint. |
| T-40 | External response echoes a valid, unmodified placeholder (a) inside free-form text and (b) inside a field not satisfying §4.4.2. | The raw mapped secret MUST NOT be restored into either location. Handling fails closed for that occurrence; the affected returned content is not applied to local state as if safely handled. | No, for the echoed occurrences. | Automatic restoration in free-form and non-authorized content is prohibited (§4.4.1). |
| T-41 | External response echoes a valid, unmodified placeholder inside a slot that satisfies all §4.4.2 criteria (pre-declared, invocation-bound, structured locally authored, exact full-field match, valid map). | Restoration permitted only inside that slot, subject to §4.4.3. | Local slot only; subject to applicable gates. | Restoration is bounded by §4.4.2 criteria (Owner Decision A). |
| T-42 | External response echoes a valid placeholder in a field that fails exactly one §4.4.2 criterion (e.g. slot declared for a different invocation, or partial match, or a field whose identity was chosen by the external party). | No restoration; fail closed for that occurrence. | No, for that occurrence. | Each §4.4.2 criterion is independently necessary. |
| T-43 | Slot declared by invocation X, placeholder issued by invocation Y; response returns Y's placeholder into X's slot. | No restoration; fail closed (criterion 2 — invocation binding). | No. | Invocation binding is enforced. |
| T-44 | Slot declared for field A, response returns the placeholder embedded in field B (a field the external party chose). | No restoration; fail closed (criteria 1 and 3). | No. | Pre-declaration and structured locally authored location are enforced. |
| T-45 | Untrusted MCP server returns a response. Step 11(a) pre-invocation prompt was issued and answered before the call. Operator has not recorded a step 11(b) release decision. | The step 11(a) pre-invocation prompt does not constitute step 11(b) release. Response remains quarantined. | No. | Step 11(a) and step 11(b) are distinct controls; one does not satisfy the other. |

---

## 11. Cross-Contract Consistency Review

### 11.1 Against `runtime/tool-manifest.md` v1.5

- **`redaction_required` field** — respected; §3.2 distinguishes the manifest output-leg flag from the separate outbound redaction requirement. **SATISFIED (against supplied content; repository state NOT VERIFIED).**
- **`redaction_unavailable` code** — reused; §5.4 and §8.1 do not redefine it. **SATISFIED (against supplied content).**
- **Fail-closed redaction on output leg** — respected; §5.6 aligns with tool-manifest §3.5 step 12. **SATISFIED (against supplied content).**
- **Single pre-invocation authorization prompt (step 11(a))** — respected; §6.1, §6.2, §6.4 do not add a second invocation prompt. **SATISFIED (against supplied content).**
- **Post-response release decision (step 11(b))** — distinguished from step 11(a); §6.2, §6.4, and T-35, T-45 state the two controls are distinct. **SATISFIED (against supplied content).**
- **Source-fixed ordering of step 11 → step 12** — reflected; §6.2, §6.7, and T-35–T-37 describe the sequence as the locked manifest defines it. **SATISFIED (against supplied content).**
- **Untrusted/unknown MCP rule** — respected; §6.2 applies the manifest §7.3 per-call rule and the step 11 → step 12 sequence. **SATISFIED (against supplied content).**
- **`GAP-TM-11` default refusal** — respected; §9.4 acknowledges the interaction. **SATISFIED (against supplied content).**
- **Outbound redaction failure code integration** — not defined here; left explicit in §8.3. **NOT VERIFIED / OPEN pending future contract decision.**
- **Quarantine/release failure code integration** — not defined here; left explicit in §8.4. **NOT VERIFIED / OPEN pending future contract decision.**
- **Inbound restoration criterion failure codes** — not defined here; left explicit in §8.5. **NOT VERIFIED / OPEN pending future contract decision.**

### 11.2 Against `architecture/agent-security.md`

- **Secret categories (T6)** — respected; §2.2 maps the §7.1–7.3 items to category IDs. **SATISFIED (against supplied content).**
- **Redaction principle (local → external)** — respected; §3.1 and §4.1–§4.3 define the outbound transformation. Inbound handling is bounded by §4.4 under Owner Decision A. **SATISFIED (against supplied content).**
- **§7.2 round-trip restoration requirement** — this contract consumes **Owner Decision A (2026-10-13)** as a constrained interpretation of §7.2. The source text of §7.2 is not amended. **SATISFIED VIA OWNER DECISION A (not as source-verbatim criteria).**
- **Boundary types redacted** — referenced and mapped; §2.2 and §2.3 cite §7.1–7.3, with the §7.3 condition on the target real domain preserved. **SATISFIED (against supplied content).**
- **Trust tiers** — §3.1 states Concept = tier 3, memory lesson = tier 2, Skill revision = tier 1. **SATISFIED (against supplied content).**
- **Untrusted MCP response quarantine (§8.2)** — preserved; §6.2 and §6.3. **SATISFIED (against supplied content).**
- **Operator-facing logs** — §6.3 and §6.5 align with §12, and reconcile §8.2's observability expectation with the manifest §7.3 logging constraint by clarifying that the reviewable record is non-content audit metadata. **SATISFIED (against supplied content).**
- **Cross-reference is a pointer, not a transfer (§9)** — respected by this contract's cross-reference usage. **SATISFIED (against supplied content).**

### 11.3 Against `architecture/file-contracts.md` §4.2

- **Runtime contract per-type** — respected; this file does not claim ownership of tool inventory, model routing, or methodology. **SATISFIED (against supplied content).**

### 11.4 `NOT VERIFIED` items

- The actual repository state of `runtime/tool-manifest.md` v1.5 (LOCKED), `architecture/agent-security.md`, and `architecture/file-contracts.md` is not inspectable from this environment. All "SATISFIED" labels above refer only to the supplied content in this conversation and do not assert the repository matches the supplied versions.
- The provenance of **Owner Decision A (2026-10-13)** is not independently verified by this candidate. It is cited as recorded by the project owner; the candidate does not claim to be the source of that decision.
- No hash, timestamp, or byte-for-byte comparison has been performed.
- No runtime enforcement has been observed.
- No test in §10 has been executed.

---

**Status of this contract itself:** Lifecycle `Status: review` / Version `v1.2`; document/policy state **LOCKED** by explicit owner decision on 2026-10-13. This is not an implementation or production-runtime claim. All relevant GAPs remain OPEN. The runtime remains non-operational while `GAP-TM-11` is OPEN in `runtime/tool-manifest.md` v1.5. v1.0 and v1.1 remain FREEZE/unapproved; this lock does not unfreeze or promote either.
