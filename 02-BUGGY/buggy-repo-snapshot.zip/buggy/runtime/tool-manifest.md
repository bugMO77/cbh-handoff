# tool-manifest.md

> **Status:** LOCKED (v1.5 policy contract; runtime implementation incomplete)
> **Lock decision (2026-10-11):** Locked by explicit project-owner direction as the governing policy baseline for continuing Buggy work. This is a document/policy lock only: it does not claim runtime implementation, close any GAP, or authorize tool invocations while GAP-TM-11 remains OPEN.
> **Scope:** Defines the **operational policy** for Buggy's callable tools — which tools are enabled in which environment, which operations are sensitive and require approval, what the failure behavior is, how tool definitions are verified, and the interface to the MCP trust list. This is the canonical implementation site for the architectural security invariants in `agent-security.md` §5.
> **Authority:** Runtime contract (per `file-contracts.md` §4.2). Source of truth for: tool gating policy, approval, sensitive operations list, tool definition verification policy, failure behavior. Source of truth for tools is split: **inventory** (state, paths, verification) lives in `runtime/registry.json`; **policy** (sensitive, approval, failure) lives here.
> **Depends on:** `architecture/file-contracts.md` (root contract; §4.2 runtime contract per-type; lifecycle), `architecture/agent-architecture-rules.md` (Skill boundaries, model-routing reference), `architecture/agent-security.md` (security invariants: §5 tool integrity, §6 scope enforcement, §7 secret exposure, §8 MCP trust; the canonical source of the security principles this file operationalizes), `architecture/validation-model.md` (§8 Validator independence), `architecture/review-discipline.md` (Builder/Reviewer/Architect discipline for this file's authoring), `runtime/registry.json` **v0.7-rev2** (LOCKED / production — the inventory this policy governs).
> **Depended on by:** every Skill and Command that invokes a tool; the OpenCode loader (per `runtime/opencode/loader.md` when implemented); the OpenCode orchestrator (per `runtime/opencode/ORCHESTRATION.md` when implemented); any future `runtime/opencode/manifest.md` (machine-readable form of the same policy); the scope-check command (per `agent-security.md` §6.3); the validator skill (per `validation-model.md` §8).

> Source: This contract is established as the canonical implementation site for `agent-security.md` §5.1 (tool integrity), §5.3 (sensitive operations), and §8 (MCP trust interface). It integrates the locked Phase 1 contracts above and the LOCKED `runtime/registry.json` v0.7-rev2. It does not invent new security principles — every rule is grounded in an existing architectural invariant or in the operational needs surfaced by the v0.7-rev2 inventory.

> **Dependency-status note**: the header references `architecture/agent-security.md` as the source of security invariants. The copy available to the author of this manifest is `review v1.1`. If the authoritative repository version is not confirmed as LOCKED/production, this manifest's dependency status remains pending Architect confirmation. The manifest does not itself assert that `agent-security.md` is LOCKED; it treats the security invariants as authoritative and follows their content.

> **v1.1 change log** (correction pass per Reviewer verdict of 2026-10-08, CHANGES REQUIRED):
> - **#1 Verification integrity** — split `verification_requirement` into `capability_requirement` + `capability_relaxable`; definition integrity is now non-relaxable (no field controls it; the runtime's hash / schema check is always enforced).
> - **#2 MCP trust semantics** — unified "untrusted MCP server" behavior: per-call approval (per `agent-security.md` §8.2), not refuse. §6.2.5 and §6.3.D now read "escalate to operator" (not "refuse"); §7.3 is unchanged.
> - **#3 Hash storage** — removed the claim that canonical hashes live in `registry.json` v0.7 `verified_capabilities`. Storage location is now OPEN. Added `GAP-TM-11`.
> - **#4 Per-tool records** — added §3.4 (Default Policy by class) and §3.5 (Policy Resolution algorithm). The runtime is now **enforceable** without per-tool records; per-tool records are optional overrides.
> - **#5 Gating semantics** — replaced `enabled: bool` with `gating: enabled | gated | disabled`. This is the canonical gating field.
> - **#6 Environment defaults** — defined the default environment as `local-kali`; environment is an overlay, not a dependency. The file is enforceable without a defined environment.

> **v1.2 change log** (correction pass per second Reviewer verdict of 2026-10-08, CHANGES REQUIRED):
> - **#1 `gated` semantics** — `gated` is now a strict override: `gated` ALWAYS requires per-call approval regardless of `approval_class`. The "regardless of approval_class" wording in §3.2/§3.3 is restored and the resolution algorithm in §3.5 is updated to match. `gated + pre_approved` is no longer ambiguous; it is treated as `gated + per_call`.
> - **#2 MCP pre-approval clarity** — until GAP-AS-03 is resolved (trust list exists), **no pre-approval is allowed for untrusted MCP tools**. The trust list is the prerequisite for any "pre-approved" state. Pre-approval is **invocation authorization**, not **trust**. §7.3 and §4.4 S6 row updated.
> - **#3 Stale `verification_requirement` references** — replaced all remaining `verification_requirement` mentions in §6.2.3 and §6.3.B with `capability_requirement`.
> - **#4 Definition-integrity wording** — separated the **inherited security invariant** ("definition integrity MUST be enforced") from the **current capability** ("until GAP-TM-11 is closed, the hash check is a no-op; the runtime can only check existence, availability, and capability"). A tool is NOT considered integrity-verified merely by being in the registry. §3.3, §6.2, §6.4 updated.
> - **#5 `mcp_server_ref` ownership** — removed `mcp_server_ref` from the per-tool record (redundant with the registry's `provider` field). The registry's `provider` is the authoritative MCP server identity. §3.2, §3.3, §7 updated.
> - **#6 Operational readiness for 63 discovered tools** — added §3.6 characterizing the default as an **intentional secure default** (per the security invariant), with a documented operator path: per-tool override OR per-environment capability relaxation OR a verification pass on the runtime. The 63 tools are gated by design, not broken.
> - **#7 Builtin sensitivity defaults rechecked** — `read`, `glob`, `grep` are now `sensitive: false, approval_class: none, redaction_required: true` (read-only tools; the secret-exposure concern is handled by `redaction_required` at the output boundary, not by per-call approval). `write`/`edit` remain `sensitive: true, approval_class: per_call` (mutation). `shell`/`execute` remain `gated, sensitive: true, approval_class: per_call` (arbitrary execution). Each is now explicitly justified in §3.4.

> **v1.3 change log** (correction pass per third Reviewer verdict of 2026-10-09, CHANGES REQUIRED):
> - **B1 (gated resolution unification)** — the §3.5 algorithm now correctly enforces `gating: gated` as a strict per-call override. The "prompt if `approval_class: per_call` and no pre-approval" check is removed; instead, step 7 sets `effective_approval_class: per_call` whenever `gating: gated`, and step 9 prompts whenever `effective_approval_class: per_call`. `gated + pre_approved` produces per-call (no pre-approval can bypass). Also clarified: `gated` is a default that can be overridden by an explicit per-tool record (changing to `enabled` or `disabled`), but when `gated`, the per-call rule is strict.
> - **B2 (disabled + scope_dependency in algorithm)** — added explicit steps in §3.5: step 4 checks `gating: disabled` (refuse with `gating_disabled`, §6.3 E); step 5 checks `scope_dependency: target_scope_required` (refuse with `scope_unverifiable` if scope.md is missing, §6.3 F; refuse with `out_of_scope` if out of scope, §6.3 G). The algorithm is no longer silent on these checks.
> - **B3 (definition integrity invariant actually enforced)** — added §3.6.2 "Temporary Integrity Exception". The 6 currently-invokable tools operate under an explicit, time-bound, logged, Architect-authorized exception (tracked as `GAP-TM-13`). Without the exception, the runtime refuses all invocations. The v1.2 wording "6 tools can be invoked under the default policy" was misleading; v1.3 corrects this.
> - **B4 (sensitive operation approval cannot be downgraded)** — added step 8 in §3.5: a per-tool record or environment override that attempts to set `approval_class: none` (or anything below the §4.4 minimum) for a sensitive operation (S1–S12) is refused with `approval_downgrade_denied` (§6.3 H), and the runtime falls back to the §4.4 minimum for that class. The §4.4 table is now an **enforcement constraint**, not a recommendation.
> - **B5 (fail-closed redaction)** — added step 10 in §3.5: if `redaction_required: true` and `runtime/redaction.md` is not implemented (GAP-AS-02), the tool's output MUST NOT cross any external boundary (fail-closed). The refuse reason is `redaction_unavailable` (§6.3 I) on the **output leg**, not the input leg. The tool call may proceed; the output handling is fail-closed.
> - **B6 (verification path respects registry versioning)** — the §3.6 verification lifecycle now produces a **new `runtime/registry.json` version** (e.g. v0.8) instead of modifying v0.7 in place. v0.7 is LOCKED; the lifecycle is "versioned, append-or-revise" per `file-contracts.md` §4.2.
> - **B7 (per-tool records consistently optional)** — clarified across §2.1, §4.3, §12, and `GAP-TM-01` that per-tool records are **optional overrides**; the runtime is enforceable with class-level defaults alone. The mandatory/optional contradiction is resolved.
> - **M1 (verification cadence split)** — §6.5 now explicitly separates per-invocation checks (§6.2, run on every call) from lifecycle checks (§6.5.2, run at session start / registry change / MCP restart). The lifecycle pass does not include §6.2.4 (hash) because the mechanism is not implemented; this is explicit.
> - **M2 (refuse reason codes E–I)** — added new codes `gating_disabled` (E), `scope_unverifiable` (F), `out_of_scope` (G), `approval_downgrade_denied` (H), `redaction_unavailable` (I). Also separated `unavailable` (B') from `not_in_registry` (A) for auditability.
> - **M3 (GAP-TM-10 status field)** — corrected from "OPEN TODO" to "SUPERSEDED" to match the text body.

> **v1.4 change log** (correction pass per fourth Reviewer verdict of 2026-10-10, CHANGES REQUIRED):
> - **B1 (reframed integrity — removed temporary exception)** — the v1.3 "Temporary Integrity Exception" (§3.6.2, GAP-TM-13) was rejected by the Architect because it conflicts with the non-relaxable §6.4.1 invariant. v1.4 removes the exception entirely. The manifest's default is now: **while GAP-TM-11 is OPEN, refuse ALL invocations**. No exception is granted by this file. Any exception requires a separate architecture revision pass and is tracked OUTSIDE this file. Added §6.6 "Integrity Default Refusal" and a new §3.5 step 6a "Integrity Eligibility" that runs BEFORE the approval prompt. The 6 previously-invokable tools are now refused by default. Updated simulations a, b, c, g, h, k to reflect the new default.
> - **B2 (destination check on every network operation)** — added `network_capable: bool` field to per-tool record. The new §3.5 step 6b "Destination Check" runs BEFORE the approval prompt and verifies the actual destination of the network call against `testing/<target>/scope.md`. If the destination is out of scope or cannot be verified, the call is refused with `destination_unverifiable` (new code K) or `out_of_scope` (existing G). Default policy updated: all network-capable tools (CLI, MCP, shell, execute, webfetch, websearch, browser) get `network_capable: true`. Read-only file tools get `network_capable: false`. S10 clarified as "out-of-scope egress" not "all network activity".
> - **B3 (unified MCP authorization)** — the v1.3 algorithm had two separate prompts for MCP tools: (i) MCP trust escalation (step 6) and (ii) per-call due to `gated` (step 9). v1.4 merges these into ONE pre-invocation authorization decision (new step 8 "MCP Authorization"). The post-response release (tier 3 → model context) stays as a separate control per `agent-security.md` §8.2 / §7.3. Clarified: `gated` is overridable by per-tool record, but a per-tool record cannot grant `pre_approved` for an MCP tool unless the server is on the trust list.
> - **B4 (approval downgrade is policy error, not call refusal)** — `approval_downgrade_denied` (H) is now defined as: a policy error (the override is invalid). The runtime logs the error, then applies the §4.4 minimum. The call can proceed under the §4.4 minimum if approval is given. This is consistent with simulation i and §6.3 row H. The override is rejected; the call continues under the corrected policy.
> - **B5 (fail-closed redaction in all failure modes)** — §3.5 step 10 extended: fail-closed when "redaction success cannot be proven", which covers: redaction mechanism absent, redaction fails, redaction times out, redaction returns partial/uncertain output, redaction cannot process the type. The output MUST NOT cross any external boundary in any of these cases.

> **v1.5 change log (first pass)**: **(R1)** registry reference updated to `v0.7-rev2` and current-state counts corrected. **(R2)** §7.3 MCP observability logging is metadata-only. **(R3)** §4.4 S6 row aligned with §7.4. **(R4)** `network_capable` semantics clarified + `egress_class` field added. **(R5)** §3.4 CLI classes split into behavioral classes. **(R6)** §3.5 preface step labels corrected; §6.5.1 `integrity_state: exception` removed; §6.6 clarified first-failed-check rule; simulations corrected; §3.6.2 relabeled explanatory history.

> **v1.5 change log (second pass)**: **(TMV15-R1)** S5 external-egress approval corrected (`cli-passive-source`, `cli-archive`, `builtin-websearch` → `sensitive: true, approval_class: per_call`). **(TMV15-R2)** `egress_class` renamed to `egress_class_default`; per-invocation classification added. **(TMV15-R3)** §3.6.1 rewritten: capability overrides cannot bypass integrity refusal. **(TMV15-R4)** §4.3 clarified as S1–S12 annotation, not an override of `sensitive`. **(TMV15-R5)** full v1.1–v1.4 changelog blocks restored verbatim.

> **v1.5 change log (third pass)**: **(TMV15-R2 corrected)** §3.5.2 no longer auto-classifies an out-of-scope destination as `external`. Out-of-scope destinations are refused with `out_of_scope`; `external`/`research` require independently-established external-service intent; ambiguous cases fail closed with `destination_unverifiable`. Browser subrequests classified individually. Simulation `m` corrected. **(TMV15-R6)** §3.5 step ordering fixed: sensitive-operation approval floor resolved BEFORE the authorization prompt; MCP trust status recorded without prompting; exactly one authorization prompt for MCP tools; step 11 no longer duplicates. §6.2.5 and §6.3.J aligned. Post-response quarantine/release unchanged.

> **v1.5 change log (fourth pass — this pass)**: **(R7)** §3.5.2 `builtin-shell` and `builtin-execute` no longer classify `none` merely from absence of a recognized network verb/signature. `none` requires positively-established local-only behavior; otherwise fail closed with `destination_unverifiable`. Updated simulation `q`; added counterexample simulation `v` (interpreter-based network access). **(R8)** §3.5 step 9 now normalizes the effective approval class to `per_call` when final `gating: gated` OR when the MCP server is untrusted/unknown, regardless of `approval_class` overrides. Prompt content and audit record show the normalized effective class. Added hypothetical simulations `w` (gated + none) and `x` (untrusted MCP + pre_approved). **(R9)** §3.5 step 9 and §4.4 distinguish: (a) default approval class, (b) unconditional floor, (c) narrowly permitted exception. S5 exception limited to specifically named/configured external services; S12 exception limited to short well-scoped background work; S6 state-mutating MCP tools require per-call approval **regardless of trust-list status** (rule restored verbatim from the v1.5 second-pass baseline). S10 remains prohibited. **(Redirect handling)** §3.5.2 `builtin-webfetch` requires every redirect hop to be classified before the follow-up request; if redirect inspection is unavailable, automatic redirects must be blocked or the invocation must fail closed. Added GAP-TM-22 (redirect inspection) and simulation `u` (in-scope URL redirecting to out-of-scope host). Restored policy text and GAP descriptions from the v1.5 second-pass baseline that were edited in the third pass.
>
> **v1.5 change log (final bounded correction pass)**:
> - **(F6-R1)** §3.5 step 8c now requires a fresh full-destination scope check for every follow-up request before authorization coverage is evaluated. Scheme/host/port matching never substitutes for path/resource-aware scope evaluation.
> - **(F6-R2)** §3.5 step 8c distinguishes initial authorization from per-hop classification, scope membership, and authorization coverage. Egress-class changes are refused unless the exact hop is already explicitly covered or a valid, identity-verified S5 pre-approval exception covers that exact external/research service.
> - **(F5-R1)** §3.5 step 9 defines the ordering `none < pre_approved < per_call`, records MCP trust status before the prompt, and normalizes S5/S12 to `per_call` when their narrow exception is not fully satisfied, including both `none` and `pre_approved` candidates.
> - **(F5-R3)** §3.5.2 now includes redirects, crawler-discovered links, browser subrequests, and other follow-up network requests. Interception and normalization dependencies remain OPEN and fail closed until implemented.
> - **(F6-R3)** The complete candidate and a machine-generated unified diff are produced from the actual fourth-pass baseline available in this workspace. Historical changelogs from earlier external baselines are not claimed to have been independently byte-verified.
> - **(Proactive consistency audit)** Added explicit simulation coverage for same-host path scope violations, authorization coverage failures, cross-class hops, unavailable per-hop inspection, and ambiguous destination normalization. Added GAP-TM-23 through GAP-TM-26; all remain OPEN.


---

## 1. Purpose

This contract defines:

- the **manifest structure** — what fields a tool record has and their semantics
- the **sensitive operations list** — the canonical enumeration of operations that require approval (operationalizes `agent-security.md` §5.3)
- the **pre-approval policy** — which sensitive operations require per-call approval vs. which can be pre-approved by environment configuration (completes GAP-AS-01 specification)
- the **failure behavior** — what the runtime does when a tool times out, errors, returns partial output, or refuses
- the **tool definition verification policy** — how tool definitions are checked before invocation (operationalizes `agent-security.md` §5.1)
- the **MCP server trust interface** — how this file references the future MCP trust list (per `agent-security.md` §8; the mechanism is GAP-AS-03)
- the **environment configuration model** — how enable/disable is set per environment

This contract does **NOT** define:

- the inventory of tools — lives in `runtime/registry.json` v0.7-rev2
- the redaction protocol — lives in `runtime/redaction.md`, deferred per GAP-AS-02
- the MCP trust list mechanism — lives in `runtime/opencode/ORCHESTRATION.md` or `runtime/mcp-trust.md`, deferred per GAP-AS-03
- the scope enforcement proxy layer — lives in `runtime/opencode/ORCHESTRATION.md` when implemented, deferred per GAP-AS-06
- the redaction inventory — lives in `runtime/redaction.md`, deferred per GAP-AS-08
- methodology, scoring, run output, finding content (forbidden by `file-contracts.md` §4.2)

---

## 2. Authority and Ownership

### 2.1 What this file IS authoritative for

1. **Sensitive operations list** — canonical enumeration. Proposes resolution of GAP-AS-01.
2. **Pre-approval policy** — per-environment rule.
3. **Failure behavior per tool class**.
4. **Tool definition verification policy** — proposes resolution of GAP-AS-04.
5. **MCP server trust interface** (per GAP-AS-03).
6. **Environment configuration model**.
7. **The per-tool policy record** — **optional** override. The runtime is enforceable with class-level defaults (§3.4) alone.

### 2.2 What this file MUST NOT become authoritative for

1. ❌ **Tool inventory** — owned by `runtime/registry.json` v0.7-rev2.
2. ❌ **The MCP trust list itself** — owned by the future MCP trust list file (GAP-AS-03).
3. ❌ **The redaction protocol** — owned by `runtime/redaction.md` (GAP-AS-02).
4. ❌ **The scope enforcement proxy** — owned by `runtime/opencode/ORCHESTRATION.md` when implemented (GAP-AS-06).
5. ❌ **Operator prompts and approval flows** — owned by `runtime/opencode/ORCHESTRATION.md` when implemented.
6. ❌ **Methodology** — owned by Skills.
7. ❌ **Run output, finding content, target state** — owned by `testing/<target>/...`.
8. ❌ **Model IDs and routing** — owned by `runtime/model-routing.md` (when implemented).

### 2.3 Cross-reference rule

Every per-tool record references the inventory entry by `registry_id`. The policy never duplicates state from the registry. If the two files disagree about a tool's existence, the registry is the source of truth.

---

## 3. Manifest Structure

### 3.1 Top-level layout

The runtime policy manifest is a Markdown document (this file). A future machine-readable form MAY live at `runtime/opencode/manifest.md` or `runtime/opencode/manifest.json` (when implemented); that file would be a 1:1 rendering of this policy. **The Markdown form is the source of truth for the policy; the machine-readable form is a derivative.**

```
runtime/tool-manifest.md          ← this file (source of truth for policy)
runtime/registry.json             ← source of truth for inventory (v0.7-rev2, LOCKED)
runtime/opencode/manifest.md      ← machine-readable form (when implemented; derivative)
```

### 3.2 Per-tool policy record (OPTIONAL override)

For every entry in `runtime/registry.json` v0.7-rev2, this file MAY include a policy record. A policy record is **optional** — it overrides the class-level default policy in §3.4. The runtime is **enforceable** even when no per-tool record exists.

```yaml
- registry_id: <id from registry.json>
  gating: <"enabled" | "gated" | "disabled">
  sensitive: <bool>
  approval_class: <"per_call" | "pre_approved" | "none">
  capability_requirement: <"runtime_verified" | "discovered_acceptable">
  capability_relaxable: <bool>
  failure_behavior: <"abort" | "retry" | "log_and_continue" | "escalate">
  timeout_seconds: <int | null>
  retry_count: <int | null>
  scope_dependency: <"target_scope_required" | "global_ok" | null>
  network_capable: <bool>
  egress_class_default: <"none" | "target" | "external" | "research">
  redaction_required: <bool>
  environment_overrides: <list>
  notes: <string | null>
```

> **Critical (v1.2 #1 + #5)**: `gating: gated` is a strict override — always requires per-call approval regardless of `approval_class`. `mcp_server_ref` removed; the registry's `provider` field is authoritative.

> **Critical distinction** (v1.2 #4): **definition integrity** is the security invariant inherited from `agent-security.md` §5.1. **Currently implementable verification** is existence + availability + capability. The canonical hash mechanism is not implemented (GAP-TM-11). A tool in the registry is **not** integrity-verified.

> **`network_capable` vs `egress_class_default`**: `network_capable` is a capability flag — it says the tool *can* issue network requests. `egress_class_default` is the **class-level default**. The **actual** egress class of an invocation is determined at step 8a of §3.5 based on the call's arguments, command, or code.

### 3.3 Field semantics

| Field | Type | Semantics |
|---|---|---|
| `registry_id` | string | The `id` field from the matching entry in `runtime/registry.json`. Required. |
| `gating` | enum | **"enabled"** = freely invokable subject to `approval_class`. **"gated"** = always requires per-call approval regardless of `approval_class`. **"disabled"** = never invokable. Default: derived from class (§3.4). |
| `sensitive` | bool | Whether the operation is sensitive per §4. Default: derived from class. |
| `approval_class` | enum | "per_call" / "pre_approved" / "none". **For `gating: gated` tools, implicitly `per_call` regardless of value.** Default: derived from class. |
| `capability_requirement` | enum | "runtime_verified" (only invoke if the registry says `runtime_verified`), "discovered_acceptable" (also OK for `discovered`). **This is capability verification, NOT definition integrity.** Default: `runtime_verified`. |
| `capability_relaxable` | bool | Whether an environment override may relax `capability_requirement`. Applies only to capability, never to definition integrity. Default: `true`. |
| `failure_behavior` | enum | "abort" / "retry" / "log_and_continue" / "escalate". Default: per §5.2. |
| `timeout_seconds` | int / null | Null = runtime default. |
| `retry_count` | int / null | Null = no retry. |
| `scope_dependency` | enum / null | "target_scope_required" (must verify `testing/<target>/scope.md` exists and is readable before invocation), "global_ok" (no target scope check required), null. Default: per class. |
| `network_capable` | bool | **Capability flag**: whether the tool *can* issue network requests. `true` for CLI/MCP network tools, `shell`, `execute`, `webfetch`, `websearch`, `browser`. `false` for local utilities, read-only file tools, orchestration builtins, opencode internal. |
| `egress_class_default` | enum | **Class-level default**: `none` / `target` / `external` / `research`. The **actual** class of a specific invocation is determined at §3.5 step 8a. |
| `redaction_required` | bool | Whether outputs must pass through `runtime/redaction.md` before crossing the local → external boundary. Default: per class. |
| `environment_overrides` | list | Per-environment overrides. Restrict-only for `gating`; either direction for `approval_class` and `capability_requirement`. |
| `notes` | string | Free-form context for operators. |

### 3.4 Default Policy (per tool class)

| Class | Tools (registry v0.7-rev2) | `gating` | `sensitive` | `approval_class` | `capability_requirement` | `capability_relaxable` | `scope_dependency` | `network_capable` | `egress_class_default` | `redaction_required` |
|---|---|---|---|---|---|---|---|---|---|---|
| `cli-passive-source` | subfinder, amass, assetfinder, dnsx | enabled | true | per_call | runtime_verified | true | target_scope_required | true | external | false |
| `cli-archive` | gau, waybackurls | enabled | true | per_call | runtime_verified | true | target_scope_required | true | external | false |
| `cli-crawl` | katana, hakrawler | gated | true | per_call | runtime_verified | true | target_scope_required | true | target | true |
| `cli-probe` | naabu, httpx | gated | true | per_call | runtime_verified | true | target_scope_required | true | target | true |
| `cli-fuzz` | ffuf, arjun, paramspider, kiterunner | gated | true | per_call | runtime_verified | true | target_scope_required | true | target | true |
| `cli-vuln` | nuclei, dalfox, sqlmap, subzy, jwt_tool | gated | true | per_call | runtime_verified | true | target_scope_required | true | target | true |
| `cli-js` | jsluice | enabled | false | none | runtime_verified | true | global_ok | false | none | false |
| `cli-util` | anew, uro, gf, unfurl, qsreplace | enabled | false | none | runtime_verified | true | global_ok | false | none | false |
| `cli-secrets` | gitleaks, trufflehog | gated | true | per_call | runtime_verified | true | global_ok | false | none | true |
| `cli-sast` | semgrep | enabled | false | none | runtime_verified | true | global_ok | false | none | false |
| `cli-cloud` | cloud_enum | gated | true | per_call | runtime_verified | true | target_scope_required | true | target | true |
| `cli-oast` | interactsh-client | gated | true | per_call | runtime_verified | true | global_ok | true | external | false |
| `mcp-read` | burp_get_active_editor_contents, burp_get_organizer_items, burp_get_organizer_items_regex, burp_get_proxy_http_history, burp_get_proxy_http_history_regex, burp_get_proxy_websocket_history, burp_get_proxy_websocket_history_regex, burp_output_project_options, burp_output_user_options | gated | true | per_call | runtime_verified | false | target_scope_required | false | none | true |
| `mcp-send` | burp_send_http1_request, burp_send_http2_request | gated | true | per_call | runtime_verified | false | target_scope_required | true | target | true |
| `mcp-repeater` | burp_create_repeater_tab, burp_create_repeater_tab_http2 | gated | true | per_call | runtime_verified | false | global_ok | false | none | false |
| `mcp-intruder` | burp_send_to_intruder | gated | true | per_call | runtime_verified | false | global_ok | false | none | false |
| `mcp-mutate` | burp_set_proxy_intercept_state, burp_set_task_execution_engine_state, burp_set_active_editor_contents, burp_set_project_options, burp_set_user_options | gated | true | per_call | runtime_verified | false | global_ok | false | none | false |
| `mcp-encoding` | burp_base64_encode, burp_base64_decode, burp_url_encode, burp_url_decode, burp_generate_random_string | gated | true | per_call | runtime_verified | false | global_ok | false | none | false |
| `builtin-read` | read, glob, grep | enabled | false | none | runtime_verified | true | global_ok | false | none | true |
| `builtin-write` | write, edit | enabled | true | per_call | runtime_verified | true | global_ok | false | none | false |
| `builtin-shell` | shell | gated | true | per_call | runtime_verified | true | target_scope_required | true | target (default) | false |
| `builtin-execute` | execute | gated | true | per_call | runtime_verified | true | target_scope_required | true | target (default) | false |
| `builtin-webfetch` | webfetch | enabled | true | per_call | runtime_verified | true | global_ok | true | target (default) | true |
| `builtin-websearch` | websearch | enabled | true | per_call | runtime_verified | true | global_ok | true | research | false |
| `builtin-orchestration` | subagent, question, skill | enabled | false | none | runtime_verified | true | global_ok | false | none | false |
| `builtin-browser` | browser | gated | true | per_call | runtime_verified | true | target_scope_required | true | target (default) | true |
| `builtin-opencode-internal` | opencode.models, opencode.session_move, opencode.session_rename | enabled | false | none | runtime_verified | false | global_ok | false | none | false |

**Notes on the defaults**:

- `cli-passive-source` and `cli-archive` are `sensitive: true, approval_class: per_call` (S5 external service egress). Operators may pre-approve specific named external services via environment configuration.
- `builtin-websearch` is `sensitive: true, approval_class: per_call` (S5). Pre-approval via environment config for the specific search service.
- `cli-js`, `cli-util`, `cli-sast`, `cli-secrets` are `network_capable: false` — pure local processing. No network request issues from these invocations.
- `cli-oast` egresses to an external service. `egress_class_default: external`.
- MCP classes are all `sensitive: true, gating: gated, approval_class: per_call`. MCP transport (stdio / SSE to local bridge) is **not** a network request. Only `mcp-send` tools issue target requests.
- `builtin-shell`, `builtin-execute`, `builtin-webfetch`, `builtin-browser` are `network_capable: true` but the **actual** egress class is determined per invocation at §3.5 step 8a per §3.5.2.
- `builtin-websearch` egress is research; no target-scope check fires. S5 approval applies.
- `builtin-read` (`read`, `glob`, `grep`) is non-sensitive with redaction required.
- `builtin-write` (`write`, `edit`) is `enabled, sensitive: true, approval_class: per_call`.
- `builtin-shell` / `builtin-execute` are gated AND `target_scope_required` AND `network_capable`.
- `builtin-orchestration` is non-sensitive.
- `builtin-opencode-internal` is Buggy internal; not capability-relaxable.

### 3.5 Policy Resolution (runtime algorithm)

> **Step labels** (v1.5 third pass): the numbered algorithm is the canonical reference. Earlier drafts labeled the integrity/destination checks as "step 4a/4b"; they are actually steps 7 and 8 in this version.

The runtime resolves the effective policy for a tool invocation in this order. **Each step must complete; no step may be skipped.** If a step fails, the runtime refuses (or escalates) per §6.3.

1. **Apply the class-level default policy** (§3.4).
2. **Apply any per-tool record** (§3.2) as an override.
3. **Apply any active environment override** (§8).
4. **Check `gating: disabled`** — refuse with `gating_disabled` (§6.3.E). **Stop.**
5. **Check `scope_dependency`** — if `target_scope_required`, verify `testing/<target>/scope.md` **before** invocation:
   - Missing/unreadable → refuse `scope_unverifiable` (§6.3.F). **Stop.**
   - Target out of scope → refuse `out_of_scope` (§6.3.G). **Stop.** No approval can override.
   - In scope → continue.
6. **Apply the verification chain** (§6.2) for existence, availability, and capability:
   - Existence (§6.2.1): not in registry → refuse `not_in_registry` (§6.3.A).
   - Availability (§6.2.2): not `present` → refuse `unavailable` (§6.3.B').
   - Capability (§6.2.3): `verification_state` does not meet `capability_requirement` → refuse `verification_insufficient` (§6.3.C).
7. **Integrity eligibility check** (v1.4 B1):
   - GAP-TM-11 CLOSED → integrity check per §6.2.4. On hash mismatch → refuse `hash_mismatch` (§6.3.D).
   - GAP-TM-11 OPEN → refuse `integrity_unverifiable` (§6.3.L). **No exception granted.** Runs BEFORE any prompt.
8. **Initial network destination preflight and per-hop enforcement** (v1.4 B2, v1.5-3R2, v1.5-4 redirect, final bounded correction pass):
   - **Step 8a — Classify the initial invocation.** If `network_capable: true` for the class, classify the actual initial request destination per §3.5.2. Classification MUST be based on the actual arguments/request representation, not on the absence of a scope match.
   - **Step 8b — Validate the initial destination.**
     - `egress_class: none` is permitted only when local-only behavior is positively and reliably established.
     - `egress_class: target` → extract and normalize the complete request destination; evaluate it against `testing/<target>/scope.md` using the scope semantics defined by that scope contract. Check all scope-relevant components, including scheme, normalized host, effective port, path/resource, query, and method when relevant. In scope → continue. Out of scope → refuse `out_of_scope` (§6.3.G). Scope file missing/unreadable or scope membership cannot be established → refuse `scope_unverifiable` (§6.3.F). Destination cannot be parsed or normalized reliably → refuse `destination_unverifiable` (§6.3.K).
     - `egress_class: external` or `research` → permitted only when external/research intent and the specific service identity are independently established per §3.5.2. No target-scope check is substituted for service identity. S5 approval requirements apply.
     - Any ambiguous classification → refuse `destination_unverifiable` (§6.3.K). Fail closed.
   - Initial destination classification and scope validation run before the initial authorization prompt.
   - **Step 8c — Per-hop enforcement for every follow-up request.** This is a send-time subroutine for every request after the initial one, including HTTP redirects, crawler-discovered links, browser subrequests, cross-origin requests, shell/execute requests, CLI-generated requests, and MCP requests whose underlying client follows redirects. It is mandatory even when the initial request passed step 8b:
     1. Resolve a relative or protocol-relative redirect reference against the immediately preceding request URL. Normalize the destination deterministically before comparison: lowercase scheme/host; apply a single, defined IDNA/punycode and trailing-dot rule; calculate effective default ports; parse IPv4/IPv6 literals canonically; reject user-info and authority-parsing ambiguities; and normalize path/query only according to the canonical scope parser, without double-decoding. Keep the hostname checked by policy bound to the actual connection destination when the scope rules depend on resolution. Parser/transport disagreement, DNS/connection identity ambiguity, or uncertainty about redirect-chain semantics fails closed with `destination_unverifiable` (§6.3.K) and the follow-up is not sent. Path/query/method normalization must follow the actual scope contract rather than inventing a new scope language.
     2. Independently classify the follow-up's actual egress class. Do not inherit the initial request's `target`, `external`, or `research` classification.
     3. If the follow-up is target-directed, evaluate the **complete follow-up destination** against `testing/<target>/scope.md` BEFORE checking authorization coverage. A destination known to be out of scope → refuse `out_of_scope` (§6.3.G). If the scope file or required scope interpretation is unavailable/ambiguous → refuse `scope_unverifiable` (§6.3.F). A matching `(scheme, host, port)` never bypasses path/resource/query/method-aware scope evaluation.
     4. Only after the complete scope check succeeds, determine whether the follow-up is authorized. A request is covered only when its normalized request identity matches the initial authorization record, or an explicit authorization record covers the exact request, or the operator approved a scope-bounded operation whose recorded target and scope-document version/digest still match and whose scope rules include this request. Scope membership alone is NOT authorization. A generic approval for the initial URL does NOT create scope-bounded authorization.
     5. The authorization identity MUST include normalized scheme, host, effective port, and full normalized path/resource and query; include request method and material operation parameters/body identity where these change the requested effect. If the runtime cannot record or compare the relevant identity, fail closed. These are required semantics, not a claim that the runtime currently implements them (GAP-TM-25, GAP-TM-26).
     6. If the follow-up egress class differs from the initial request's class (`target` ↔ `external`/`research`, or `external` ↔ `research`), the initial class is never inherited. The hop MUST be refused with `hop_not_authorized` (§6.3.M) unless (a) its exact request identity is explicitly covered by the initial authorization record, or (b) for an `external`/`research` hop only, the specific service's S5 exception is independently and fully satisfied for this hop, including allowlist membership, explicit service-identity verification, and absence of `gated`, untrusted/unknown MCP, S6, or any other mandatory floor. S5 pre-approval is service-specific, not a blanket authorization. An S5 exception never authorizes a target hop.
     7. For a same-class target follow-up that passes scope but is not covered by exact-request or explicitly recorded scope-bounded authorization, refuse `hop_not_authorized` (§6.3.M). For a known external/research service that is not covered by explicit authorization or its valid narrow S5 exception, refuse `hop_not_authorized` (§6.3.M). A known-but-unauthorized hop is not `destination_unverifiable`.
     8. Every crawler-discovered link (including URLs from page content, `robots.txt`, sitemaps, and other discovery sources) is a follow-up request under this step, not only an HTTP redirect. Redirect chains and repeated hops are checked one by one. If a loop, redirect-count limit, DNS/connection identity, parser result, or URL normalization cannot be resolved consistently with the scope and authorization record, fail closed before sending the follow-up.
     9. If the runtime cannot inspect a follow-up destination and perform these checks before send, the relevant automatic redirect, link-following, cross-origin request, or auto-follow behavior MUST be disabled for that invocation; if it cannot be disabled, the follow-up MUST be refused before send with the appropriate reason code. No prompt may be silently skipped in favor of a tool execution.
     10. **No second prompt.** The one-prompt-per-invocation invariant remains. An uncovered hop is refused rather than re-prompted. A valid separately configured S5 pre-approval is the only relevant external/research exception and does not override any mandatory floor.
   - The runtime capability to intercept and enforce the above per-hop rules is not implemented; see GAP-TM-22, GAP-TM-23, GAP-TM-25, GAP-TM-26. Until implemented, relevant auto-follow/link-following behavior must be disabled or fail closed.
9. **Resolve the effective approval class before the single prompt** (v1.5-3R6, v1.5-4R8, v1.5-4R9, final bounded correction pass). **No operator prompt is issued in this step.** The step produces one final `effective_approval_class` for step 11 and the audit record.

   **Class ordering:** `none < pre_approved < per_call`. A later value is stricter. The resolution below must be applied deterministically; no override or exception may skip a mandatory floor.

   **9a. Compute `candidate_class` and override provenance.** Start with the class-level default (§3.4), then apply the per-tool record (§3.2), then active environment overrides (§8). Set `candidate_class` to the final configured value. Also record whether an explicit per-tool or environment override deliberately set `approval_class: per_call`; a narrow S5/S12 exception MUST NOT weaken such an explicit stricter setting.

   **9b. Record MCP trust status before normalization.** For MCP tools, look up the server's trust status from the future trust list (GAP-AS-03) and record `trusted`, `untrusted`, or `unknown` in the pending invocation record. Do not prompt here. For non-MCP tools, trust status is not applicable. This recorded fact is used below and by step 11.

   **9c. Evaluate narrow exceptions.** Determine every applicable S1–S12 class under §4.2–§4.3. Evaluate S5 and S12 independently; they do not override each other or any mandatory floor.
   - **S5 exception-valid** only if the current request is classified `external` or `research`, the specific service and destination identity are named in the active environment's allowlist and explicitly identity-verified, the invocation is not `gated`, an MCP server (if any) is trusted, no S6 applies, no other unconditional floor applies, and no explicit per-tool/environment `per_call` override deliberately requires a prompt. For a follow-up hop, evaluate these criteria against that hop itself, not the initial request.
   - **S12 exception-valid** only if the operation is a short, well-scoped background task explicitly configured for the active environment, the invocation is not `gated`, no untrusted/unknown MCP status applies, no other mandatory floor applies, and no explicit per-tool/environment `per_call` override deliberately requires a prompt.
   - Start `post_exception_class = candidate_class`. If an applicable S5 operation has a valid S5 exception, or an applicable S12 operation has a valid S12 exception, set `post_exception_class = pre_approved` only if **every** applicable S5/S12 exception required by the operation is valid, no non-exception-sensitive class is applicable, and no explicit stricter override was recorded. This is the permitted exception result; it is never `none`. Otherwise leave `post_exception_class = candidate_class`.
   - If an override attempts to downgrade below a mandatory floor, log `approval_downgrade_denied` (§6.3.H), reject that downgrade, and continue only at the normalized floor. This is a policy error, not permission to bypass the floor.

   **9d. Compute `mandatory_floor`.** If S10 applies, refuse with `out_of_scope` (§6.3.G) and stop; S10 is prohibited and MUST NOT be converted into any approval class. Otherwise set `mandatory_floor = per_call` if ANY of these apply; if none apply, set `mandatory_floor = none`:
   - final resolved `gating` is `gated`;
   - MCP server is untrusted or unknown;
   - operation is S6 (state-mutating MCP), regardless of trust-list status;
   - operation is S1, S2, S3, S4, S7, S8, S9, or S11;
   - operation is S5 and its S5 exception is not fully valid;
   - operation is S12 and its S12 exception is not fully valid.

   **9e. Emit `effective_approval_class`.** Choose the stricter (later) value of `post_exception_class` and `mandatory_floor` under the defined order. If `mandatory_floor = none`, `effective_approval_class = post_exception_class`. A valid S5/S12 exception may resolve to `pre_approved`, never `none`, and only when every applicable floor permits it. A candidate `none` or `pre_approved` for an S5/S12 operation with an invalid exception is raised to `per_call`.
10. **MCP trust lookup is complete** (final bounded correction pass). Trust was looked up and recorded at step 9b; this step performs no additional prompt or separate decision, preserving step numbering for existing cross-references.
11. **Single authorization step** — exactly one operator prompt per invocation when required:
    - If `effective_approval_class = per_call`, issue one prompt. For MCP tools, it combines server trust status, normalized effective class, operation, and requested destination/operation identity. For network-capable operations, the prompt/authorization record MUST distinguish an exact-request authorization from an explicitly scope-bounded target operation. The scope-bounded mode must identify the target, the applicable scope-document version/digest, and the operation/request limits; it is not implied merely because the initial URL is in scope.
    - If `effective_approval_class = pre_approved`, proceed without prompting only under the fully satisfied narrow exception recorded at step 9c.
    - If `effective_approval_class = none`, proceed without a prompt only when no mandatory floor and no applicable sensitive-operation requirement raises it.
    - A follow-up request is subject to step 8c before send even after the invocation has received authorization. No second prompt is issued for an uncovered hop; refuse it instead.
    - **Post-response release** is a separate control per `agent-security.md` §8.2 / §7.3. After the call returns, an untrusted MCP response remains quarantined until the operator separately approves release into model context. This output-leg decision is not a second invocation prompt.
12. **Apply the redaction fail-closed check** (v1.4 B5) — if `redaction_required: true` AND redaction success cannot be proven (absent, fails, times out, partial/uncertain output, unsupported type), output MUST NOT cross any external boundary. Refuse reason: `redaction_unavailable` (§6.3.I) on the output leg.
#### 3.5.1 Policy-resolution simulations

> Simulations `a`–`x` are retained from previous passes. Simulations `u` and `t` are read under the per-hop rule in the final bounded correction pass. New simulations `y`–`au` cover approval floors, full scope evaluation, authorization coverage, cross-class hops, and fail-closed behavior. Any row that assumes required GAPs are CLOSED is a policy simulation only; it does not claim that implementation exists. While GAP-TM-11 is OPEN, step 7 refuses all invocations before prompts or tool execution.

| # | Inputs | First failed check | Operator prompts | Refuse? | Notes |
|---|---|---|---|---|---|
| a | `enabled`, `none`, runtime_verified, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Step 7 precedes step 8. |
| b | `gated`, `per_call`, runtime_verified, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Same. |
| c | `gated`, `pre_approved`, runtime_verified, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | `gated` semantics preserved. |
| d | `disabled` | Step 4 | 0 | **Yes** (`gating_disabled`) | Never invokable. |
| e | MCP, untrusted, runtime_verified, enabled, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Steps 9–11 not reached. |
| f | `enabled`, `none`, discovered, scope=in, GAP-TM-11 OPEN | Step 6 | 0 | **Yes** (`verification_insufficient`) | Fails before step 7. |
| g | `enabled`, `per_call`, runtime_verified, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Same as a. |
| h | `gated`, `none` override but S6, runtime_verified, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Step 9 would raise to `per_call`; step 7 refuses first. |
| i | `enabled`, `none` override but S1, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Same. |
| j | `enabled`, `none`, scope=missing | Step 5 | 0 | **Yes** (`scope_unverifiable`) | Step 5 precedes step 7. |
| k | `enabled`, `none`, redaction_required=true, redaction unavailable, scope=in, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Redaction step (12) not reached. |
| l | `enabled`, `none`, runtime_verified, network_capable=true, GAP-TM-11 OPEN | Step 7 | 0 | **Yes** (`integrity_unverifiable`) | Step 7 precedes step 8. |
| m | `shell` with `curl http://out-of-scope.example.com/`, GAP-TM-11 CLOSED (hypothetical) | Step 8b | 0 | **Yes** (`out_of_scope`) | URL host is a target-named host not in `scope.md` → classified `target`; step 8b refuses. |
| n | `shell` with `curl http://in-scope.example.com/`, GAP-TM-11 CLOSED (hypothetical) | None | 1 (single prompt) | No | Step 8 classifies as `target`, verifies in-scope; step 11 single prompt; proceeds on approval. |
| o | `websearch` query, GAP-TM-11 CLOSED (hypothetical) | None | 1 (single prompt) unless valid S5 exception applies | No | Step 8a classifies as `research`; without a valid identity-verified service allowlist exception, step 11 prompts. With a valid S5 exception and no mandatory floor, effective class may be `pre_approved`. |
| p | `anew` (local util), network_capable=false, GAP-TM-11 CLOSED (hypothetical) | None | 0 | No | No network check; no approval prompt (non-sensitive); proceeds. |
| q | `shell` with `pwd`, GAP-TM-11 CLOSED (hypothetical) | **None** | 1 (single prompt) | No | **v1.5-4R7**: `pwd` is a positively known local-only command. If the classifier can positively establish `none`, step 8b skips; step 11 prompts (gated). If the classifier cannot positively establish `none`, it must fail closed (`destination_unverifiable`). The runtime's classifier capability is deferred (GAP-TM-18). |
| r | `shell` with `curl http://random-unknown-host.example/`, GAP-TM-11 CLOSED (hypothetical) | Step 8a | 0 | **Yes** (`destination_unverifiable`) | URL parses but neither confirmed in-scope target nor confirmed external service. Fail-closed. |
| s | MCP `burp_send_http1_request`, untrusted server, GAP-TM-11 CLOSED (hypothetical) | None | **1** (unified) | No | Step 8 classifies target; step 9 normalizes effective class to `per_call` (untrusted server); step 10 records trust; step 11 issues **one** prompt combining trust + `per_call`. Post-response release is a separate control. |
| t | `browser` navigation to in-scope page, page triggers cross-origin subrequest to `cdn.external.example`, GAP-TM-11 CLOSED (hypothetical) | Step 8c | 1 (initial prompt, then block before subrequest) | **Yes** (`destination_unverifiable`) | The subrequest is independently classified and scope/authorization checked; if interception or destination identity cannot be established before send, refuse. |
| **u** | **`webfetch` with in-scope URL that redirects to an out-of-scope host, GAP-TM-11 CLOSED (hypothetical; required per-hop inspection assumed available for the test)** | **Step 8c** | **1 (initial prompt, then refused before follow-up)** | **Yes** (`out_of_scope`) | The follow-up is independently classified and full scope checked before authorization coverage; known out-of-scope destination is refused before send. If inspection is unavailable in real operation, auto-follow must be disabled or fail closed. |
| **v** | **`shell` with `python -c 'import urllib.request; urllib.request.urlopen("http://x/")'`, GAP-TM-11 CLOSED (hypothetical)** | **Step 8a** | **0** | **Yes** (`destination_unverifiable`) | **v1.5-4R7.** No listed network verb (`curl`/`wget`) appears, but the interpreter can initiate network access. The classifier cannot positively establish `none` → fail closed. |
| **w** | **`gated + approval_class: none` on a non-S-class operation, GAP-TM-11 CLOSED (hypothetical)** | **None** | **1 (single prompt)** | **No** | **v1.5-4R8.** Step 9b normalizes `effective_approval_class` to `per_call` because final `gating` is `gated`. Step 11 issues **one** prompt. Audit record shows `per_call`. |
| **x** | **Untrusted MCP tool with a per-tool record setting `approval_class: pre_approved`, GAP-TM-11 CLOSED (hypothetical)** | **None** | **1 (unified prompt)** | **No** | **v1.5-4R8.** Step 9b normalizes `effective_approval_class` to `per_call` because the server is untrusted. The `pre_approved` override is ignored for the invocation. Step 11 issues **one** prompt combining trust + `per_call`. Post-response release is a separate control. |
| **y** | **S5 operation with `candidate_class: none`, no valid identity-verified allowlist exception, GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Step 9d applies S5 floor and raises `none` to `per_call`; logs `approval_downgrade_denied`. |
| **z** | **S5 operation with `candidate_class: pre_approved`, exception invalid, GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Step 9d applies S5 floor and raises `pre_approved` to `per_call`; an invalid exception cannot retain pre-approval. |
| **aa** | **S5 operation with a valid identity-verified, allowlisted external service; no gated/MCP/S6/other floor, no explicit per-call override; GAP-TM-11 CLOSED (hypothetical)** | None | 0 | No | Step 9c exception is fully valid; effective class is `pre_approved`, never `none`. |
| **ab** | **S12 operation with `candidate_class: none`, no eligible configured task, GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Step 9d applies S12 floor and raises `none` to `per_call`. |
| **ac** | **S12 operation with `candidate_class: pre_approved`, exception invalid, GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Step 9d applies S12 floor and raises `pre_approved` to `per_call`. |
| **ad** | **S12 operation with eligible, explicitly configured short task; no gated/MCP/other floor or explicit per-call override; GAP-TM-11 CLOSED (hypothetical)** | None | 0 | No | Step 9c exception is fully valid; effective class is `pre_approved`, never `none`. |
| **ae** | **Initial URL `/in-scope` redirects to `/out-of-scope` on the same host and port; scope rules exclude `/out-of-scope`; relevant parser/interception GAPs hypothetically CLOSED** | Step 8c | 1 (initial prompt, then refuse before follow-up) | Yes (`out_of_scope`) | The complete follow-up path is scope-checked before authorization coverage; matching scheme/host/port does not bypass scope. |
| **af** | **Initial request is in scope; follow-up is a different in-scope path/host not covered by exact or scope-bounded authorization; binding GAP hypothetically CLOSED** | Step 8c | 1 (initial prompt only) | Yes (`hop_not_authorized`) | Scope passes, but authorization coverage fails; do not send and do not prompt a second time. |
| **ag** | **Initial `target` request redirects to a named, identity-verified, allowlisted external/research service; S5 exception valid for the exact hop and no mandatory floor; relevant GAPs hypothetically CLOSED** | None | 1 (initial target prompt; no second prompt) | No | The initial target approval is not inherited. The exact hop is separately covered by the narrowly configured S5 pre-approval; only that exception permits the cross-class hop. |
| **ah** | **Initial `target` request redirects to a known external/research service not in the valid S5 allowlist; relevant GAPs hypothetically CLOSED** | Step 8c | 1 (initial prompt only) | Yes (`hop_not_authorized`) | Destination identity is known but no explicit authorization or valid service-specific pre-approval covers it. |
| **ai** | **Initial external/research request redirects to an in-scope target URL not covered by an explicit target authorization record; relevant GAPs hypothetically CLOSED** | Step 8c | 1 (initial prompt only) | Yes (`hop_not_authorized`) | Target scope passes, but S5 does not authorize target traffic and no target-request coverage exists. |
| **aj** | **`cli-crawl` starts in scope and discovers a target-named link excluded by scope.md (not an HTTP redirect); relevant interception GAP hypothetically CLOSED** | Step 8c | 1 (initial prompt, then refuse before discovered-link request) | Yes (`out_of_scope`) | Crawler-discovered links are follow-up requests and are scope-checked before send. |
| **ak** | **Follow-up destination cannot be parsed/normalized, or parser and transport destination disagree; relevant GAPs hypothetically CLOSED except the tested parser ambiguity** | Step 8c | 1 (initial prompt, then refuse before follow-up) | Yes (`destination_unverifiable`) | Ambiguous URL identity fails closed before sending. |
| **al** | **Follow-up is target-directed but scope.md is missing/unreadable or scope membership cannot be established; relevant parser/interception GAPs hypothetically CLOSED** | Step 8c | 1 (initial prompt, then refuse before follow-up) | Yes (`scope_unverifiable`) | Scope uncertainty uses the scope-specific refusal code, not `destination_unverifiable`. |
| **am** | **Redirect/link interception cannot inspect the next request before send; interception GAP remains OPEN** | Step 8c | 1 (initial prompt, then block/disable auto-follow) | Yes (`destination_unverifiable`) if a follow-up is attempted; otherwise no follow-up is sent | Real behavior must disable the relevant follow-up feature or fail closed; this simulation does not claim interception exists. |
| **an** | **S5 candidate `pre_approved`, but invocation is `gated`; allowlist valid; GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Gating imposes `per_call`; the S5 exception cannot lower it. |
| **ao** | **Operation is S5 and S12; S5 exception valid but S12 exception invalid; no other floors; GAP-TM-11 CLOSED (hypothetical)** | None | 1 (single prompt) | No | Every applicable exception must be valid. The S12 floor raises the result to `per_call`. |
| **ap** | **Target URL with relative redirect that resolves to an out-of-scope path on the same host; relevant URL normalization/interception GAPs hypothetically CLOSED** | Step 8c | 1 (initial prompt, then refuse before follow-up) | Yes (`out_of_scope`) | Resolve the relative Location against the previous URL, normalize, then scope-check the resolved full path before checking authorization coverage. |
| **aq** | **Target URL redirects to an allowlisted external service but the service identity cannot be verified; relevant GAP-TM-11 closed, identity/interception GAP open** | Step 8c | 1 (initial prompt, then refuse before follow-up) | Yes (`destination_unverifiable`) | A hostname label or allowlist text alone does not prove service identity; no S5 exception without positive verification. |
| **ar** | **A gated browser invocation triggers an unseen cross-class external hop; no exact hop is in the initial authorization record; no second prompt allowed** | Step 8c | 1 (initial prompt only) | Yes (`hop_not_authorized`) | A valid S5 pre-approval cannot bypass the gated floor; absent exact coverage, block the hop. |
| **as** | **Candidate `none` for non-sensitive, non-gated local-only operation; no applicable S1–S12 floor; GAP-TM-11 CLOSED (hypothetical)** | None | 0 | No | Effective class remains `none`; no prompt is required when no mandatory floor applies. |
| **at** | **Same normalized request identity and in-scope destination recorded in initial authorization; scope-binding data unchanged; relevant GAPs hypothetically CLOSED** | None | 1 (initial prompt only) | No | The follow-up passes an independent scope check and matches the authorization record; identity match is considered only after scope succeeds. |
| **au** | **`GAP-TM-11` OPEN for any otherwise eligible invocation** | Step 7 | 0 | Yes (`integrity_unverifiable`) | Integrity default refusal occurs before destination checking, authorization, prompts, or tool execution. |

#### 3.5.2 Per-invocation egress classification (v1.5-4 updated)

For tools with `network_capable: true`, the runtime classifies the specific invocation's egress at step 8a. Classification is **only** permitted when the intent is independently established by the call's arguments, command, or code — **not** by exclusion from `testing/<target>/scope.md`.

| Tool class | Classification rule |
|---|---|
| `builtin-shell` | Classify `none` only when local-only behavior is positively and reliably established (e.g., a known-local command such as `pwd`, `ls`, or reading a local file). Absence of a recognized network verb is not proof of local-only behavior. Interpreters, wrappers, aliases, functions, helper programs, dynamic calls, and libraries may initiate network access. If a destination can be extracted, classify it independently; otherwise refuse `destination_unverifiable`. Every follow-up request issued by the command is subject to §3.5 step 8c. |
| `builtin-execute` | Same policy as `builtin-shell`: classify `none` only when local-only behavior is positively and reliably established. Absence of a known network API signature is insufficient. Every follow-up request issued by the code is subject to §3.5 step 8c; ambiguity or unavailable inspection fails closed. |
| `builtin-webfetch` | Classify the initial URL independently. Every HTTP redirect hop is a follow-up under §3.5 step 8c. Resolve relative/protocol-relative locations against the previous URL, normalize deterministically, run a full scope check first for target-class hops, and then check authorization coverage. An external/research hop requires exact service identity and a valid narrow S5 exception or explicit authorization coverage. If inspection/normalization cannot occur before send, disable automatic redirects or fail closed. GAP-TM-22 and GAP-TM-26 remain OPEN. |
| `builtin-browser` | Each outbound request — initial navigation, browser subrequests, cross-origin subrequests, redirects, and link-following actions — is classified individually. Target-directed requests receive a full scope check before authorization coverage is considered. No request inherits the parent page's class or scope status. If the runtime cannot inspect and authorize a request before send, block that behavior or fail closed. GAP-TM-21, GAP-TM-22, GAP-TM-25, and GAP-TM-26 remain OPEN. |
| `builtin-websearch` | Always `research` (independently established by tool semantics). |
| `cli-passive-source`, `cli-archive`, `cli-oast` | Always `external` (independently established by tool semantics — the tools query named external services). |
| `cli-crawl`, `cli-probe`, `cli-fuzz`, `cli-vuln`, `cli-cloud` | The initial destination is classified as `target` from arguments. Every outbound request generated during execution — HTTP redirect, crawler-discovered link, repeated probe, or other follow-up — is independently classified at send time under §3.5 step 8c. For target-class requests, full destination scope evaluation precedes authorization coverage. Out-of-scope → `out_of_scope`; in-scope but uncovered → `hop_not_authorized`; ambiguous destination → `destination_unverifiable`; scope semantics unavailable → `scope_unverifiable`. A named external/research hop requires its own exact, identity-verified S5 pre-approval or explicit authorization coverage. If the runtime cannot intercept requests before send, disable redirect/link-following or fail closed. GAP-TM-23 and GAP-TM-26 remain OPEN. |
| `mcp-send` (`burp_send_http1_request`, `burp_send_http2_request`) | The request's Host header and complete request target determine the destination. Validate scope for each target-directed request, including any redirect hop, before checking authorization coverage. The underlying client must not follow a redirect unless step 8c can inspect the next request before send; otherwise disable follow redirects or fail closed. Out-of-scope → `out_of_scope`; known but uncovered → `hop_not_authorized`; ambiguous destination → `destination_unverifiable`. |
| `mcp-read`, `mcp-repeater`, `mcp-intruder`, `mcp-mutate`, `mcp-encoding` | `network_capable: false` → step 8 skipped. |

> ⚠️ **GAP-TM-14 (OPEN)** — the concrete per-invocation and per-hop egress-classifier implementation is deferred to the runtime layer. Until it exists, any invocation or follow-up whose class cannot be determined by the current runtime fails closed before send with `destination_unverifiable`.

> ⚠️ **GAP-TM-18 (OPEN, extended in final bounded correction pass)** — the parser for extracting destinations from call arguments, commands, code, redirect locations, and follow-up requests is not implemented. The classifier also cannot positively establish `none` for arbitrary commands/code with hidden network access. Fail-closed is the default.

> ⚠️ **GAP-TM-20 (OPEN)** — the named external/research-service allowlist used for classification and S5 pre-approval is deferred to the environment configuration file. Until it exists, generic tools cannot be positively classified as an allowlisted external/research service; affected calls/hops fail closed.

> ⚠️ **GAP-TM-21 (OPEN, extended in final bounded correction pass)** — the ability to inspect browser cross-origin subrequests and link-following requests individually before send is not implemented. Until it is, block the relevant request behavior or fail closed.

> ⚠️ **GAP-TM-22 (NEW, v1.5-4)** — the ability to inspect HTTP redirect destinations before sending follow-up requests is not implemented. Until it is, automatic redirect following must be disabled or the follow-up must fail closed before send.

> ⚠️ **GAP-TM-23 (OPEN, final bounded correction pass)** — CLI redirect and crawler-link interception is not implemented. Every redirect, discovered link, repeated probe, and other follow-up request must be inspectable before send. Until then, disable the relevant auto-follow/link-following behavior or fail closed before sending the follow-up.

> ⚠️ **GAP-TM-24 (OPEN, final bounded correction pass)** — explicit service-identity verification for S5 `external`/`research` exceptions is not implemented. An allowlist string alone is not proof of service identity. Until identity verification exists, the S5 exception is unavailable and affected operations/hops remain `per_call` or are refused if their destination cannot be established.

> ⚠️ **GAP-TM-25 (OPEN, final bounded correction pass)** — authorization-to-destination binding is not implemented. The runtime cannot currently prove that an operator authorization covers a particular complete request identity or scope-bounded operation. Until implemented, any follow-up whose coverage cannot be established must not be sent; disable auto-follow/link-following or fail closed with `hop_not_authorized` when the destination is known, otherwise `destination_unverifiable`.

> ⚠️ **GAP-TM-26 (OPEN, final bounded correction pass)** — deterministic URL/request normalization and full per-hop scope evaluation are not implemented. Required cases include relative/protocol-relative redirects; lowercase scheme/host normalization; IDNA/punycode and trailing-dot handling; effective default ports; canonical IPv4/IPv6 literals; rejection of user-info/authority ambiguities; path/query normalization without double-decoding; method/operation parameters where relevant; parser/transport agreement; redirect chains; and hostname-to-connection identity binding where scope rules require it. If destination identity cannot be normalized, fail closed with `destination_unverifiable`; if scope membership cannot be established, fail closed with `scope_unverifiable`.

### 3.6 Operational Readiness and Verification Lifecycle

Of the 70 tools in `runtime/registry.json` v0.7-rev2:
- **45** are `runtime_verified`.
- **24** are `discovered`.
- **1** is `partially_verified`.

**Characterization**: intentional secure default. **While `GAP-TM-11` is OPEN, the runtime refuses all invocations** (§6.6).

#### 3.6.1 Operator path to make a tool available

> **Critical (v1.5-2R3)**: capability overrides do **not** bypass the integrity refusal. While `GAP-TM-11` is OPEN, no invocation is permitted by any capability override.

**The only paths to operational availability** under the current invariant:

1. **Close `GAP-TM-11`** — implement the canonical hash mechanism.
2. **A separate Architect-authorized architecture revision** — the Architect updates `agent-security.md` to add a formal exception mechanism, and a new architecture file (e.g. `architecture/integrity-exceptions.md`) is LOCKED to record the exception.

**What capability relaxation does** (once `GAP-TM-11` is closed):

- A per-tool record MAY set `capability_requirement: discovered_acceptable`.
- An environment override MAY relax `capability_requirement` (only when `capability_relaxable: true`).
- These affect only the capability check.

**What capability relaxation does NOT do**:

- Does not enable invocation while `GAP-TM-11` is OPEN.
- Does not grant an integrity exception.
- Does not bypass the §6.6 default refusal.

**Registry versioning**: new registry versions are LOCKED separately; v0.7-rev2 is never modified in place.

#### 3.6.2 [Historical only] Rejected temporary integrity exception

> **Explanatory history only.** The v1.3 "Temporary Integrity Exception" was rejected by the Architect (v1.4 review, Correction B1) because it conflicted with the non-relaxable §6.4.1 invariant. **No exception is granted by this manifest.** Any exception requires a separate architecture revision pass for `agent-security.md` and a new architecture file tracked OUTSIDE this manifest. This subsection is retained for traceability of the v1.3→v1.4 decision; it does not authorize any invocation.

---

## 4. Sensitive Operations List (resolves GAP-AS-01)

### 4.1 Principle

A **sensitive operation** is one that: mutates persistent state outside normal runtime operation, OR exposes data outside the local runtime, OR changes a tier 1 artifact, OR is flagged as state-mutating in `registry.json` v0.7-rev2.

### 4.2 Enumeration of sensitive operation classes

| Class | Examples | Why sensitive |
|---|---|---|
| **S1: Architecture writes** | Writing to any path under `/architecture/` | Tier 1 artifact. |
| **S2: Steering writes** | Writing to `/AGENTS.md` | Tier 1; controls runtime behavior. |
| **S3: Skill / Concept modification** | Modifying any SKILL.md or concept file | Tier 1 methodology. |
| **S4: Scope change** | Modifying `testing/<target>/scope.md` | Tier 1; scope is a security boundary. |
| **S5: External service egress** | Calling cloud model APIs, third-party tools, untrusted MCP servers, external research services, passive source querying, archive querying, websearch, OAST backend interaction | Tier 1 outbound boundary. |
| **S6: Trusted MCP server mutation** | Calls to MCP tools that mutate state (Burp options, intercept, task engine, editor writes) | Flagged in registry as "state-mutating". |
| **S7: Target-controlled content persistence** | Writing target responses to tier 1 paths | Tier 3 → tier 1; only derived operator-approved artifacts may land in tier 1. |
| **S8: Destructive file operations** | File deletion, overwrite without diff, recursive removal | Catastrophic recovery cost. |
| **S9: System-level commands** | `rm`, `mkfs`, `dd`, `iptables`, `kill -9`, package install/remove | Affects the runtime host. |
| **S10: Network egress outside target scope** | HTTP/TCP/UDP to hosts **that are target-named or target-adjacent** and not in `testing/<target>/scope.md`. A call to a genuinely external service (independently established per §3.5.2) is S5, not S10. | Out-of-scope target requests are not made. |
| **S11: Secret-bearing output** | Returning raw proxy history with PII, target identifier under redaction, credentials, active editor contents that may contain secrets | Per `agent-security.md` §7. |
| **S12: Long-running async operations** | Background scans, fuzzers, crawlers, OOB listeners | High blast radius if unintended. |

### 4.3 Per-tool mapping (S1–S12 operation-class annotation)

> §4.3 is an **S1–S12 operation-class annotation table**. It does **not** override the §3.4 class-level `sensitive` field. Every MCP tool remains `sensitive: true`.

**MCP class** — per §3.4, all MCP tools default to `gated, sensitive: true, approval_class: per_call`.

| Registry id | S1–S12 annotation | Justification |
|---|---|---|
| `burp_set_proxy_intercept_state` | S6 | State-mutating per registry `notes`. |
| `burp_set_task_execution_engine_state` | S6 | State-mutating per registry `notes`. |
| `burp_set_active_editor_contents` | S6, S11 | State-mutating (S6); editor buffer may contain secrets (S11). |
| `burp_set_project_options` | S6 | State-mutating per registry `notes`. |
| `burp_set_user_options` | S6 | State-mutating per registry `notes`. |
| `burp_send_http1_request` | S10 (target egress) | Sends HTTP/1.1 requests to a target. |
| `burp_send_http2_request` | S10 (target egress) | Sends HTTP/2 requests to a target. |
| `burp_get_proxy_http_history`, `_regex` | S11 (when redaction active) | May contain target real domain, cookies, tokens, PII. |
| `burp_get_proxy_websocket_history`, `_regex` | S11 (when redaction active) | Same. |
| `burp_get_active_editor_contents` | S11 | Editor buffer may contain secret-bearing content. |
| `burp_get_organizer_items`, `_regex` | S11 (when redaction active) | May contain target URLs, tokens, response bodies. |
| `burp_output_project_options`, `burp_output_user_options` | S11 (when redaction active) | Config dumps may contain credentials or tokens. |
| `burp_create_repeater_tab`, `_http2` | no S1–S12 behavior | Repeater populate without sending. |
| `burp_send_to_intruder` | no S1–S12 behavior | Intruder populate without sending. |
| `burp_base64_encode`, `_decode`, `burp_url_encode`, `_decode`, `burp_generate_random_string` | no S1–S12 behavior | Encoding / generation helpers. |

**Builtins annotated by S1–S12 behavior**:

| Registry id | S1–S12 annotation |
|---|---|
| `write` | S1, S2, S3, S4, S7, S8 (path-dependent) |
| `edit` | S1, S2, S3, S4, S7, S8 (path-dependent) |
| `shell` | S9 (and indirectly S1–S10 via the command) |
| `execute` | S9 (Code Mode execution) |

**Tools whose egress is S5**:
- `cli-passive-source`: subfinder, amass, assetfinder, dnsx
- `cli-archive`: gau, waybackurls
- `cli-oast`: interactsh-client
- `builtin-websearch`: websearch

**Tools whose egress is S10**:
- `cli-crawl`, `cli-probe`, `cli-fuzz`, `cli-vuln`, `cli-cloud`
- `builtin-shell`, `builtin-execute`, `builtin-webfetch`, `builtin-browser` **when the specific invocation is target-directed per §3.5.2**
- `mcp-send` tools

### 4.4 Pre-approval policy

> **v1.5-4R9**: this table distinguishes **default approval class**, **unconditional floor**, and any **narrowly permitted exception**. The default is the starting value; the floor is the minimum the runtime may resolve to; the exception column lists the only conditions under which the effective class may be lower than `per_call`.

| Class | Default | Unconditional floor | Narrowly permitted exception |
|---|---|---|---|
| S1 | per_call | per_call | none |
| S2 | per_call | per_call | none |
| S3 | per_call | per_call | none |
| S4 | per_call | per_call | none |
| S5 | per_call | per_call | `pre_approved` only when the specific `external` or `research` service and the permitted destination/request scope are named in the active environment's allowlist, service identity is explicitly verified, the S5 exception is evaluated for this exact request/hop, the invocation is not `gated`, any MCP server is trusted, no S6 or other unconditional floor applies, and no explicit per-tool/environment `per_call` override deliberately requires a prompt. The exception result is `pre_approved`, never `none`. If any condition is absent, `per_call` applies; a known but uncovered follow-up is refused with `hop_not_authorized`, an ambiguous destination with `destination_unverifiable`. `research` is not globally equated with `external`. |
| S6 | per_call | per_call | **none for state-mutating MCP tools — regardless of trust-list status.** A trusted server does not relax the S6 floor. |
| S7 | per_call | per_call | none |
| S8 | per_call | per_call | none |
| S9 | per_call | per_call | none |
| S10 | **N/A** | **N/A** | **prohibited — not approvable.** |
| S11 | per_call | per_call | none |
| S12 | per_call | per_call | `pre_approved` only for a short, well-scoped background task explicitly configured for the active environment, when the invocation is not `gated`, no untrusted/unknown MCP status or other mandatory floor applies, and no explicit per-tool/environment `per_call` override deliberately requires a prompt. The exception result is `pre_approved`, never `none`. Otherwise `per_call`. |

> ⚠️ **GAP**: §4.4 remains a policy table. Operators may override per-class or per-tool via environment configuration (§8). Tracked as `GAP-TM-02`.

---

## 5. Failure Behavior

### 5.1 Principle

Failure modes: **timeout**, **error**, **refuse**. Each must be deterministic and auditable.

### 5.2 Per-class failure behavior

| Failure mode | Default `failure_behavior` | Notes |
|---|---|---|
| Timeout | abort for sensitive; retry (up to `retry_count`) for transient network tools | Retry must not exceed 2× `timeout_seconds`. |
| Error | escalate for sensitive; log_and_continue for read-only | Error message (minus secrets) logged per `agent-security.md` §5.2. |
| Refuse | abort (no retry) | Refusal is a security signal. |

### 5.3 Forbidden failure behaviors

The runtime MUST NOT silently retry a refused tool; silently swallow a timeout; continue past a refused sensitive operation without explicit operator decision; return partial output without flagging it; treat an error response as a successful response.

---

## 6. Tool Definition Verification Policy (resolves GAP-AS-04)

### 6.1 The invariant (inherited)

Per `agent-security.md` §5.1:

```
A tool definition MUST come from a tier 1 source.
The runtime MUST:
  - verify the tool definition against the canonical registry
  - refuse to invoke a tool whose definition is not in the registry
  - treat a hash mismatch as a tool-poisoning attempt (T3) and refuse
  - log any tool definition mismatch as a tool-poisoning attempt (T3)
```

### 6.2 The verification chain

1. **Existence check** — `registry_id` present? Else refuse (§6.3.A).
2. **Availability check** — `availability` is `present`? Else refuse (§6.3.B').
3. **Capability check** — `verification_state` meets `capability_requirement`? Else refuse (§6.3.C).
4. **Definition hash check** (when canonical hash recorded) — currently a no-op (GAP-TM-11).
5. **MCP server trust check** (for MCP tools) — the server trust status is looked up and recorded at §3.5 step 9b before approval normalization. If untrusted or unknown, the mandatory floor is `per_call`; the single authorization prompt is issued at §3.5 step 11. **This check does not issue its own prompt.**

### 6.3 Response policy on verification failure

| Failure | Refuse reason code | Response | Notification |
|---|---|---|---|
| **A. Not in registry** | `not_in_registry` | abort, no retry | Log + alert |
| **B'. Tool marked absent/unknown** | `unavailable` | abort, no retry | Log + alert |
| **C. Capability insufficient** | `verification_insufficient` | abort, no retry | Log + alert |
| **D. Definition hash mismatch** | `hash_mismatch` | abort, no retry | Log + alert + escalate (T3) |
| **E. Gating disabled** | `gating_disabled` | abort, no retry | Log + alert |
| **F. Scope unverifiable** | `scope_unverifiable` | abort, no retry | Log + alert |
| **G. Out of scope** | `out_of_scope` | abort, no retry | Log + alert + escalate |
| **H. Approval downgrade denied** | `approval_downgrade_denied` | **policy error** — log it; runtime applies the §4.4 floor; the override is rejected; the call continues under the corrected class; step 11 prompts per the corrected class | Log + alert |
| **I. Redaction unavailable** | `redaction_unavailable` | output is fail-closed | Log + alert |
| **J. MCP server not trusted** | `mcp_untrusted` | record-only; trust is resolved at §3.5 step 9b and imposes a `per_call` floor; the single unified prompt is issued at §3.5 step 11 | Log + alert + record the per-call authorization from step 11 |
| **K. Network destination unverifiable** | `destination_unverifiable` | abort, no retry | Log + alert |
| **L. Integrity unverifiable (default refusal)** | `integrity_unverifiable` | abort, no retry | Log + alert (default while GAP-TM-11 OPEN) |
| **M. Follow-up hop not authorized** | `hop_not_authorized` | abort, no retry; do not send the follow-up | Log + alert. Destination is known and scope has been checked where applicable, but no explicit authorization record or valid exact-service pre-approval covers the hop. Distinct from `out_of_scope`, `scope_unverifiable`, and `destination_unverifiable` |

### 6.4 Hash storage and the current capability gap

#### 6.4.1 The inherited security invariant

Per `agent-security.md` §5.1: a tool whose definition is not verified against the canonical source MUST NOT be invoked. Non-relaxable.

#### 6.4.2 The current implementable capability

The runtime cannot enforce the invariant. GAP-TM-11 is OPEN. No `definition_hash` field exists in `runtime/registry.json` v0.7-rev2. §6.2.4 is a no-op. A tool passing current checks is runtime-eligible, not integrity-verified.

#### 6.4.3 Hash storage and rotation (when implemented)

When GAP-TM-11 closes: a `definition_hash` field will be added in a future registry version. Algorithm (proposed: SHA-256) and rotation policy deferred.

> ⚠️ **GAP-TM-11**: operator MUST NOT interpret the absence of a hash as a guarantee of integrity.

### 6.5 Verification cadence — per-invocation vs lifecycle

#### 6.5.1 Per-invocation checks

The §6.2 chain runs on every invocation: existence (§6.2.1), availability (§6.2.2), capability (§6.2.3), MCP trust (§6.2.5). The definition integrity check (§6.2.4) is currently a no-op (GAP-TM-11). Per §6.6, when GAP-TM-11 is OPEN the runtime refuses with `integrity_unverifiable` at step 7 of the §3.5 algorithm. No `integrity_state` value is recorded because the runtime enforces the invariant by default refusal.

#### 6.5.2 Lifecycle checks

Runs at session start, after any registry version change, after any MCP server restart. Runs the same per-invocation checks across the entire tool inventory. Does not include §6.2.4 (hash) — mechanism not implemented.

#### 6.5.3 What lifecycle checks do NOT do

Do not modify the registry. Do not invoke any tool. Do not override per-invocation checks.

### 6.6 Integrity Default Refusal

**The inherited security invariant** (§6.4.1): a tool whose definition is not verified MUST NOT be invoked. No exception.

**The current implementable capability** (§6.4.2): GAP-TM-11 OPEN. The runtime cannot verify definition integrity. A tool passing existence + availability + capability + MCP trust checks is runtime-eligible but **not** integrity-verified.

**The default behavior**: while GAP-TM-11 is OPEN, the runtime's default is to refuse all invocations. The **actual refusal reason code is the first failed check in the §3.5 algorithm order**:

- A tool that fails capability (§3.5 step 6) is refused with `verification_insufficient`.
- A tool that passes capability but reaches the integrity step (§3.5 step 7) is refused with `integrity_unverifiable`.

Because step 6 precedes step 7, a `discovered` tool correctly fails at step 6 with `verification_insufficient`; a `runtime_verified` tool correctly fails at step 7 with `integrity_unverifiable`. Both are refusals; the difference is the accurate reason code.

The runtime is non-operational until: (1) GAP-TM-11 is closed, or (2) a separate architecture revision grants a scoped exception.

**What this manifest does NOT do**: grant exceptions; declare tools invokable; track an exception lifecycle inside this file.

---

## 7. MCP Server Trust Interface

### 7.1 The interface

The MCP server for an MCP tool is the `provider` field of the matching entry in `runtime/registry.json` v0.7-rev2.

This file defines runtime behavior for MCP tools. The trust list (GAP-AS-03) defines which servers are trusted.

### 7.2 Current MCP servers referenced

| Server id (registry `provider`) | Tools | Trust status |
|---|---|---|
| `burp-mcp` | 24 burp_* tools | UNKNOWN (GAP-AS-03; trust list not yet created) |

### 7.3 Invocation rule (untrusted MCP)

Until the trust list is created (GAP-AS-03), every MCP server is **untrusted by default**. The runtime MUST:

- require **per-call operator approval** for every MCP tool invocation. The approval is obtained through the **single unified prompt** at §3.5 step 11 (see §6.2.5 — record-only, no separate prompt). An untrusted or unknown server imposes a non-bypassable `per_call` floor at §3.5 step 9d, regardless of any `pre_approved` or `none` override.
- quarantine the untrusted server's responses (they do not enter the model's reasoning context until the operator approves release via the post-response control at §3.5 step 11).
- **log only the untrusted server's identity and the non-content request/response metadata** necessary to audit the call, the quarantine decision, and the approval outcome. **Raw request/response bodies and any other untrusted content MUST NOT be placed in the observability log** (per `agent-security.md` §5.2 and §8.2).
- treat the response as tier 3 data once the operator approves its release.

### 7.4 The trust list requirement for pre-approval

**Rule**:

- If the MCP server is on the trust list → invocation may proceed under the effective `approval_class` for non-state-mutating tools (may be `pre_approved` for that environment).
- If the MCP server is NOT on the trust list → **per-call approval is required regardless of `approval_class`**. No environment pre-approval may bypass this.
- **State-mutating MCP tools (S6) require per-call approval regardless of trust-list status.** A trusted server does not relax the S6 floor. This rule is preserved verbatim from the v1.5 second-pass baseline.

Until the trust list exists, the second rule applies to every MCP tool: per-call approval, no pre-approval.

> ⚠️ **GAP-TM-05, GAP-TM-12**: until GAP-AS-03 resolves, every MCP invocation requires per-call approval.

---

## 8. Environment Configuration

### 8.1 The environment model

Each environment is identified by a name (e.g. `local-kali`, `lab-target`, `ctf`). The environment determines: `gating`, `approval_class`, `capability_requirement` (when relaxable).

The class-level default policy (§3.4) plus any per-tool record (§3.2) is the absolute default. An environment is a restrict-or-extend overlay.

When no environment is configured, the runtime uses the default environment `local-kali`.

> ⚠️ **GAP-TM-06**: `runtime/environments/<env-name>.md` not yet present.

### 8.2 Per-tool gating override

`environment_overrides` lists environments where the default `gating` is overridden. **Restrict-only**: an environment may move `enabled → gated → disabled` but never the reverse.

### 8.3 Per-class pre-approval

The pre-approval policy (§4.4) may be relaxed or restricted per environment. **MCP pre-approval is not allowed via environment** until the trust list exists (§7.4). S5 pre-approval requires a named external service in the environment's allowlist; S12 pre-approval requires an explicitly configured short background task.

### 8.4 Per-tool capability relaxation

`capability_requirement` may be relaxed per environment **only when `capability_relaxable: true`**. Definition integrity is never relaxable. **Capability relaxation does not bypass the §6.6 integrity refusal while GAP-TM-11 is OPEN.**

### 8.5 Environment override precedence

1. Class-level default policy (§3.4).
2. Per-tool record (§3.2).
3. Active environment's `environment_overrides`.
4. Verification chain (§6.2).
5. MCP trust check (§6.2.5).
6. Approval flow (§3.5 steps 9–11).

Override direction:

- `gating`: restrict-only.
- `approval_class`: either direction, subject to the §4.4 floor and normalized by §3.5 steps 9c–9e.
- `capability_requirement`: either direction, only when `capability_relaxable: true`.
- Definition integrity: never relaxable.
- MCP trust: never relaxable via environment.

---

## 9. Cross-References to Other Runtime Files

| File | Relationship |
|---|---|
| `runtime/registry.json` v0.7-rev2 (LOCKED) | References every tool by `registry_id`. |
| `runtime/redaction.md` (deferred) | Referenced by `redaction_required`. |
| `runtime/opencode/loader.md` (deferred) | Consults per-tool records. |
| `runtime/opencode/ORCHESTRATION.md` (deferred) | Consults for approval flow. |
| `runtime/opencode/manifest.md` (deferred) | Machine-readable form. |
| `runtime/model-routing.md` (deferred) | Independent. |

---

## 10. Self-Application

This file is authored using the discipline in `architecture/review-discipline.md`. The Builder:

- ran PRE-BUILD dependency extraction
- preserved inherited invariants from the Phase 1 contracts and `runtime/registry.json` v0.7-rev2
- did not modify any locked contract
- did not silently resolve any architectural GAP
- applied Reviewer verdicts through the v1.5 fourth pass, then performed one final bounded correction pass focused on confirmed approval, scope, authorization-coverage, and follow-up-request findings
- **v1.5 fourth pass (historical)**: applied R7 (no `none` from missing verb/API), R8 (normalize effective class to `per_call` for gated/untrusted MCP), R9 (distinguish default / floor / exception; restore S6 rule), and redirect handling (webfetch hop-by-hop). Restored policy text and GAP descriptions from the v1.5 second-pass baseline that were compressed in the third pass.
- **Final bounded correction pass**: clarified full scope evaluation before authorization coverage for every follow-up, cross-class redirect behavior, S5/S12 normalization, refusal code M, and OPEN GAP-TM-23 through GAP-TM-26. No implementation is claimed. Following the final review, the policy baseline was explicitly LOCKED by project-owner direction; all implementation gaps remain OPEN.

---

## 11. Source Attribution

Established as the canonical implementation site for `agent-security.md` §5.1, §5.3, §8, and the GAP-AS-01 / GAP-AS-04 OPEN TODOs. Integration sources: `agent-security.md` §5, §6, §7, §8; `runtime/registry.json` v0.7-rev2; `file-contracts.md` §4.2; `validation-model.md` §8; `review-discipline.md`; `blueprint-v3.md`. Does not invent new security principles.

---

## 12. Open Questions for Architect Decision

1. GAP-AS-01 formal closure — authorize §4 enumeration?
2. GAP-AS-04 formal closure — authorize §6 verification policy?
3. Integrity default refusal (§6.6) — close GAP-TM-11 or authorize separate architecture revision?
4. Network destination check semantics (§3.5.2) — accept the per-invocation classification rules, including positive-establishment requirement for `none` (R7) and redirect-hop classification (R2 note)?
5. Unified MCP authorization (§3.5 steps 9–11) — accept single prompt with effective class normalized to `per_call` for gated/untrusted cases (R8)?
6. Default vs floor vs exception (§4.4, §3.5 step 9) — accept the three-column distinction (R9)?
7. S6 state-mutating MCP tools — confirm the restored per-call floor applies **regardless of trust-list status**.
8. Deterministic `approval_downgrade_denied` — accept policy-error semantics?
9. Fail-closed redaction (§3.5 step 12) — accept fail-closed in all modes?
10. Refuse reason codes — confirm K and L acceptable?
11. Operator prompts and approval flow — deferred to `runtime/opencode/ORCHESTRATION.md`.
12. Default environment — `local-kali` acceptable?
13. Per-tool records optional — confirm.
14. §3.4 class split — accept?
15. Dependency status of `agent-security.md` — verify whether the authoritative repository version is LOCKED/production.
16. S5 external-service allowlist (GAP-TM-20) — confirm the mechanism belongs to `runtime/environments/<env-name>.md`.
17. Browser subrequest inspection (GAP-TM-21) — confirm the fail-closed default until inspection capability exists.
18. Redirect inspection (GAP-TM-22, new) — confirm the block-redirects-or-fail-closed default until redirect inspection capability exists.
19. Hidden network access through interpreters, wrappers, dynamic calls (GAP-TM-18 extension) — confirm the fail-closed default applies to `shell` and `execute` when the classifier cannot positively establish `none`.
20. (final bounded correction pass) Per-hop scope checking — confirm that complete destination scope evaluation, including path/resource/query/method where relevant, occurs before authorization coverage is evaluated (GAP-TM-26).
21. (final bounded correction pass) Authorization-to-destination binding — confirm the exact-request and scope-bounded authorization record semantics and fail-closed behavior until implemented (GAP-TM-25).
22. (final bounded correction pass) Cross-class redirects — confirm target ↔ external/research and external ↔ research hops are refused unless exact authorization coverage or a fully valid service-specific S5 pre-approval exception applies.
23. (final bounded correction pass) Redirect/CLI link interception — confirm disabled auto-follow or fail-closed behavior until every follow-up request can be inspected before send (GAP-TM-22 / GAP-TM-23).

---

## 13. ⚠️ GAP NOTES

### GAP-TM-01: Per-tool records not yet filled — SUPERSEDED

### GAP-TM-02: Pre-approval override mechanism — OPEN

### GAP-TM-03: Hash algorithm and rotation — MERGED INTO GAP-TM-11

### GAP-TM-04: Hash check is currently a no-op — OPEN

### GAP-TM-05: MCP trust list not yet created — OPEN

### GAP-TM-06: Environment file not yet created — OPEN

### GAP-TM-07: Sensitive operation class completeness — OPEN

### GAP-TM-08: Per-tool records for builtins — OPEN but non-blocking

### GAP-TM-09: Sensitive operation pre-approval audit log — OPEN

### GAP-TM-10: Per-tool capability_requirement defaults — SUPERSEDED

### GAP-TM-11: Canonical hash storage location — OPEN

### GAP-TM-12: MCP pre-approval path before trust list — OPEN

### GAP-TM-13: Integrity eligibility — REJECTED in v1.4 as exception

### GAP-TM-14: Destination check on network operations — OPEN
Per-invocation classification rules documented in §3.5.2. The concrete classifier implementation is deferred. Ambiguous cases fail closed.

### GAP-TM-15: Unified MCP authorization — OPEN
Operator prompt format deferred to `runtime/opencode/ORCHESTRATION.md`.

### GAP-TM-16: Approval downgrade policy error semantics — OPEN

### GAP-TM-17: Fail-closed redaction in all failure modes — OPEN

### GAP-TM-18: (v1.5) Egress-class parser implementation and positive-establishment of `none` — OPEN
**Extended in v1.5-4R7.** The parser for extracting the destination from a call's arguments/command/code is not implemented. Additionally, the classifier cannot positively establish `none` for arbitrary commands/code — interpreters, wrappers, dynamic calls can hide network access. Fail-closed default.

### GAP-TM-19: (v1.5) `agent-security.md` dependency status — OPEN

### GAP-TM-20: (v1.5-2) S5 external-service allowlist — OPEN
The named external-service allowlist used in `external` classification is deferred to the environment configuration file. Until it exists, generic tools (shell, execute, webfetch) cannot be positively classified as `external`; such calls fail closed.

### GAP-TM-21: (v1.5-3) Browser subrequest inspection — OPEN
The ability to inspect cross-origin subrequests individually is not implemented. Until it is, browser navigation that triggers subrequests to hosts whose classification cannot be established fails closed with `destination_unverifiable`.

### GAP-TM-22: (v1.5-4) Redirect-hop inspection — OPEN
The ability to inspect HTTP redirect destinations **before** sending the follow-up request is not implemented. Until it is, automatic redirect following must be disabled (block redirects) or the invocation must fail closed with `destination_unverifiable`. Applies to `builtin-webfetch`; the same principle applies to redirects followed by `builtin-browser` and CLI tools that follow redirects.

### GAP-TM-23: (final bounded correction pass) CLI redirect and crawler-link interception — OPEN
The runtime cannot currently inspect all CLI-generated follow-up requests before send, including redirects, crawler-discovered links, repeated probes, and other requests derived from page content or discovery sources. Disable the relevant follow-up behavior or fail closed before sending until interception is implemented. Also applies to `builtin-shell`, `builtin-execute`, and `mcp-send` where they issue or follow multiple requests.

### GAP-TM-24: (final bounded correction pass) S5 external/research service-identity verification — OPEN
The explicit identity-verification mechanism for a named external/research service is not implemented. An allowlist string by itself does not prove service identity. Until verification exists, S5 pre-approval is unavailable for that service; retain `per_call` or fail closed if the destination cannot be established.

### GAP-TM-25: (final bounded correction pass) Authorization-to-destination binding — OPEN
The runtime cannot currently bind the initial operator authorization to the complete request identity or an explicitly scope-bounded operation. Until implemented, a follow-up request whose coverage cannot be proven must not be sent. For a known but uncovered destination, refuse with `hop_not_authorized`; if destination identity is unknown, use `destination_unverifiable`.

### GAP-TM-26: (final bounded correction pass) URL normalization and per-hop scope evaluation — OPEN
The runtime does not yet provide a verified, deterministic way to normalize and validate every follow-up request against the scope semantics in `testing/<target>/scope.md`. Required cases include relative/protocol-relative redirects; lowercase scheme/host normalization; IDNA/punycode and trailing-dot handling; effective default ports; canonical IPv4/IPv6 literals; rejection of user-info/authority ambiguities; path/query normalization without double-decoding; method/operation parameters where relevant; parser/transport agreement; redirect chains; and hostname-to-connection identity binding where scope rules require it. Ambiguous destination identity fails closed with `destination_unverifiable`; unavailable or ambiguous scope interpretation fails closed with `scope_unverifiable`. No host/port tuple may bypass full scope checking.

**Status of the contract itself:** `LOCKED` (v1.5 policy baseline; runtime implementation incomplete). This lock freezes the policy text as the governing baseline for subsequent implementation. It does **not** claim production-operational runtime behavior, does not close any GAP, and does not authorize tool invocations while GAP-TM-11 remains OPEN. All relevant GAPs remain OPEN. Any future policy change requires a new versioned revision and explicit authorization.
