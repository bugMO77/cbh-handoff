# 🐞 Buggy

**AI-Assisted Bug Bounty Hunting Workspace**

> **AI proposes. Runtime proves. Human decides.**

![status](https://img.shields.io/badge/status-early%20scaffold-6f42c1)
![approach](https://img.shields.io/badge/approach-human--in--the--loop-0e7e0e)
![focus](https://img.shields.io/badge/focus-web%20%26%20API%20bug%20bounty-1f6feb)

---

## Repository Status — Read This First

Buggy is a **personal** security research project in its **initial construction phase**.

Today, this repository is an **empty scaffold**: the canonical directory structure and
contract filenames are established, but **every file is a placeholder stub awaiting
content** (`README.md`, the `architecture/*.md` contracts, each `SKILL.md`, every command
and template, the `learning_engine/`, `automation/`, `retrieval/` and `scripts/` sources,
and the `memory/` ledgers are all currently empty).

In short:

- **Nothing in this repository is operational yet.**
- No capability described below is implemented, installed, or testable.
- The sections that follow describe the **intended design and roadmap**, not shipped features.

The tree is scaffolding for a serious system; none of it should be treated as
production-ready code or guide content today.

---

## What Is Buggy?

Buggy is a **personal, human-in-the-loop security research environment** designed to
improve **web and API bug bounty hunting** through:

- structured reconnaissance
- vulnerability-oriented methodology
- AI-assisted hypothesis generation
- runtime-backed validation
- evidence collection
- reusable security knowledge
- persistent hunting memory
- regression and run comparison
- learning from actual hunting outcomes

Buggy is **not** an autonomous hacking bot. It combines security methodology, AI-assisted
reasoning, runtime execution, evidence collection, validation, persistent memory,
regression, and learning — with a human hunter making every final decision.

## Core Philosophy

### AI ≠ Proof

AI can:

- generate hypotheses
- identify suspicious behavior
- suggest attack paths
- prioritize possibilities
- reason over existing evidence

AI output alone does **not** establish a vulnerability.

### Runtime = Evidence

Evidence comes from actual execution:

- requests and responses
- browser behavior
- authorization state
- callbacks
- reproducible changes
- demonstrated impact

### Human = Final Judgment

The hunter decides:

- whether behavior is actually vulnerable
- whether it is in scope
- whether the security boundary was crossed
- whether the evidence is sufficient
- whether the issue is reportable

| Layer    | Responsibility                                        |
|----------|-------------------------------------------------------|
| AI       | Hypotheses, reasoning, prioritization                 |
| Runtime  | Execution and evidence                                |
| Knowledge| Methodology and security concepts                     |
| Memory   | Lessons from actual hunts                             |
| Human    | Final validation and reporting                        |

## Why Buggy Exists

Long-form hunting suffers from well-known failure modes that Buggy is designed to address:

- repeated rediscovery of the same knowledge
- weak organization during long hunting sessions
- losing useful lessons from previous hunts
- overloading agents with too much context
- treating AI guesses as findings
- lack of structured validation
- difficulty comparing different hunting runs
- no persistent methodology that improves over time

The goal is a methodology that gets **better with use**, powered by evidence and actual
outcomes rather than disconnected prompts.

## High-Level Architecture

```
Hunter
  ↓
Buggy
  ↓
┌───────────────┬───────────────┬───────────────┐
Knowledge       Methodology    Runtime
  ↓                ↓               ↓
concepts         skills      Burp / Browser
writeups         commands    MCP / OOB / Tools
research         validation
  └───────────────┼────────────────┘
                  ↓
          Evidence / Findings
                  ↓
               Memory
                  ↓
              Learning
```

This is a conceptual view. The detailed contracts live in
[`architecture/`](architecture/) and are currently being authored.

## The Hunting Loop

Buggy is **function-centric** rather than blindly endpoint-centric.

```
Research
↓
Scope Verification
↓
Identity Setup
↓
Surface Discovery
↓
Function Mapping
↓
Hypothesis Generation
↓
Targeted Testing
↓
Runtime Validation
↓
Evidence Collection
↓
Triage
↓
Reporting
↓
Regression
↓
Learning
```

Each stage has a corresponding command or skill in the planned tree (see
[Repository Structure](#repository-structure)).

## What Buggy Actually Supports

> **Status: nothing is implemented yet.**

Because every file is currently an empty stub, the honest capability matrix is:

### Implemented

None. The repository is scaffolding; no subsystem is operational.

### In Progress

None currently contain content. The directory tree below anticipates the upcoming work
and is described in [Planned / Deferred](#planned--deferred).

### Planned / Deferred

The intended design anticipates these capabilities (mapped to the scaffold below):

| Capability                                        | Scaffold location |
|---------------------------------------------------|-------------------|
| Reconnaissance support                            | `.opencode/skills/recon`, `.opencode/commands/recon` |
| Scope verification                                | `.opencode/skills/scope-bootstrap`, `.opencode/commands/scope-check` |
| Program research                                  | `.opencode/skills/program-research`, `.opencode/commands/research` |
| JavaScript discovery and analysis                 | `.opencode/skills/js-discovery`, `.opencode/skills/js-analyze` |
| Access control / IDOR / BAC methodology           | `.opencode/skills/access-control`, `concepts/vulnerability-classes/access-control`, `concepts/vulnerability-classes/idor` |
| XSS methodology                                   | `.opencode/skills/xss`, `concepts/vulnerability-classes/xss` |
| Identity / account setup                          | `.opencode/skills/identities` |
| Validation gates and false-positive handling      | `.opencode/skills/validator`, `.opencode/commands/validate`, `concepts/false-positives` |
| Hunting memory and context ledgers                | `memory/`, `.opencode/skills/session-search` |
| Run comparison and regression                     | `.opencode/commands/compare-runs`, `.opencode/skills/regression`, `learning_engine/run_comparison` |
| Report drafting and triage                        | `.opencode/skills/report-writer`, `.opencode/commands/report`, `.opencode/commands/triage` |
| Learning engine (lessons, analytics, ingestion)   | `learning_engine/` |
| Knowledge pipeline (fetch → process → index → retrieve) | `knowledge/`, `retrieval/`, `scripts/fetch`, `scripts/process`, `scripts/index`, `scripts/learn` |
| Monitoring and change detection                   | `automation/`, `.opencode/commands/monitor`, `.opencode/commands/mindmap`, `.opencode/commands/update` |

These are **intended directions**, not shipped behavior. Capabilities will be moved to
"Implemented" only once the corresponding code, skills, and validation actually exist and
work.

## Validation Model

A hypothesis becomes a finding only after passing a **validation gate**:

1. Scope
2. Reproducibility
3. Authorization Context
4. Security Boundary
5. Evidence
6. Alternative Explanation
7. Impact

```
Suspicion → Hypothesis → Validation → Finding
```

An unvalidated AI output is **not** a finding. See
[`architecture/validation-model.md`](architecture/validation-model.md) for the detailed
model (currently being authored).

## What Buggy Is Not

- **not** a fully autonomous hacking bot
- **not** an agent swarm
- **not** a generic multi-agent framework
- **not** a replacement for Burp Suite
- **not** a vulnerability scanner
- **not** a collection of disconnected prompts
- **not** a system that treats LLM output as security proof

Buggy intentionally prioritizes evidence, methodology, and human judgment over automation
for its own sake.

## Repository Structure

| Directory          | Purpose                                                        |
|--------------------|----------------------------------------------------------------|
| `.opencode/`       | Skills, commands and agent definitions                         |
| `architecture/`    | Architecture contracts and design rules                        |
| `knowledge/`       | External security knowledge source material                    |
| `concepts/`        | Synthesized security concepts                                  |
| `memory/`          | Lessons learned from actual hunting                            |
| `runtime/`         | Runtime contracts, tooling and model routing                   |
| `templates/`       | Reusable hunting and target templates                          |
| `testing/`         | Target-specific hunting state                                  |
| `learning_engine/` | Learning and run-analysis infrastructure                       |
| `retrieval/`       | Knowledge retrieval layer                                      |
| `automation/`      | Monitoring and change-detection infrastructure                 |
| `scripts/`         | Deterministic tooling and system glue                          |
| `wordlists/`       | Reusable testing data                                          |

This tree is currently a scaffold — see
[Repository Status](#repository-status--read-this-first).

## Knowledge and Learning

Buggy keeps two different classes of information separate.

**Knowledge** — external source material:

```
Source material
→ processed extraction
→ concepts
→ retrieval
→ skills
```

**Learning** — from actual hunts:

```
Findings
→ false positives
→ misses
→ run outcomes
→ report outcomes
→ lessons
→ memory
→ methodology improvement
```

External knowledge and hard-won lessons from real hunting are different classes of
information and are handled differently. `knowledge/` and `concepts/` hold the former; the
`learning` path is grounded in `memory/` and `learning_engine/` outputs.

## Runtime

At a high level, the runtime spans:

- OpenCode (the agent harness Buggy runs on)
- Burp Suite and Burp MCP
- browser automation (Playwright / Chromium)
- OOB interaction tooling
- security CLI tooling
- model routing

Model routing is **operational configuration**, not project identity — do not hardcode
provider/model choices here. See `runtime/` for operational behavior, currently basing
authoring on [`runtime/model-routing.md`](runtime/model-routing.md) and
[`runtime/opencode/`](runtime/opencode/) once they contain content.

## Design Principles

- Human-in-the-loop
- Few agents, many skills
- Function-centric testing
- Evidence before findings
- Deterministic tooling before AI
- External state over giant context
- Explicit scope enforcement
- Persistent hunting memory
- Independent validation where practical
- Reproducible execution
- Small, focused execution contexts
- No duplicated sources of truth

## Documentation Map

Architectural contracts live in `architecture/` (every file currently a placeholder):

- [`architecture/file-contracts.md`](architecture/file-contracts.md)
- [`architecture/agent-architecture-rules.md`](architecture/agent-architecture-rules.md)
- [`architecture/validation-model.md`](architecture/validation-model.md)
- [`architecture/knowledge-flow.md`](architecture/knowledge-flow.md)
- [`architecture/learning-flow.md`](architecture/learning-flow.md)
- [`architecture/agent-security.md`](architecture/agent-security.md)
- [`architecture/model-routing.md`](architecture/model-routing.md)

Operational detail, once authored, lives under `runtime/`. All of these are **in
progress** and currently contain no content.

## Project Status

**Active development — scaffolding phase.**

The current focus is establishing:

- architecture contracts
- runtime contracts
- templates
- core skills
- commands
- target workflow
- learning infrastructure
- retrieval
- controlled automation

No fake progress percentages, no invented version numbers, no production-readiness
claims. The honest status is: directory tree and contract filenames committed; content
authoring has begun; nothing is functional yet.

## Development

Buggy is primarily a **personal** security research project.

Changes should preserve the architectural contracts and avoid introducing duplicate
sources of truth. Before touching architecture-sensitive areas, review:

- `AGENTS.md`
- `architecture/`
- the relevant file contracts

Prefer small, focused changes that respect the canonical structure.

---

*Documentation status: every linked contract currently exists as an empty placeholder and
is being authored. Links are to real files only.*
