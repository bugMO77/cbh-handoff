"""
scripts/test_runtime_contract.py
================================
Fail-closed invocation-boundary tests.

Covers:
  1. Canonical-ID lookup for all 70 registry records using the real,
     file-backed ``JSONRegistry``.
  2. The three known key/ID mismatches in ``registry.json`` resolve
     by canonical ID.
  3. Duplicate IDs, malformed shapes, missing files, and invalid JSON
     all fail closed.
  4. Malformed ``tool_id`` is distinguished from an integrity refusal.
  5. A known registered tool is refused with ``integrity_unverifiable``
     while GAP-TM-11 is OPEN.
  6. Unknown, unavailable, and invalid tool requests are refused.
  7. The injected backend sees zero calls on every denied path.
  8. The locked ``runtime/registry.json`` is byte-for-byte unchanged.
  9. ``InvocationResult`` cannot represent an authorized invocation
     while GAP-TM-11 is OPEN.
 10. Non-string ``availability`` values fail closed in both registry
     implementations.

No registered Buggy tool is executed. All backend interactions use
``NoOpBackend``; all registry interactions in unit-level tests use
``InMemoryRegistry``; the real-file tests use ``JSONRegistry``.

Run with:
    python -m unittest scripts.test_runtime_contract -v
or:
    python scripts/test_runtime_contract.py
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
import unittest

# Ensure the module under test is importable when this file is run
# directly or via `python -m unittest scripts.test_runtime_contract`.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from runtime_preflight import (  # noqa: E402
    RefusalCode,
    InvocationResult,
    InvokerBoundary,
    NoOpBackend,
    InMemoryRegistry,
    JSONRegistry,
    RegistryShapeError,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_tool(tool_id, availability="present"):
    return {"id": tool_id, "type": "cli", "availability": availability}


def _write_registry(tmp_dir, payload):
    path = os.path.join(tmp_dir, "registry.json")
    with open(path, "w", encoding="utf-8") as fh:
        if isinstance(payload, str):
            fh.write(payload)
        else:
            json.dump(payload, fh)
    return path


# ---------------------------------------------------------------------------
# 1 & 2. Canonical-ID lookup via the real JSONRegistry
# ---------------------------------------------------------------------------

class TestJSONRegistryCanonicalLookup(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.registry = JSONRegistry()
        cls.registry_path = cls.registry.REGISTRY_PATH

    def test_registry_file_exists(self):
        self.assertTrue(
            os.path.isfile(self.registry_path),
            f"registry.json not found at {self.registry_path!r}",
        )

    def test_all_70_canonical_ids_resolve(self):
        ids = self.registry.list_ids()
        self.assertEqual(
            len(ids), 70,
            f"expected 70 canonical IDs, found {len(ids)}",
        )
        for tool_id in ids:
            with self.subTest(tool_id=tool_id):
                record = self.registry.get_tool(tool_id)
                self.assertIsNotNone(record, f"{tool_id} did not resolve")
                self.assertEqual(record.get("id"), tool_id)

    def test_three_known_key_id_mismatches(self):
        """The registry's dictionary keys differ from the canonical IDs
        for these three entries. Lookup by canonical ID must succeed."""
        known_mismatches = {
            "opencode_models":         "opencode.models",
            "opencode_session_move":   "opencode.session_move",
            "opencode_session_rename": "opencode.session_rename",
        }
        for key, canonical_id in known_mismatches.items():
            with self.subTest(key=key, canonical_id=canonical_id):
                record = self.registry.get_tool(canonical_id)
                self.assertIsNotNone(
                    record,
                    f"canonical ID {canonical_id!r} did not resolve",
                )
                self.assertEqual(record.get("id"), canonical_id)

    def test_all_70_refused_with_backend_zero_calls(self):
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=self.registry)
        for tool_id in self.registry.list_ids():
            with self.subTest(tool_id=tool_id):
                result = boundary.check_invocation(tool_id, {})
                self.assertTrue(result.refused)
        self.assertEqual(backend.call_count, 0)


# ---------------------------------------------------------------------------
# 3. Fail-closed on malformed registry inputs
# ---------------------------------------------------------------------------

class TestRegistryFailClosed(unittest.TestCase):

    def test_missing_registry_file(self):
        with tempfile.TemporaryDirectory() as td:
            missing = os.path.join(td, "does-not-exist.json")
            registry = JSONRegistry(path=missing)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertTrue(result.refused)
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            # No path or exception detail leaks into the reason.
            self.assertNotIn(td, result.reason)
            self.assertEqual(backend.call_count, 0)

    def test_invalid_json(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, "{ this is not json }")
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertNotIn(td, result.reason)
            self.assertEqual(backend.call_count, 0)

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, "")
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_top_level_not_object(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, json.dumps(["not", "an", "object"]))
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_tools_not_object(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, {"tools": ["not", "a", "dict"]})
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_record_not_object(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(
                td, {"tools": {"subfinder": "not-a-record"}}
            )
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_record_missing_id(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(
                td, {"tools": {"subfinder": {"availability": "present"}}}
            )
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_record_invalid_availability_string(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(
                td,
                {"tools": {"subfinder": {
                    "id": "subfinder",
                    "availability": "maybe",
                }}},
            )
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("subfinder", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)

    def test_duplicate_canonical_id(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, {"tools": {
                "alias-a": {
                    "id": "same_id",
                    "availability": "present",
                },
                "alias-b": {
                    "id": "same_id",
                    "availability": "present",
                },
            }})
            registry = JSONRegistry(path=path)
            backend = NoOpBackend()
            boundary = InvokerBoundary(backend=backend, registry=registry)
            result = boundary.check_invocation("same_id", {})
            self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
            self.assertEqual(backend.call_count, 0)


# ---------------------------------------------------------------------------
# 3b. Non-string availability fails closed in JSONRegistry (Finding 2)
# ---------------------------------------------------------------------------

class TestJSONRegistryAvailabilityTypeValidation(unittest.TestCase):
    """Non-string availability values must raise RegistryShapeError and
    be surfaced as REGISTRY_ERROR, not as a TypeError."""

    def _check_path(self, td, availability):
        path = _write_registry(td, {"tools": {
            "subfinder": {"id": "subfinder", "availability": availability},
        }})
        registry = JSONRegistry(path=path)
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        result = boundary.check_invocation("subfinder", {})
        self.assertEqual(result.code, RefusalCode.REGISTRY_ERROR)
        self.assertEqual(backend.call_count, 0)
        self.assertNotIn(td, result.reason)

    def test_availability_list_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            self._check_path(td, ["present"])

    def test_availability_object_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            self._check_path(td, {"value": "present"})

    def test_availability_none_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            self._check_path(td, None)

    def test_availability_int_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            self._check_path(td, 1)

    def test_shape_error_raised_directly(self):
        with tempfile.TemporaryDirectory() as td:
            path = _write_registry(td, {"tools": {
                "subfinder": {
                    "id": "subfinder",
                    "availability": ["present"],
                },
            }})
            registry = JSONRegistry(path=path)
            with self.assertRaises(RegistryShapeError):
                registry.list_ids()


# ---------------------------------------------------------------------------
# 4. Malformed input vs integrity refusal
# ---------------------------------------------------------------------------

class TestMalformedInputVsIntegrityRefusal(unittest.TestCase):

    def setUp(self):
        self.registry = InMemoryRegistry([make_tool("subfinder")])
        self.backend = NoOpBackend()
        self.boundary = InvokerBoundary(
            backend=self.backend, registry=self.registry,
        )

    def test_malformed_tool_id_is_local_code(self):
        for bad in ["", "   ", None, 123, [], {}, True, b"bytes"]:
            with self.subTest(tool_id=bad):
                result = self.boundary.check_invocation(bad, {})
                self.assertTrue(result.refused)
                self.assertEqual(result.code, RefusalCode.MALFORMED_INPUT)
                self.assertFalse(result.code.manifest_defined)
                self.assertFalse(result.gap_tm11_blocked)
        self.assertEqual(self.backend.call_count, 0)

    def test_unknown_tool_is_manifest_not_in_registry(self):
        result = self.boundary.check_invocation("unknown", {})
        self.assertEqual(result.code, RefusalCode.NOT_IN_REGISTRY)
        self.assertTrue(result.code.manifest_defined)
        self.assertFalse(result.gap_tm11_blocked)
        self.assertEqual(self.backend.call_count, 0)

    def test_well_formed_known_tool_is_integrity_refusal(self):
        # Arbitrary request shapes must not change the outcome.
        for req in [None, {}, {"a": 1}, [1, 2], "just a string", 42]:
            with self.subTest(request=type(req).__name__):
                result = self.boundary.check_invocation("subfinder", req)
                self.assertEqual(
                    result.code, RefusalCode.INTEGRITY_UNVERIFIABLE,
                )
                self.assertTrue(result.code.manifest_defined)
                self.assertTrue(result.gap_tm11_blocked)
        self.assertEqual(self.backend.call_count, 0)


# ---------------------------------------------------------------------------
# 5 & 6. Known / unknown / unavailable tool refusals
# ---------------------------------------------------------------------------

class TestKnownToolRefusedWhileGapOpen(unittest.TestCase):

    def test_known_tool_refused(self):
        registry = InMemoryRegistry([make_tool("subfinder")])
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        result = boundary.check_invocation("subfinder", {"targets": ["x"]})
        self.assertTrue(result.refused)
        self.assertEqual(result.code, RefusalCode.INTEGRITY_UNVERIFIABLE)
        self.assertTrue(result.gap_tm11_blocked)
        self.assertIn("GAP-TM-11", result.reason)
        self.assertEqual(backend.call_count, 0)

    def test_unavailable_tool_refused(self):
        registry = InMemoryRegistry([make_tool("subfinder", availability="absent")])
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        result = boundary.check_invocation("subfinder", {})
        self.assertEqual(result.code, RefusalCode.UNAVAILABLE)
        self.assertFalse(result.gap_tm11_blocked)
        self.assertEqual(backend.call_count, 0)

    def test_unknown_availability_refused(self):
        registry = InMemoryRegistry([make_tool("subfinder", availability="unknown")])
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        result = boundary.check_invocation("subfinder", {})
        self.assertEqual(result.code, RefusalCode.UNAVAILABLE)
        self.assertEqual(backend.call_count, 0)


# ---------------------------------------------------------------------------
# 7. Backend sees zero calls on every denied path
# ---------------------------------------------------------------------------

class TestBackendZeroCalls(unittest.TestCase):

    def _boundary(self, records):
        backend = NoOpBackend()
        registry = InMemoryRegistry(records)
        return backend, InvokerBoundary(backend=backend, registry=registry)

    def test_zero_calls_known(self):
        backend, boundary = self._boundary([make_tool("subfinder")])
        for _ in range(3):
            boundary.check_invocation("subfinder", {"x": 1})
        self.assertEqual(backend.call_count, 0)

    def test_zero_calls_unknown(self):
        backend, boundary = self._boundary([make_tool("subfinder")])
        boundary.check_invocation("nope", {})
        self.assertEqual(backend.call_count, 0)

    def test_zero_calls_malformed(self):
        backend, boundary = self._boundary([make_tool("subfinder")])
        boundary.check_invocation("", {})
        boundary.check_invocation(None, {})
        self.assertEqual(backend.call_count, 0)

    def test_zero_calls_unavailable(self):
        backend, boundary = self._boundary(
            [make_tool("subfinder", availability="absent")]
        )
        boundary.check_invocation("subfinder", {})
        self.assertEqual(backend.call_count, 0)

    def test_zero_calls_high_volume(self):
        backend, boundary = self._boundary(
            [make_tool(t) for t in ["a", "b", "c"]]
        )
        for _ in range(1000):
            boundary.check_invocation("a", {})
        self.assertEqual(backend.call_count, 0)


# ---------------------------------------------------------------------------
# 8. Locked registry unchanged, byte-for-byte
# ---------------------------------------------------------------------------

class TestLockedRegistryUnchanged(unittest.TestCase):

    def test_registry_bytes_unchanged_after_checks(self):
        path = JSONRegistry.REGISTRY_PATH
        self.assertTrue(os.path.isfile(path))

        with open(path, "rb") as fh:
            before = hashlib.sha256(fh.read()).hexdigest()

        registry = JSONRegistry(path=path)
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        for tool_id in registry.list_ids():
            boundary.check_invocation(tool_id, {})

        with open(path, "rb") as fh:
            after = hashlib.sha256(fh.read()).hexdigest()

        self.assertEqual(
            before, after,
            "registry.json was modified during the test run",
        )


# ---------------------------------------------------------------------------
# 9. InvocationResult fail-closed invariant (Finding 1 regression)
# ---------------------------------------------------------------------------

class TestInvocationResultFailClosedInvariant(unittest.TestCase):
    """While GAP-TM-11 is OPEN, no InvocationResult may report
    permitted=True. Direct construction with refused=False must be
    rejected."""

    def test_direct_construction_with_refused_false_rejected(self):
        with self.assertRaises(ValueError):
            InvocationResult(
                refused=False,
                code=RefusalCode.INTEGRITY_UNVERIFIABLE,
                reason="should not be constructible",
                tool_id="test",
            )

    def test_direct_construction_with_refused_false_rejected_for_all_codes(self):
        for code in RefusalCode:
            with self.subTest(code=code):
                with self.assertRaises(ValueError):
                    InvocationResult(
                        refused=False,
                        code=code,
                        reason="x",
                        tool_id="y",
                    )

    def test_direct_construction_with_refused_true_accepted(self):
        result = InvocationResult(
            refused=True,
            code=RefusalCode.INTEGRITY_UNVERIFIABLE,
            reason="x",
            tool_id="y",
        )
        self.assertFalse(result.permitted)
        self.assertFalse(bool(result))
        self.assertTrue(result.refused)

    def test_no_boundary_result_can_report_permitted(self):
        registry = InMemoryRegistry([make_tool("subfinder")])
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        for tool_id in ["subfinder", "unknown", "", None, "   "]:
            with self.subTest(tool_id=tool_id):
                result = boundary.check_invocation(tool_id, {})
                self.assertFalse(result.permitted)
                self.assertFalse(bool(result))
                self.assertTrue(result.refused)


# ---------------------------------------------------------------------------
# 10. Non-string availability fails closed in InMemoryRegistry (Finding 2)
# ---------------------------------------------------------------------------

class TestInMemoryRegistryAvailabilityTypeValidation(unittest.TestCase):
    """Non-string availability must raise RegistryShapeError rather than
    letting TypeError escape."""

    def test_availability_list_rejected(self):
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{
                "id": "subfinder",
                "availability": ["present"],
            }])

    def test_availability_object_rejected(self):
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{
                "id": "subfinder",
                "availability": {"value": "present"},
            }])

    def test_availability_none_rejected(self):
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{
                "id": "subfinder",
                "availability": None,
            }])

    def test_availability_int_rejected(self):
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{
                "id": "subfinder",
                "availability": 1,
            }])


# ---------------------------------------------------------------------------
# Public API semantics
# ---------------------------------------------------------------------------

class TestResultSemantics(unittest.TestCase):

    def test_no_truthy_result_while_gap_open(self):
        registry = InMemoryRegistry([make_tool("subfinder")])
        backend = NoOpBackend()
        boundary = InvokerBoundary(backend=backend, registry=registry)
        for tool_id in ["subfinder", "unknown", "", None]:
            with self.subTest(tool_id=tool_id):
                result = boundary.check_invocation(tool_id, {})
                self.assertFalse(bool(result))
                self.assertFalse(result.permitted)
                self.assertTrue(result.refused)

    def test_manifest_defined_classification(self):
        self.assertTrue(
            RefusalCode.INTEGRITY_UNVERIFIABLE.manifest_defined,
        )
        self.assertTrue(RefusalCode.NOT_IN_REGISTRY.manifest_defined)
        self.assertTrue(RefusalCode.UNAVAILABLE.manifest_defined)
        self.assertFalse(RefusalCode.MALFORMED_INPUT.manifest_defined)
        self.assertFalse(RefusalCode.REGISTRY_ERROR.manifest_defined)

    def test_registry_shape_error_is_raised_by_inmemory(self):
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{"id": "", "availability": "present"}])
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([
                {"id": "a", "availability": "present"},
                {"id": "a", "availability": "present"},
            ])
        with self.assertRaises(RegistryShapeError):
            InMemoryRegistry([{"id": "a", "availability": "invalid"}])


if __name__ == "__main__":
    unittest.main(verbosity=2)
