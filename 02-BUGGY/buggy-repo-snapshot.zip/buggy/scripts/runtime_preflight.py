"""
scripts/runtime_preflight.py
============================
Fail-closed invocation boundary — first runtime slice.

Enforces ``tool-manifest.v1.5`` §6.6: while ``GAP-TM-11`` is OPEN, every
tool invocation is refused before the execution backend is consulted.

**This module is not a complete runtime.** It contains no dispatch path,
no execution loop, and no per-tool schema. It provides only the
following guarantees:

* it decides whether an invocation may proceed, using the locked
  ``runtime/registry.json`` and the locked ``runtime/tool-manifest.md``
  v1.5 §6.6 invariant;
* while ``GAP-TM-11`` is OPEN, it always refuses, regardless of input;
* it never forwards a request to the execution backend;
* it never modifies the registry file or any other file.

GAP-TM-11 remains OPEN. This module does not close it.

Public API
----------
RefusalCode, InvocationResult, InvokerBoundary, NoOpBackend,
InMemoryRegistry, JSONRegistry, RegistryShapeError, build_boundary.

No dependencies outside the Python standard library.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from enum import Enum
from typing import Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Refusal codes
# ---------------------------------------------------------------------------

class RefusalCode(Enum):
    """Reasons this boundary may refuse an invocation.

    **Manifest-defined** (``tool-manifest.md`` v1.5 §6.3):

    * ``INTEGRITY_UNVERIFIABLE`` — §6.3.L; refusal while GAP-TM-11 is OPEN.
    * ``NOT_IN_REGISTRY``         — §6.3.A; tool not present in the registry.
    * ``UNAVAILABLE``             — §6.3.B'; tool not ``present`` in the environment.

    **Local to this boundary component** (not defined by the locked manifest):

    * ``MALFORMED_INPUT``         — caller passed an invalid ``tool_id``.
    * ``REGISTRY_ERROR``          — registry file missing, unreadable,
                                     malformed, or containing duplicates.
    """

    INTEGRITY_UNVERIFIABLE = "integrity_unverifiable"
    NOT_IN_REGISTRY        = "not_in_registry"
    UNAVAILABLE            = "unavailable"
    MALFORMED_INPUT        = "malformed_input"
    REGISTRY_ERROR         = "registry_error"

    def __str__(self) -> str:
        return self.value

    @property
    def manifest_defined(self) -> bool:
        """True for codes that the locked manifest enumerates; False for
        local codes that this boundary defines on its own."""
        return self in _MANIFEST_REFUSAL_CODES


_MANIFEST_REFUSAL_CODES = frozenset({
    RefusalCode.INTEGRITY_UNVERIFIABLE,
    RefusalCode.NOT_IN_REGISTRY,
    RefusalCode.UNAVAILABLE,
})


# ---------------------------------------------------------------------------
# Invocation result
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class InvocationResult:
    """Result of an invocation check. Never contains tool output.

    **Fail-closed invariant (GAP-TM-11 OPEN).** While GAP-TM-11 remains
    OPEN, no ``InvocationResult`` instance may report
    ``permitted=True``. Direct construction with ``refused=False`` is
    rejected by ``__post_init__``: the class cannot represent an
    authorized invocation in this slice.

    When a future versioned change closes GAP-TM-11, this guard must be
    removed or gated by an explicit, versioned decision — not silently
    relaxed.
    """

    refused: bool
    code: RefusalCode
    reason: str
    tool_id: str
    gap_tm11_blocked: bool = False

    def __post_init__(self) -> None:
        if not self.refused:
            raise ValueError(
                "InvocationResult cannot represent an authorized "
                "invocation while GAP-TM-11 is OPEN. All results in "
                "this slice are refusals."
            )

    @property
    def permitted(self) -> bool:
        """Always ``False`` in this slice. ``__post_init__`` guarantees
        ``refused=True``; this property returns the derived truth."""
        return False

    def __bool__(self) -> bool:
        return self.permitted

    def __repr__(self) -> str:
        return (
            f"<InvocationResult Refused [{self.code.value}] "
            f"tool={self.tool_id!r}>"
        )


# ---------------------------------------------------------------------------
# Boundary
# ---------------------------------------------------------------------------

class InvokerBoundary:
    """The invocation boundary.

    Receives a tool identifier and (optionally) a request. Returns an
    ``InvocationResult``. Never forwards to the execution backend while
    ``GAP-TM-11`` is OPEN.

    **Validation scope.** No governing contract defines a generic
    invocation-request envelope. This boundary therefore validates only
    the ``tool_id`` argument (it must be a non-empty string). It does
    **not** validate request contents; per-tool request shapes are the
    responsibility of future runtime contracts, not of this slice.
    """

    def __init__(self, backend, registry):
        self._backend = backend
        self._registry = registry

    # -- public API -------------------------------------------------------

    def check_invocation(self, tool_id, request=None) -> InvocationResult:
        """Check whether the invocation is permitted.

        Always refuses while ``GAP-TM-11`` is OPEN. Never raises; always
        returns an ``InvocationResult``.
        """

        # 1. Validate tool_id. Request contents are not validated
        #    (no generic envelope is specified by any governing source).
        if not isinstance(tool_id, str) or not tool_id.strip():
            return InvocationResult(
                refused=True,
                code=RefusalCode.MALFORMED_INPUT,
                reason="tool_id must be a non-empty string",
                tool_id=repr(tool_id),
                gap_tm11_blocked=False,
            )

        # 2. Registry lookup. Any failure → REGISTRY_ERROR, no details
        #    about the path or the underlying exception leak to the caller.
        try:
            tool_record = self._registry.get_tool(tool_id)
        except Exception:
            return InvocationResult(
                refused=True,
                code=RefusalCode.REGISTRY_ERROR,
                reason=(
                    "registry lookup failed; invocation refused "
                    "(fail closed)"
                ),
                tool_id=tool_id,
                gap_tm11_blocked=False,
            )

        # 3. Unknown tool.
        if tool_record is None:
            return InvocationResult(
                refused=True,
                code=RefusalCode.NOT_IN_REGISTRY,
                reason=f"tool {tool_id!r} is not present in the registry",
                tool_id=tool_id,
                gap_tm11_blocked=False,
            )

        # 4. Availability check. Only "present" permits progress; the
        #    loader has already validated that the value is one of
        #    {"present", "absent", "unknown"}, so anything other than
        #    "present" here is a legitimate B' refusal.
        if tool_record.get("availability") != "present":
            return InvocationResult(
                refused=True,
                code=RefusalCode.UNAVAILABLE,
                reason=f"tool {tool_id!r} is not currently available",
                tool_id=tool_id,
                gap_tm11_blocked=False,
            )

        # 5. GAP-TM-11 is OPEN. Refuse with the manifest's L code.
        #    The execution backend is not called.
        return InvocationResult(
            refused=True,
            code=RefusalCode.INTEGRITY_UNVERIFIABLE,
            reason=(
                "GAP-TM-11 is OPEN. Definition integrity cannot be "
                "verified. All invocations are refused per "
                "tool-manifest.v1.5 \u00a76.6."
            ),
            tool_id=tool_id,
            gap_tm11_blocked=True,
        )


# ---------------------------------------------------------------------------
# Execution backend protocol
# ---------------------------------------------------------------------------

@runtime_checkable
class ExecutionBackend(Protocol):
    """Protocol for the tool execution backend.

    The boundary holds an instance but never calls it while GAP-TM-11 is
    OPEN. Tests inject a mock to assert zero calls.
    """

    def execute(self, tool_id: str, request) -> object:
        ...


class NoOpBackend:
    """No-operation backend. Tracks calls; should receive none."""

    def __init__(self) -> None:
        self._calls: list = []

    def execute(self, tool_id, request):
        self._calls.append((tool_id, request))

    @property
    def call_count(self) -> int:
        return len(self._calls)

    def get_calls(self) -> list:
        return list(self._calls)

    def reset(self) -> None:
        self._calls.clear()


# ---------------------------------------------------------------------------
# Registry readers
# ---------------------------------------------------------------------------

class RegistryShapeError(Exception):
    """Raised when the registry file or one of its records is malformed,
    or when duplicate canonical IDs are detected. The boundary converts
    this into a REGISTRY_ERROR refusal; the message is for internal use
    and is never propagated to the caller."""


@runtime_checkable
class RegistryReader(Protocol):
    """Read-only access to the tool registry."""

    def get_tool(self, tool_id: str):
        ...

    def list_ids(self) -> list:
        ...


_VALID_AVAILABILITY = frozenset({"present", "absent", "unknown"})


class InMemoryRegistry:
    """In-memory registry for tests. Records are indexed by their
    canonical ``id``. Duplicate IDs or malformed records raise
    ``RegistryShapeError`` at construction time."""

    def __init__(self, tool_records):
        index: dict = {}
        for record in tool_records:
            if not isinstance(record, dict):
                raise RegistryShapeError("record must be an object")
            record_id = record.get("id")
            if not isinstance(record_id, str) or not record_id.strip():
                raise RegistryShapeError("record missing valid 'id'")
            availability = record.get("availability")
            # Require a string before membership testing so unhashable
            # values (lists, dicts) fail closed with RegistryShapeError
            # rather than raising TypeError from the frozenset lookup.
            if (not isinstance(availability, str)
                    or availability not in _VALID_AVAILABILITY):
                raise RegistryShapeError(
                    "record missing valid 'availability'"
                )
            if record_id in index:
                raise RegistryShapeError(
                    f"duplicate canonical id {record_id!r}"
                )
            index[record_id] = record
        self._by_id = index

    def get_tool(self, tool_id):
        return self._by_id.get(tool_id)

    def list_ids(self):
        return list(self._by_id.keys())


class JSONRegistry:
    """File-backed registry that reads ``runtime/registry.json``.

    * Resolves tools by their **canonical** ``id`` field, not by the
      dictionary key (some keys differ from their canonical IDs).
    * Validates the top-level shape (``tools`` must be an object) and
      each record (must be an object with a non-empty string ``id``
      and an ``availability`` in {"present", "absent", "unknown"}).
    * Rejects duplicate canonical IDs.
    * Raises ``RegistryShapeError`` on any malformed input. The
      boundary converts this into a REGISTRY_ERROR refusal.

    The file is opened read-only and is never written to.
    """

    REGISTRY_PATH = os.path.abspath(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            os.pardir, "runtime", "registry.json",
        )
    )

    def __init__(self, path: str | None = None) -> None:
        self._path = path if path is not None else self.REGISTRY_PATH
        self._index: dict | None = None

    # -- internals --------------------------------------------------------

    def _load_index(self) -> dict:
        if self._index is not None:
            return self._index

        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except FileNotFoundError as exc:
            raise RegistryShapeError("registry file not found") from exc
        except OSError as exc:
            raise RegistryShapeError("registry file unreadable") from exc

        if not raw or not raw.strip():
            raise RegistryShapeError("registry file is empty")

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RegistryShapeError("registry file is not valid JSON") from exc

        if not isinstance(data, dict):
            raise RegistryShapeError("registry top-level must be an object")

        tools = data.get("tools")
        if not isinstance(tools, dict):
            raise RegistryShapeError("registry 'tools' must be an object")

        index: dict = {}
        for key, record in tools.items():
            if not isinstance(record, dict):
                raise RegistryShapeError(
                    f"record for key {key!r} must be an object"
                )
            record_id = record.get("id")
            if not isinstance(record_id, str) or not record_id.strip():
                raise RegistryShapeError(
                    f"record for key {key!r} missing valid 'id'"
                )
            availability = record.get("availability")
            # Require a string before membership testing so unhashable
            # values (lists, dicts) fail closed with RegistryShapeError
            # rather than raising TypeError from the frozenset lookup.
            if (not isinstance(availability, str)
                    or availability not in _VALID_AVAILABILITY):
                raise RegistryShapeError(
                    f"record for key {key!r} has invalid 'availability'"
                )
            if record_id in index:
                raise RegistryShapeError(
                    f"duplicate canonical id {record_id!r}"
                )
            index[record_id] = record

        self._index = index
        return index

    # -- public API -------------------------------------------------------

    def get_tool(self, tool_id: str):
        return self._load_index().get(tool_id)

    def list_ids(self) -> list:
        return list(self._load_index().keys())


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_boundary(registry: RegistryReader | None = None) -> InvokerBoundary:
    """Build an ``InvokerBoundary`` using the production ``JSONRegistry``
    by default. Pass a custom registry for tests.

    The backend is a ``NoOpBackend``; no dispatch path exists in this
    slice. All real tool invocation remains disabled.
    """
    reg = registry if registry is not None else JSONRegistry()
    backend = NoOpBackend()
    return InvokerBoundary(backend=backend, registry=reg)


__all__ = [
    "RefusalCode",
    "InvocationResult",
    "InvokerBoundary",
    "ExecutionBackend",
    "NoOpBackend",
    "RegistryReader",
    "InMemoryRegistry",
    "JSONRegistry",
    "RegistryShapeError",
    "build_boundary",
]
