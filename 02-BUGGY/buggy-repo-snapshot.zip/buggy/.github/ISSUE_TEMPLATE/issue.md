---
name: Issue
about: Bug, feature, or question
title: ""
labels: ""
assignees: ""
---

## Area

- [ ] Documentation
- [ ] Architecture contract
- [ ] Runtime
- [ ] .opencode/ (skills / commands / agents)
- [ ] Templates / testing
- [ ] learning_engine / retrieval
- [ ] automation / scripts

## Type

- [ ] Bug / incorrect behavior
- [ ] Feature request
- [ ] Question / clarification
- [ ] Other

## Description

_What is the issue or request? Include reproducer steps for bugs._

## Context

_Personal security research project. Note at the current stage the repository is an empty
scaffold — contracts and file names are established but files contain no content yet._
