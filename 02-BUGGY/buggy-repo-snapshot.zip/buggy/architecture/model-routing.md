# model-routing.md

> **Status:** draft
> **Version:** v0.1
> **Scope:** Defines the architecture-level philosophy, terminology, and constraints for how Buggy reasons about model selection and routing. Establishes the boundary between this architecture contract and the operational routing data owned by `runtime/model-routing.md`. Does not contain operational model IDs, provider mappings, fallback tables, or routing algorithms.
> **Authority:** Architecture contract.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-architecture-rules.md`, `architecture/validation-model.md`.
> **Depended on by:** `runtime/model-routing.md` (operational routing; separate source of truth), `.opencode/agents/<name>.md` via the `model-routing-ref` frontmatter field.
> **Related OPEN GAPs:** `GAP-VM-09` (Validator model identity). This contract does not close it.
> **Consulted but not a dependency:** `runtime/tool-manifest.md` v1.5 (names `runtime/model-routing.md` as the operational site), `architecture/review-discipline.md` v0.2 (process governance), Final Canonical Blueprint v3 (structural reference).

> **Lock decision (2026-10-13):** LOCKED by explicit project-owner direction, following the independent review disposition `PASS — READY TO LOCK` on 2026-10-13. This is a **document/policy lock** only. It does not claim runtime enforcement, does not close any GAP, does not authorize any repository write, and does not change the state of any other artifact. The lifecycle `Status` field above (`draft`) and this LOCKED decision are separate; the lock does not overwrite the lifecycle vocabulary of `architecture/file-contracts.md` §8.

---

## 1. Purpose

This contract defines the **architecture-level discipline** for model routing in Buggy: its terminology, source-established constraints, and the boundary between architecture policy and operational routing data. Any derived safeguard is explicitly classified so that an inference is not silently treated as a binding rule.

This contract:

- establishes the vocabulary and boundary between architecture-level policy and runtime-level routing data;
- states source-established constraints and identifies derived safeguards whose owner approval is still pending;
- identifies the interfaces by which downstream artifacts reference routing rules.

This contract does **not**:

- choose any model, provider, or vendor;
- define any operational routing algorithm, priority hierarchy, capability score, latency threshold, cost threshold, token budget, or failover rule;
- assign a Validator model or model class;
- alter any existing contract;
- close or reclassify any GAP.

---

## 2. Terminology and Responsibility Boundaries

The following distinctions are preserved from the governing contracts and cited individually below. No term below may be collapsed with another: Model/Agent (`agent-architecture-rules.md` §2), Skill (`agent-architecture-rules.md` §4), and Command (`agent-architecture-rules.md` §5).

- **Model** — a model is not an agent. The same model may power multiple roles. Changing the model that serves an agent must not implicitly change the agent's conceptual role (`agent-architecture-rules.md` §2).

- **Agent** — an execution role composed of a defined responsibility, relevant context, allowed tools, skills, state access, model routing, output contract, and isolation boundaries. An agent *uses* a model; it is not a model (`agent-architecture-rules.md` §2).

- **Skill** — methodology. A skill defines how a category of work is reasoned about and tested. A skill is not a model, not an agent, and not a command (`agent-architecture-rules.md` §4).

- **Command** — a workflow entry point. A command orchestrates capabilities; it is not a model, not an agent, and not a skill (`agent-architecture-rules.md` §5).

- **Model routing** — the act of selecting which model serves an agent role for a given task, under the constraints stated in this contract and the operational data recorded in `runtime/model-routing.md`.

- **Architecture-level routing policy** — the philosophy, terminology, and constraints defined in this file.

- **Operational routing data** — the concrete model identifiers, provider mappings, and fallback tables owned by `runtime/model-routing.md`.

---

## 3. Architecture-Level Routing Philosophy

### Classification rule for routing principles

Each principle or safeguard is classified according to its source and approval state:

- **`SOURCE-ESTABLISHED`** — stated directly by a governing source. It is binding within that source's scope; this contract may explain it but must not broaden it without identifying the broader claim separately.
- **`DERIVED-BINDING`** — an inference from governing sources that has received **explicit project-owner approval for that specific derived rule**. It is binding only within the approved scope. The label alone is not evidence of approval; the approval must be recorded.
- **`DERIVED-PROPOSED`** — an inference or operationalization that is not stated verbatim by a governing source and has not received explicit owner approval as a binding rule. It is **non-binding** and must not be enforced or represented as an established invariant.
- **`PROPOSED`** — a design choice that is neither directly established nor necessarily entailed by the cited sources. The formal numbered owner decisions of this kind are recorded in §9 and require an explicit owner decision.

A self-check, source-report label, or appearance in this draft does not itself approve a derived rule. Unless a separate explicit owner approval for a particular derived rule is recorded, classify it as `DERIVED-PROPOSED`, not `DERIVED-BINDING`. The classification framework in this section is included under the project owner's explicit authorization for this bounded correction; that authorization does **not** approve any individual derived safeguard as binding.

### 3.1 Preserved principles

- **Routing must not collapse the Model/Agent distinction.** A change of model must not change an agent's conceptual role (`agent-architecture-rules.md` §2).

- **Proposed safeguard — preserve Skill and Command identity across routing (`DERIVED-PROPOSED`; non-binding).** It is proposed that routing decisions preserve Skill methodology and Command workflow identity. `agent-architecture-rules.md` §4 defines Skill as methodology and §5 defines Command as a workflow entry point, but those sections do not directly establish a routing-specific prohibition. This safeguard is an inference from those boundaries and `file-contracts.md` §2's ownership and single-source-of-truth principles. It remains non-binding unless the project owner explicitly approves this specific derived rule as `DERIVED-BINDING`. The source-established Agent conceptual-role rule remains separate.

- **Routing is a policy decision, not a runtime capability claim.** This contract describes what routing must respect; it does not assert that any routing is implemented, enforced, or verified at runtime (`review-discipline.md` §5).

- **Routing philosophy is architecture; routing data is runtime.** Philosophy, terminology, and constraints live here. Model IDs, provider mappings, and fallback tables live in `runtime/model-routing.md`. Neither file duplicates the other (`file-contracts.md` §4.2, §10).

- **One source of truth per concern.** This file is the sole architecture-level source for routing philosophy and constraints. `runtime/model-routing.md` is the sole operational source for routing data. No other file duplicates either (`file-contracts.md` §2 principles 2 and 7).

- **Validator independence requirement (`SOURCE-ESTABLISHED`).** Validation must be operationally independent from the hypothesis-producing path where practical (`validation-model.md` §8.3). `GAP-VM-09` remains OPEN for Validator model identity. Whether and how routing should implement a particular safeguard is addressed separately in §4.3 as `DERIVED-PROPOSED`; the routing-specific inference is not part of the source-established requirement.

### 3.2 What this section does NOT state

This contract does not:

- define a routing order, priority list, or task-to-model mapping;
- define which model class serves which role;
- define any numeric threshold, budget, score, or weight;
- define failover ordering, retry policy, or degradation strategy;
- define the number or names of "model tiers" — no such classification is established by any supplied source.

The formal numbered design decisions tracked by this contract are `PROPOSED DECISION MR-01` through `MR-04` in §9. They are distinct from `DERIVED-PROPOSED` safeguards identified in the body: those safeguards are unapproved, non-binding inferences, not additional numbered MR decisions or registered project GAPs. Other excluded mechanisms — for example, routing algorithms, priority hierarchies, capability scores, latency thresholds, cost thresholds, token budgets, retry policies, degradation strategies, and tier vocabularies — remain out of scope. Their exclusion here does not imply that they are recorded as formal numbered proposals; they are simply outside this contract's subject matter.

---

## 4. Constraints and Invariants

### 4.1 Boundary constraint (source-established)

Operational routing data (model IDs, provider mappings, fallback tables) MUST NOT appear in this file (`file-contracts.md` §4.2, §10). This file MUST NOT duplicate any route table that lives in `runtime/model-routing.md`.

### 4.2 Identity constraints

**Agent scope (`SOURCE-ESTABLISHED`):** Changing the model must not implicitly change the agent's conceptual role (`agent-architecture-rules.md` §2). This remains a source-established rule.

**Skill and Command safeguard (`DERIVED-PROPOSED`; non-binding):** It is proposed that routing not alter Skill identity or Command identity. `agent-architecture-rules.md` §4 and §5 define the respective boundaries, and `file-contracts.md` §2 establishes ownership and single-source-of-truth principles; these sources do not state the routing-specific extension verbatim. This safeguard remains non-binding unless the project owner explicitly approves this specific derived rule as `DERIVED-BINDING`. Merely identifying the inference here does not constitute approval.

### 4.3 Routing safeguard for Validator independence (`DERIVED-PROPOSED`; non-binding)

**Proposed safeguard:** A future routing design should not prevent the source-established Validator independence requirement from being satisfiable.

The underlying requirement — validation must be operationally independent from the hypothesis-producing path where practical — is `SOURCE-ESTABLISHED` by `validation-model.md` §8.3. The additional rule that routing itself must preserve that condition is an inference, not a verbatim source rule. It remains `DERIVED-PROPOSED` and non-binding until the project owner explicitly approves this specific derived safeguard as `DERIVED-BINDING`.

This section does not prescribe how routing implements any safeguard and does not assign any Validator model, class, or family. The identity of the Validator model remains OPEN under `GAP-VM-09`.

### 4.4 Single-source constraint (source-established)

Each routing concern has exactly one owning file (`file-contracts.md` §2 principle 2). Philosophy and constraints → this file. Operational routing data → `runtime/model-routing.md`. Cross-references between the two use paths or named contracts, never duplication (`file-contracts.md` §5).

### 4.5 Lifecycle constraint (source-established)

This artifact's lifecycle status is a value from the vocabulary of `architecture/file-contracts.md` §8. `LOCKED` is not a lifecycle status value; it is a separate owner decision recorded elsewhere (`review-discipline.md` §3.4, §5 item 4).

### 4.6 No-invention and approval constraint

**Source-established process rule:** A Builder must not invent unsupported architectural decisions; unsupported items must be marked `PROPOSED — OWNER DECISION REQUIRED` (`review-discipline.md` §§2.1, 3.7).

**Classification rule for this contract:** A routing principle stated directly in a governing source may be classified `SOURCE-ESTABLISHED`, within that source's scope. A routing safeguard inferred from sources but not directly stated is `DERIVED-PROPOSED` and non-binding unless the project owner explicitly approves that specific safeguard as `DERIVED-BINDING`. A design choice not established or necessarily entailed by the sources is classified `PROPOSED` and requires an explicit owner decision. A classification label, self-check, or inclusion in this draft is not owner approval. Formal numbered decisions `MR-01` through `MR-04` remain as recorded in §9; this section does not create new numbered decisions or registered GAPs.

### 4.7 Validator-model constraint (source-established)

This contract does not assign any model, model class, or model family to the Validator role. The identity of the Validator model remains OPEN under `GAP-VM-09` (`validation-model.md` §14, GAP-VM-09). No routing rule stated here may resolve that GAP.

---

## 5. Interface with Downstream Consumers

### 5.1 `runtime/model-routing.md`

This file is the architecture-level source; `runtime/model-routing.md` is the operational source. Downstream consumers cite both paths when they need philosophy and data respectively:

- architecture-level philosophy and constraints → this file;
- operational model identifiers, provider mappings, and fallback data → `runtime/model-routing.md`.

**Source-established no-duplication rule:** Neither file may duplicate content owned by the other, per `file-contracts.md` §§2 and 5.

**Proposed specific operationalization (`DERIVED-PROPOSED`; non-binding):** A future author of `runtime/model-routing.md` should reference this file for architecture-level routing philosophy rather than restating it. The architecture/runtime split is source-established (`file-contracts.md` §§4.2, 10); this more specific reference obligation is an inference and remains non-binding unless the project owner explicitly approves it as `DERIVED-BINDING`.

### 5.2 Agents via `model-routing-ref`

`architecture/agent-architecture-rules.md` §10.3 defines a `model-routing-ref` frontmatter field for agent artifacts. That field, where present, references both:

- `architecture/model-routing.md` (this file), and
- `runtime/model-routing.md`.

This contract does not introduce new frontmatter fields, alter existing ones, or reinterpret the `model-routing-ref` semantics. The field is owned by `agent-architecture-rules.md`.

### 5.3 Possible future consumer — non-normative note

The supplied sources establish `runtime/opencode/ORCHESTRATION.md` (when implemented) as a consumer of approval flow and agent/role rules. They do **not** explicitly establish that it consumes `architecture/model-routing.md` for routing philosophy. This contract therefore does **not** list ORCHESTRATION as a confirmed dependent.

If a future, separately authored `runtime/opencode/ORCHESTRATION.md` contract explicitly declares a dependency on this file, that declaration would be the authoritative source. Until then, the relationship is an inference, not a dependency. This note is not a normative dependency claim and does not authorize any change to that future contract.

### 5.4 References from other artifacts

**Source-established rule:** Cross-references use paths or named contracts rather than duplicated content (`file-contracts.md` §5).

**Proposed specific operationalization (`DERIVED-PROPOSED`; non-binding):** An artifact that needs a routing constraint should reference this file by path and section. The specific requirement to reference both a path and section for every routing constraint is this contract's operationalization, not a verbatim rule from `file-contracts.md` §5. It remains non-binding unless the project owner explicitly approves it as `DERIVED-BINDING`.

---

## 6. Validator Independence

Preserved from `architecture/validation-model.md` §8.3:

- Validation must be operationally independent from the hypothesis-producing path where practical.
- Independence may be achieved through several mechanisms; the specific mechanism is not fixed by that contract.

Preserved from `architecture/validation-model.md` §14 (GAP-VM-09):

- The identity of the Validator model (or model class) remains **OPEN**.
- This contract does not assign any Validator model, model class, or family.
- This contract does not state which routing configuration must serve validation.
- Any future decision about Validator model identity is outside this contract's authority and remains an owner decision.

---

## 7. Architecture / Runtime Separation

This contract and `runtime/model-routing.md` are two files with two responsibilities:

| Concern | Owner |
|---|---|
| Routing philosophy, terminology, constraints | `architecture/model-routing.md` (this file) |
| Model IDs, provider mappings, fallback tables, operational routing configuration | `runtime/model-routing.md` |
| Model ≠ Agent ≠ Skill identity | `architecture/agent-architecture-rules.md` §2 |
| Validator independence requirement | `architecture/validation-model.md` §8.3 |
| Tool gating policy | `runtime/tool-manifest.md` v1.5 |
| Tool inventory | `runtime/registry.json` v0.7-rev2 |

The architecture/runtime split in the table above and the general rule against duplicating another file's content are source-established by `file-contracts.md` §§2, 4.2, 5, and 10.

**Proposed specific operationalizations (`DERIVED-PROPOSED`; non-binding pending explicit owner approval):**

- A future author of `runtime/model-routing.md` should reference this file for routing philosophy and constraints rather than restating them.
- The runtime routing file should not introduce a second source of truth for the specific concerns listed in the table above.
- Adding operational data (IDs, mappings, fallbacks) that does not contradict approved architecture constraints should not, by itself, require a change to this architecture contract.

These are narrower rules inferred from the source-established split and no-duplication principles. None is binding merely because it appears here; each would require explicit project-owner approval of the specific derived rule before being classified `DERIVED-BINDING`.

---

## 8. Explicit Exclusions

This contract explicitly excludes:

- operational model IDs and provider identifiers;
- provider-to-model mappings;
- fallback tables or failover lists;
- runtime enforcement claims, implementation claims, or verification claims;
- any assignment of a Validator model or model class (`GAP-VM-09` remains OPEN);
- any change to `runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2, or any other locked contract;
- any change to `runtime/redaction.md` v1.0, which remains FREEZE/unapproved;
- any closure, downgrade, or reclassification of any OPEN GAP;
- any invented routing algorithm, priority hierarchy, capability score, latency threshold, cost threshold, token budget, or failover semantics.

---

## 9. Proposed Owner Decisions

The following four items are the formal numbered **PROPOSED DECISION MR-01** through **MR-04**. They are **not** registered project GAPs. Registering any of them as a formal project GAP would be a separate owner decision and a separate record.

These are the only numbered `MR-*` design decisions in this contract. The body-level `DERIVED-PROPOSED` safeguards described in §§3.1, 4.2–4.3, 5.1, 5.4, and 7 are separately identified non-binding inferences; they do not become binding rules, formal `MR-*` entries, or registered GAPs merely by appearing in the body. No other excluded design detail is recorded as a formal numbered proposal.

### PROPOSED DECISION MR-01 — Model classification vocabulary

- **Question:** does Buggy adopt a formal model classification vocabulary (e.g. tiers or capability classes) as architecture-level terminology, or is each routing decision made without a named classification?
- **Status:** proposal only. No supplied source establishes a classification vocabulary. This contract currently neither defines nor forbids one.
- **Owner decision required.**

### PROPOSED DECISION MR-02 — Routing-decision authority

- **Question:** which role decides, at runtime, which model serves an agent role for a given task — the operator through configuration, the runtime through a policy, or a hybrid?
- **Status:** proposal only. No supplied source establishes the authority model for operational routing decisions. Not decided by this contract.
- **Owner decision required.**

### PROPOSED DECISION MR-03 — Validator-capable model policy

- **Question:** in operational terms, what constitutes an acceptable Validator model given the independence requirement in `validation-model.md` §8.3? This is the operational side of `GAP-VM-09`.
- **Status:** proposal only. `GAP-VM-09` remains OPEN. This contract does not resolve it and does not assign a Validator model.
- **Owner decision required.**

### PROPOSED DECISION MR-04 — Cross-file fallback semantics

- **Question:** if a routing configuration cannot be resolved at runtime (e.g. a model is unavailable), what does the architecture say about the required behavior — refuse, degrade, or defer to the operator?
- **Status:** proposal only. No supplied source establishes failover semantics. This contract neither defines nor forbids them.
- **Owner decision required.**

---

## 10. Cross-References

- `architecture/file-contracts.md` §2, §4.1, §4.2, §5, §8, §9, §10 — file ownership, metadata requirements, architecture vs runtime split, cross-reference rules, lifecycle vocabulary, change discipline.
- `architecture/agent-architecture-rules.md` §2, §4, §5, §10.3, §14.3 — `Model ≠ Agent ≠ Skill`, Skill/Command identity definitions, `model-routing-ref` field, related cross-references.
- `architecture/validation-model.md` §8.3, §13.3, §14 — Validator independence, routing references, and `GAP-VM-09`.
- `runtime/tool-manifest.md` v1.5 §2.2 — declares `runtime/model-routing.md` as the operational routing site. Consulted as a downstream-consumer source, not declared as an upstream dependency of this file.
- `architecture/review-discipline.md` v0.2 §2, §3, §4, §5 — process-governance source; not a subject-matter dependency.
- Final Canonical Blueprint v3 — structural reference; its "Reference only" wording for this file is inconsistent with `file-contracts.md` §4.2 / §10 and is disclosed in this contract's change report (not in this file's normative text).

---

**Status of this contract itself:** `draft` / v0.1. LOCKED on 2026-10-13 by explicit owner decision (see header blockquote). Not production. Not transferred to the repository.
