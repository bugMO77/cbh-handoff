# agent-architecture-rules.md

> **Status:** production v1.2
> **Scope:** Defines what Agents, Skills, and Commands are in Buggy; their boundaries; when each is appropriate; how they relate; and how each is structured.
> **Authority:** Architecture contract. Refines `architecture/file-contracts.md` for the agent / skill / command semantics.
> **Depends on:** `architecture/file-contracts.md`
> **Depended on by:** `.opencode/skills/<name>/SKILL.md`, `.opencode/commands/<name>.md`, `.opencode/agents/<name>.md`, `/AGENTS.md`, `runtime/opencode/loader.md`, `runtime/opencode/ORCHESTRATION.md`

---

## 1. Purpose

This contract defines the architectural rules for:

- what counts as an **Agent** in Buggy
- what counts as a **Skill** in Buggy
- what counts as a **Command** in Buggy
- when each is appropriate
- how they relate to one another
- how each is structured (frontmatter conventions)

This contract does NOT define:

- the 7-question validation gate (`architecture/validation-model.md`)
- knowledge flow (`architecture/knowledge-flow.md`)
- memory and learning flow (`architecture/learning-flow.md`)
- agent security (`architecture/agent-security.md`)
- model routing (policy: `architecture/model-routing.md`; ops: `runtime/model-routing.md`)
- tool gating (`runtime/tool-manifest.md`)
- template contents (`templates/*`)
- file type ownership, lifecycle, and path semantics (`architecture/file-contracts.md`)

If a downstream contract needs a rule already established here, it must reference this file rather than duplicate it.

## 2. Core Distinction — Model ≠ Agent

> Source: Buggy Master Blueprint §6 (canonical integration, not rewrite).

A model is not an agent.

An agent is an execution role composed of:

- a defined responsibility
- relevant context
- allowed tools
- skills
- state access
- model routing
- output contract
- isolation boundaries

The same model may power multiple roles.

Changing the model must not implicitly change the conceptual role.

## 3. Agent Roles — Coordinator / Solver / Detector / Validator

> Source: Buggy Master Blueprint §8 (canonical integration, not rewrite).

Agent architecture is intentionally sparse.

### 3.1 Coordinator

Coordinator is an orchestration role.

It is not required to be a permanent agent file.

Its responsibility is to:

- understand current workflow state
- select appropriate capabilities
- delegate isolated work
- maintain task boundaries
- combine summarized results
- avoid unnecessary context accumulation

### 3.2 Solver

Solver is an isolated or ephemeral execution context used when deeper reasoning or focused work is justified.

Solver is not a permanent taxonomy requirement.

A solver receives a bounded task and returns a bounded result.

It should not dump its entire raw execution context back into the coordinator.

### 3.3 Detector

Detector is a narrow executable/runtime capability.

A detector may be:

- a script
- a runtime capability
- a target-specific execution helper
- a registered tool

Detector does not automatically become a permanent agent.

Deterministic detection should be preferred when deterministic logic can solve the problem reliably.

### 3.4 Validator

Validator is responsible for independent validation where practical.

Validation should challenge the initial hypothesis instead of merely confirming it.

## 4. Skills

> Sources: Buggy Master Blueprint §9, Rules Producer §10, Architecture Builder §16 (canonical integration, not rewrite).

### 4.1 Definition

A skill is methodology.

A skill defines how a category of work should be reasoned about and tested.

### 4.2 What a Skill May Reference

A skill may reference:

- architecture contracts
- runtime contracts
- concepts
- processed knowledge
- reusable wordlists

### 4.3 What a Skill May Define

A skill may define:

- methodology
- test sequencing
- expected observations
- evidence expectations
- tool invocations
- decision trees

If a skill needs a command, it **references or invokes an existing command**. The command artifact itself stays independent — a skill does not become the place where a command is defined.

### 4.4 What a Skill Must NOT Do

A skill must NOT:

- become a giant prompt container
- become a payload repository
- duplicate concepts unnecessarily
- replace runtime proof
- silently override architecture contracts
- embed large reusable payload dumps (those belong in `/wordlists/`, not in skills)
- embed source material (sources live in `/knowledge/`)
- hold target-specific state (that goes in `/testing/<target>/`)
- hold run output (that goes in `/testing/<target>/runs/` or `/logs/`)
- silently redefine architecture decisions

### 4.5 Skill = SKILL.md + Optional Subtree

> Source: Synthesis (combining Master Blueprint §9 with `architecture/file-contracts.md` §4.4).

A skill is implemented as:

```
.opencode/skills/<skill-name>/
├── SKILL.md           (required — the methodology + frontmatter)
├── scripts/           (optional — deterministic helpers)
└── references/        (optional — bounded supporting references)
```

The semantic split between `references/` and `knowledge/` is:

```
references/  = bounded supporting references, derived material,
               pointers to relevant contract / concept / artifact
               names. Lives next to the skill that uses it.

knowledge/   = canonical external source material
               (writeups, reports, blogs, research, docs).
               Lives under /knowledge/<source-type>/ and is the
               source of truth for source content.
```

`references/` must NOT duplicate canonical source material from `knowledge/`. If a skill needs to cite a writeup, it links to `/knowledge/writeups/...` (or via `/concepts/` / `/retrieval/`); it does not embed the source.

### 4.6 Initial Core Skills

> Source: Buggy Master Blueprint §9 + Blueprint v3 (canonical list).

The initial core skills are:

- Scope Bootstrap
- Program Research
- Recon
- JavaScript Discovery
- JavaScript Analysis
- Identities
- Session Search
- Validator
- Report Writer
- Regression
- Access Control / IDOR / BAC
- XSS

The exact implementation of each is governed by its dedicated SKILL.md contract and the templates it consumes.

### 4.7 When to Build a Skill — and When NOT To

> Source: Synthesis derived from Rules Producer §10 and Sources Research Foundation (consensus across 12 source families).

Build a Skill when ONE of:

- the model does not know the knowledge natively (your environment, your servers, your custom workflow)
- the knowledge is private / non-generic (gadgets, techniques, program-specific patterns)
- you want a specific execution method that requires proxy visibility, history, or replay (e.g. Kaito / Burp-driven testing)
- the methodology is non-obvious and benefits from a deterministic shape

Do NOT build a Skill when:

- the model is already good at the task natively
- a deterministic tool already solves it
- a single command in the runtime layer is enough
- the proposed Skill would just become a payload repository
- the skill would need to be loaded into every session regardless of relevance (skill description would be too broad)

A skill should make it possible to ask:

"Did we follow this methodology or not?"

## 5. Commands

> Sources: Buggy Master Blueprint §10, Rules Producer §10, Architecture Builder §16 (canonical integration, not rewrite).

### 5.1 Definition

Commands are workflow entry points.

### 5.2 What a Command May Do

A command may:

- orchestrate existing capabilities
- order phases of a workflow
- define completion checks
- declare required skills
- declare required inputs / outputs

### 5.3 What a Command Must NOT Do

A command must NOT:

- become another place where methodology is duplicated (delegate to skills)
- own target-state mutation as a domain responsibility. Commands may
  trigger delegated capabilities (skills, scripts, tools) that perform
  authorized state changes; the command itself stays an orchestrator.
- hold a single payload
- become a giant prompt

### 5.4 Canonical Commands

> Source: Blueprint v3 (canonical commands list).

The canonical conceptual commands are:

- `hunt` — focused hunting loop
- `recon` — recon workflow
- `monitor` — monitoring cycle
- `update` — state / briefing / memory refresh
- `validate` — candidate / finding validation
- `report` — confirmed finding → report
- `research` — Program Research Mode
- `understand` — application understanding
- `compare-runs` — run comparison + miss analysis
- `mindmap` — hosts / features / endpoints / relationships
- `scope-check` — fast in-scope / out-of-scope / third-party / unknown decision
- `triage` — fast go / no-go candidate triage
- `pickup` — resume previous work (untested → partial → unresolved)

A command's exact frontmatter is defined in §10 below.

## 6. Agents — Rare

> Source: Architecture Builder §16 (canonical integration, not rewrite).

### 6.1 When an Agent File Is Justified

An Agent file (`.opencode/agents/<name>.md`) is justified only when:

- a genuinely distinct execution responsibility exists
- isolation from the main context is required
- a coordination boundary must be explicitly named

### 6.2 When an Agent File Is NOT Justified

An Agent file is NOT justified when:

- a skill can solve the problem (prefer the skill)
- a command can solve the problem (prefer the command)
- deterministic tooling can solve the problem (prefer tooling)
- the work fits in a Solver role (use an isolated ephemeral execution, not a permanent agent)

### 6.3 Required Justification

Every agent file must include an explicit "few agents" justification.

If the justification is "it's a vulnerability class", that is not sufficient.

## 7. Few Agents, Many Skills

> Sources: Buggy Master Blueprint §7, Architecture Builder §17 (canonical integration, not rewrite).

Buggy must not become an agent-per-vulnerability system.

Do NOT create:

- one agent for IDOR
- one agent for XSS
- one agent for SQLi
- one agent for SSRF
- one agent for every skill
- one agent for every command

Skills define methodology.

Agents define isolated responsibilities.

Commands define workflow entry points.

## 8. Function-Centric Testing

> Source: Buggy Master Blueprint §12 (canonical integration, not rewrite).

Buggy is function-centric rather than blindly endpoint-centric.

Endpoints are implementation surfaces.

Functions represent security-relevant behavior.

A function may involve:

- multiple endpoints
- browser state
- identities
- permissions
- asynchronous operations
- background jobs
- invitations
- state transitions
- financial actions
- configuration
- object ownership

The system should reason about the function and its security boundary, not merely enumerate URLs.

## 9. AGENTS.md as Steering Layer (Not Encyclopedia)

> Source: Synthesis (Buggy Master Blueprint §3 / §35 cross-cutting + Rules Producer feedback loop).

`/AGENTS.md` is a steering document.

It contains:

- identity / role for the agent operating the workspace
- short, stable operational guidance
- pointers to relevant contracts
- current stopping rules
- cross-cutting safety reminders

It must NOT contain:

- the full architecture (lives in `/architecture/*.md`)
- the full knowledge base (lives in `/knowledge/`)
- the full skill library (lives in `/.opencode/skills/`)
- giant method enumerations
- prompt-engineering tutorials

`AGENTS.md` should stay small enough to read at the start of any session without context bloat.

If a rule belongs in `/architecture/`, it does not belong in `AGENTS.md`. Reference the architecture file by name instead.

## 10. Frontmatter Conventions

> Source: Synthesis (per `architecture/file-contracts.md` §4.1 / §4.4 / §4.5 / §4.6 + Architecture Builder §33).

The hierarchy is strict and must not be reversed:

1. `architecture/file-contracts.md` defines the **minimum metadata contract** (the baseline) for each file type. Its required fields are mandatory here.
2. This file (`agent-architecture-rules.md`) may **add** additional type-specific required fields beyond the baseline.
3. This file may **NOT downgrade** a field that is required upstream in `file-contracts.md` to optional.
4. When a dependency is empty (e.g. a skill has no other skills to depend on), represent it as an **empty list** (`depends-on-skills: []`) rather than omitting the field. Keeping the schema stable helps the runtime loader.
5. Anything not listed as required by either file is optional and may be declared when relevant.

Frontmatter must be plain YAML; no code execution, no exotic types.

### 10.1 Skill Frontmatter

For `/.opencode/skills/<skill-name>/SKILL.md`:

**Required metadata (baseline from `file-contracts.md` §4.4 + this contract):**

```yaml
name: <skill-name>                  # required; matches folder name
status: <draft|review|production|deprecated>   # required
depends-on-skills:                  # required; may be [] if no skill deps
  - <other-skill>
depends-on-templates:               # required; may be [] if no template deps
  - templates/<name>.md
version: <semver-or-integer>        # required; aligns with file-contracts.md
description: <one-line trigger>     # required by this contract; the trigger
                                   # that activates this skill
```

**Optional metadata (declare only when relevant):**

```yaml
depends-on-contracts:               # optional; list of architecture/runtime contracts
  - architecture/<name>.md
target-types: <web|api|browser|...>  # optional; what targets the skill applies to
vuln-classes: <idor|xss|ssrf|...>   # optional; only when the skill is vulnerability-specific
```

Notes:

- `description` is the **trigger**. It must be specific enough to fire only when the skill applies, and general enough not to fail under varied phrasing.
- `depends-on-*` lists (skills, templates) are always present even when empty. This keeps the schema stable for the runtime loader.
- Anything not listed under "Required" or "Optional" above is not part of the skill frontmatter contract; do not invent additional fields without revising this contract.

### 10.2 Command Frontmatter

For `/.opencode/commands/<command-name>.md`:

**Required metadata (baseline from `file-contracts.md` §4.5 + this contract):**

```yaml
name: <command-name>                # required; matches filename without .md
status: <draft|review|production|deprecated>   # required (added by this contract)
version: <semver-or-integer>        # required (added by this contract)
description: <what>                 # required (added by this contract); one-line purpose
trigger: <when>                     # required; user-facing trigger phrase
inputs:                             # required; may be [] if no inputs
  - <input-description>
outputs:                            # required; may be [] if no outputs
  - <output-description>
depends-on-skills:                  # required; skills the command orchestrates
                                   # may be [] if the command orchestrates none
  - <skill-name>
```

**Optional metadata:**

```yaml
depends-on-contracts:               # optional
  - <contract-path>
```

Notes:

- `depends-on-skills` is required so that any command invocation can be statically checked for missing skill dependencies.
- `trigger` must be unambiguous in case multiple commands could match.
- `inputs` and `outputs` are required and may be empty lists when the command has none.
- Anything not listed above is not part of the command frontmatter contract.

### 10.3 Agent Frontmatter (Rare)

For `/.opencode/agents/<agent-name>.md`:

```yaml
name: <agent-name>                  # required; matches filename without .md
status: <draft|review|production|deprecated>   # required
version: <semver-or-integer>        # required
role: <one-line role description>   # required
isolated-context: <yes|no>          # required
few-agents-justification: <reason>  # required; explicit "few agents" justification
owns-skills:                        # required; skills this agent orchestrates
  - <skill-name>
model-routing-ref:                  # required
  - architecture/model-routing.md
  - runtime/model-routing.md
```

Notes:

- `few-agents-justification` is mandatory. "It's a vulnerability class" is not a sufficient justification.
- `isolated-context: yes` is required when the agent operates in a context the main agent cannot see directly.

## 11. Subagent Output Contract

> Source: Buggy Master Blueprint §38 (canonical integration, not rewrite).

Subagents should return summarized results.

They should not return uncontrolled raw context dumps by default.

A result should preserve:

- finding / hypothesis
- relevant evidence
- reasoning summary
- confidence
- blockers
- next required action

The exact schema is defined by the calling contract (skill, command, or agent).

## 12. Initial Vulnerability Focus

> Source: Buggy Master Blueprint §40 (canonical integration, not rewrite).

The initial methodology focus is:

- **Access Control / IDOR / BAC**
- **XSS**

The system architecture must remain capable of expanding to additional vulnerability classes without creating an agent-per-vulnerability model.

When additional vulnerability classes are added:

- they are added as **new skills**, not new agents
- their methodology is captured in `concepts/<vuln-class>/` using the schema defined in `templates/prompts/vulnerability-skill-template.md` (when that template is authored)
- their cross-cutting rules (validation, evidence, FP handling) continue to flow through the architecture contracts, not through per-vuln-class agent files

## 13. Hard Red Lines

> Source: Buggy Master Blueprint §47 (canonical integration, not rewrite).

Buggy must NOT:

- treat LLM output as proof
- create one agent per vulnerability
- create one agent per skill
- become an agent swarm
- load all skills/knowledge at startup
- rely on giant system prompts as permanent state
- default to blind payload blasting
- default to autonomous forever-hunting
- invent undefined architectures such as arbitrary graphs / scoring engines without explicit contracts
- silently modify scope
- mix target state across targets
- duplicate sources of truth
- destroy historical evidence
- allow target-controlled content to silently redefine trusted instructions

## 14. Cross-References

### 14.1 Files That Read This Contract

- `architecture/file-contracts.md` (this contract refines §4.4 / §4.5 / §4.6 of that file)
- `/AGENTS.md` (steering layer that points to this contract)
- `.opencode/skills/<name>/SKILL.md` (each skill follows the Skill frontmatter convention)
- `.opencode/commands/<name>.md` (each command follows the Command frontmatter convention)
- `.opencode/agents/<name>.md` (each agent follows the Agent frontmatter convention, when any agent files exist)
- `runtime/opencode/loader.md` (uses skill/command/agent conventions to load artifacts)
- `runtime/opencode/ORCHESTRATION.md` (uses agent + role rules for orchestration)

### 14.2 Files This Contract Reads

- `architecture/file-contracts.md` (file ownership, lifecycle, paths, per-type contracts)

### 14.3 Files This Contract Does NOT Cover (Linked Out)

- `architecture/validation-model.md` — 7-question gate, FP gate, Evidence standard, Exploit Gate, Validator model
- `architecture/agent-security.md` — threat model for agents (prompt injection, tool poisoning, MCP trust, etc.)
- `architecture/knowledge-flow.md` — sources → processed → concepts → retrieval → skills
- `architecture/learning-flow.md` — findings / FP / misses → lesson → memory → improvement
- `architecture/model-routing.md` — model selection philosophy
- `runtime/model-routing.md` — operational model IDs, mappings, fallbacks
- `runtime/tool-manifest.md` — tool definitions + gating rules
- `templates/prompts/vulnerability-skill-template.md` — schema for vulnerability skill content (does not yet exist; to be created at templates phase)

## 15. ⚠️ GAP NOTES

The following items are **OPEN TODOs** in the current architecture. They are intentionally not resolved here because the v6 source material did not provide enough specification to invent a contract without inventing architecture. Each gap is recorded with what is missing and where it should land when the missing specification becomes available.

### GAP-01: Micro-agent execution contract (NARROW INPUT / SPECIFIC TASK / LIMITED TOOLS / LIMITED RESPONSE / STRUCTURED OUTPUT)

- **What's missing:** the exact narrow-I/O contract, isolation rules, context payload, and output schema for a micro-agent invocation.
- **Why it's a gap:** sources discussed micro-agents at the conceptual level only. No source provided a concrete contract.
- **Where it should land:** a future revision of this file, or a dedicated sub-section in `runtime/opencode/ORCHESTRATION.md`, once the runtime-level micro-agent pattern is specified.
- **Status:** OPEN TODO — do not invent a contract here.

### GAP-02: Program Knowledge Pack schema

- **What's missing:** the fields, lifecycle, retrieval indexing, and provenance structure for the per-program knowledge pack that supports Research Mode.
- **Why it's a gap:** sources support the existence of a Program Knowledge Pack as part of Research Mode, but do not specify its schema.
- **Where it should land:** either in `architecture/knowledge-flow.md` or in a new `architecture/research-mode.md`. Sketch only when source-supported.
- **Status:** OPEN TODO — do not invent a schema here.

### GAP-03: False Positive DB structure

- **What's missing:** the schema, query patterns, retention policy, and provenance for the FP database.
- **Why it's a gap:** sources support the architectural need for an FP knowledge database, but the schema is not specified.
- **Where it should land:** `architecture/learning-flow.md` (FP DB is part of the memory / lessons flow).
- **Status:** OPEN TODO — do not invent a schema here.

### GAP-04: Proof Gate implementation details

- **What's missing:** how the Proof Gate is actually implemented (what runtime capability decides "confirmed", how the gate is wired to a target without flow control, what its boundary types are).
- **Why it's a gap:** the principle "AI ≠ proof, runtime = proof" is established; the implementation mechanism is not.
- **Where it should land:** `architecture/validation-model.md` (gate itself) plus `runtime/opencode/` for the runtime wiring.
- **Status:** OPEN TODO — do not invent an implementation here.

### GAP-05: Exact 10 FP questions

- **What's missing:** the literal list of 10 False Positive Gate questions.
- **Why it's a gap:** sources mentioned "10 FP questions" but did not provide the literal list.
- **Where it should land:** `architecture/validation-model.md` (within the FP Gate section) once the questions are finalized by the hunter.
- **Status:** OPEN TODO — do not invent the 10 questions here.

### GAP-06: Exact 10 Evidence requirements

- **What's missing:** the literal list of 10 Evidence Standard requirements.
- **Why it's a gap:** sources mentioned "10 evidence requirements" but did not provide the literal list.
- **Where it should land:** `architecture/validation-model.md` (within the Evidence section) once the requirements are finalized.
- **Status:** OPEN TODO — do not invent the 10 requirements here.

### GAP-07: Coverage Engine details (surface × function × identity × trust boundary × vulnerability class × tested/untested)

- **What's missing:** the schema for representing coverage at this dimensionality, the update procedure when a finding is confirmed, and the relationship between coverage state and target prioritization.
- **Why it's a gap:** the principle is established; the schema is not.
- **Where it should land:** `architecture/validation-model.md` (Coverage Map section) plus the corresponding `templates/coverage-map.md` schema.
- **Status:** OPEN TODO — do not invent a schema here.

### GAP-08: Local Redaction → Cloud → Local Restoration workflow

- **What's missing:** the exact redaction protocol, the boundary types that are redacted, the restoration mapping, and the lifecycle of redacted representations.
- **Why it's a gap:** the principle is established (privacy by redaction); the protocol is not.
- **Where it should land:** `runtime/redaction.md` (operational) and `architecture/agent-security.md` (threat model).
- **Status:** OPEN TODO — do not invent a protocol here.

### GAP-09: Model Routing — Routing philosophy vs. Operational mapping

- **What's missing:** the precise model-selection philosophy at the architecture level and the operational model IDs and fallbacks at the runtime level.
- **Why it's a gap:** the principle is established; specifics are intentionally deferred to dedicated contracts.
- **Where it should land:** `architecture/model-routing.md` (philosophy + constraints) and `runtime/model-routing.md` (model IDs + mappings + fallbacks).
- **Status:** OPEN TODO — do not invent mappings here.

### GAP-10: Cross-cutting (MCP, Observability, Privacy boundaries beyond GAP-08)

- **What's missing:** the operational contracts for MCP trust boundaries, observability policies (what is logged vs. what is sensitive), and any additional privacy boundaries not covered by GAP-08.
- **Why it's a gap:** the principles are established; the operational contracts are not.
- **Where it should land:** `architecture/agent-security.md`, `runtime/registry.json`, and dedicated `runtime/` contracts.
- **Status:** OPEN TODO — do not invent contracts here.

### GAP-11: Frontmatter schema stability

- **What's missing:** whether the frontmatter formats in §10 should evolve (e.g. add a `model-routing-ref` to skills, add `output-contract-ref` to commands).
- **Why it's a gap:** the current formats are intentionally minimal; expansion is expected as downstream skills/commands reveal what metadata they actually need.
- **Where it should land:** a future revision of this file, informed by actual skill / command production usage.
- **Status:** OPEN TODO — expand only when production usage demands it.

---

These gaps are recorded so that future work does not silently invent contracts where the architecture has not yet been specified. Each gap names what is missing, why it is missing, where the contract belongs, and the rule that the answer must follow.
