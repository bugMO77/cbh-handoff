# knowledge-flow.md

> **Status:** production v1.1
> **Scope:** Defines how knowledge moves through Buggy — from external source material to processed extraction, to synthesized concepts, to retrieval, to skills. Establishes the five layers, their contracts, their provenance rules, and the separation between knowledge and memory.
> **Authority:** Architecture contract. Refines `architecture/file-contracts.md` §4.7–§4.9 for the knowledge flow semantics.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-architecture-rules.md`, `architecture/validation-model.md`
> **Depended on by:** `/concepts/**`, `knowledge/processed/**`, `retrieval/**`, `.opencode/skills/<name>/SKILL.md` (skills), `templates/prompts/vulnerability-skill-template.md` (when authored), `/AGENTS.md`, `architecture/learning-flow.md`

---

## 1. Purpose

This contract defines:

- the five layers through which knowledge moves in Buggy
- what each layer owns, who writes it, who reads it
- the provenance and traceability rules that keep knowledge honest
- the relationship between knowledge (external / external-derived) and memory (lessons from real hunts)
- what skills may and may not do with knowledge

This contract does NOT define:

- the per-type file contracts for `/knowledge/<source-type>/` and `/concepts/<area>/` (those are in `file-contracts.md` §4.7 / §4.8 / §4.9)
- how a single skill is structured (lives in `agent-architecture-rules.md` §4 + `templates/prompts/vulnerability-skill-template.md`)
- how memory is updated from real hunts (lives in `architecture/learning-flow.md`)
- the retrieval implementation (lives in `retrieval/` per the deferred implementation)
- the validation gate that runs on a finding (lives in `architecture/validation-model.md`)

If a downstream file needs a rule established here, it references this contract rather than duplicating it.

## 2. The Five Layers

> Source: Buggy Master Blueprint §22 / §44 + Rules Producer §11 (canonical integration, not rewrite).

Knowledge moves through five distinct layers:

```
┌─────────────────────────────────────────────────────────────┐
│  LAYER 1 — SOURCE MATERIAL                                  │
│  /knowledge/<source-type>/<item>.md                         │
│  Owner: knowledge curator. Lifecycle: immutable.            │
│  Provenance: required.                                       │
└─────────────────────┬───────────────────────────────────────┘
                      │ human or AI extraction
                      │ (preserves provenance link)
                      ▼
┌─────────────────────────────────────────────────────────────┐
│  LAYER 2 — PROCESSED EXTRACTION                              │
│  /knowledge/processed/<item>.md                             │
│  Owner: knowledge curator. Lifecycle: append; supersedes.   │
│  Structured; never a full copy of source.                    │
└─────────────────────┬───────────────────────────────────────┘
                      │ multiple processed items synthesized
                      │ (must reference multiple source-derived items)
                      ▼
┌─────────────────────────────────────────────────────────────┐
│  LAYER 3 — CONCEPTS                                          │
│  /concepts/<area>/<file>.md                                 │
│  Owner: concept author. Lifecycle: append-or-revise.         │
│  Synthesized reusable knowledge.                             │
└─────────────────────┬───────────────────────────────────────┘
                      │ indexed / searchable
                      ▼
┌─────────────────────────────────────────────────────────────┐
│  LAYER 4 — RETRIEVAL                                         │
│  /retrieval/{search,metadata,index}/                        │
│  Owner: retrieval owner. Lifecycle: deferred (build order   │
│  phase 10).                                                  │
│  Surfaces relevant knowledge without loading everything.     │
└─────────────────────┬───────────────────────────────────────┘
                      │ referenced by skill (not embedded)
                      ▼
┌─────────────────────────────────────────────────────────────┐
│  LAYER 5 — SKILL CONSUMPTION                                 │
│  /.opencode/skills/<name>/SKILL.md + references/            │
│  Owner: skill author. Lifecycle: versioned.                  │
│  Skill references concepts/retrieval; never embeds source.   │
└─────────────────────────────────────────────────────────────┘
```

> Source: Buggy Master Blueprint §22 (canonical integration, not rewrite).

**Critical rule:** each layer may only be written by its designated owner. A skill may NOT write a concept. A concept may NOT rewrite a source. A processed extraction may NOT be its own source. See §3–§7 for the per-layer contracts.

## 3. Layer 1 — Source Material

> Sources: Buggy Master Blueprint §22 + `architecture/file-contracts.md` §4.7 (canonical integration, not rewrite).

### 3.1 Canonical Subdirectories

The `/knowledge/` tree contains the canonical source-material subdirectories below, plus `/knowledge/processed/` for Layer 2. **No other subdirectory may be added inside `/knowledge/`** without an explicit architectural decision.

```
knowledge/
├── writeups/        # LAYER 1 — disclosed bug bounty writeups
├── reports/         # LAYER 1 — formal security reports (vendor disclosures, advisories)
├── blogs/           # LAYER 1 — blog posts from security researchers
├── tips-tricks/     # LAYER 1 — short practical techniques
├── research/        # LAYER 1 — longer-form security research
├── docs/            # LAYER 1 — official documentation that informs methodology
│
└── processed/       # LAYER 2 — covered in §4
```

> **Excluded by architecture decision:** `posts/`, `podcasts/`, `videos/` are **not** part of Buggy's knowledge taxonomy. If a source is video-only, the user must transcribe it into a written artifact under one of the canonical subdirectories before it enters the knowledge flow.

### 3.2 Source Material Contract

> Source: `architecture/file-contracts.md` §4.7 (referenced, not duplicated).

A source-material file MUST:

- declare provenance (URL or other source reference, retrieval date, type, tags)
- preserve the source's content as-is (no "improvements" or commentary)
- be immutable once committed (corrections = new file with `supersedes` link)

A source-material file MUST NOT:

- contain personal commentary on the source (that belongs in `/knowledge/processed/`)
- be edited to "fix typos" or "modernize language" (preserve the source exactly)
- have its content pasted into a skill (skills link to source, not embed it)

### 3.3 Provenance Header (canonical)

Every source-material file MUST begin with a provenance header in the following form:

```yaml
---
type: source
subtype: writeup | report | blog | tips-tricks | research | docs
source_url: <canonical URL or local archive path>
retrieved_at: <YYYY-MM-DD>
author: <author or "anonymous">
tags: [<tag-1>, <tag-2>, ...]
supersedes: <path-to-previous-version>  # if applicable
---
```

> See GAP-KF-01 below: `file-contracts.md` §4.7 requires a source URL or reference, retrieval date, type, and tags. The YAML field-name mapping and any additional optional fields remain an OPEN TODO; this example is a working format, not the final schema.

## 4. Layer 2 — Processed Extraction

> Sources: Buggy Master Blueprint §22 + `architecture/file-contracts.md` §4.8 (canonical integration, not rewrite).

### 4.1 What a Processed Extraction Is

A processed extraction is a **structured, condensed, and reframed** version of one or more source-material items.

It extracts:

- patterns
- cases
- techniques
- prerequisites
- validation steps
- impact
- false positives
- provenance (links back to source)

> Source: Buggy Master Blueprint §22 (canonical integration, not rewrite).

### 4.2 Processed Extraction Contract

> Source: `architecture/file-contracts.md` §4.8 (referenced, not duplicated).

A processed extraction MUST:

- link to every source it extracts from (source-provenance is required)
- declare its extraction date and the extractor (human / AI / hybrid)
- be stored at `/knowledge/processed/<item>.md`
- use a structured format (sections per the categories above) rather than freeform prose
- be **append-only**; corrections or supersessions are new files with `supersedes` links

A processed extraction MUST NOT:

- be a full copy of the source (link instead)
- introduce claims that are not in the linked source
- replace the source file (sources remain canonical)
- become a "second knowledge repository" (the canonical source stays in `/knowledge/<source-type>/`)

### 4.3 When to Create a Processed Extraction

Create a processed extraction when:

- a source is too long or noisy to load directly into context
- the same source needs to be referenced from multiple skills
- the pattern in the source generalizes beyond the source's specific case
- a Skill or Concept needs a structured reference, not a source link

Do NOT create a processed extraction when:

- the source is already short and self-contained (link to it directly)
- the extraction would just paraphrase the source without adding structure

## 5. Layer 3 — Concepts

> Sources: Buggy Master Blueprint §22 + `architecture/file-contracts.md` §4.9 (canonical integration, not rewrite).

### 5.1 What a Concept Is

> Source: Buggy Master Blueprint §22 (canonical integration, not rewrite).

A concept is **synthesized reusable knowledge** derived from multiple sources. Concepts generalize patterns across more than one source and become the canonical reusable form for a domain.

### 5.2 Canonical Concept Areas

```
concepts/
├── methodology/         # how to approach a category of work
├── heuristics/          # rules of thumb
├── vulnerability-classes/
│   ├── idor/            # methodology, patterns, scenarios, edge-cases,
│   │                    # false-positives, validation, sources
│   ├── xss/             # same fixed sub-schema
│   └── access-control/  # same fixed sub-schema
├── attack-patterns/     # reusable attack patterns
├── false-positives/     # FP patterns and how to detect them
└── prioritization/      # how to prioritize targets / findings
```

> The fixed sub-schema for `/concepts/vulnerability-classes/<class>/` is `(methodology, patterns, scenarios, edge-cases, false-positives, validation, sources)`. The canonical schema is `templates/prompts/vulnerability-skill-template.md` (to be authored at templates phase; not in current tree).

### 5.3 Concept Contract

> Source: `architecture/file-contracts.md` §4.9 (referenced, not duplicated).

A concept MUST:

- be derived from **multiple** processed-extraction or source-material items (multi-source by definition)
- link to every source it synthesizes from
- live at `/concepts/<area>/<file>.md`
- use the fixed sub-schema when one exists for the area

A concept MUST NOT:

- be a single-source claim (that stays in `/knowledge/processed/`)
- contain per-target data (that goes in `/testing/<target>/`)
- be embedded by a skill (skills reference, never embed — see `agent-architecture-rules.md` §4.4 and §4.5)

### 5.4 Adding a New Concept Area

> Source: Architecture Builder §46 — change discipline.

Before adding a new area under `/concepts/`, ask:

1. Does an existing area already own this responsibility?
2. Does this introduce a new source of truth?
3. Is this a methodology problem or an orchestration problem?
4. Can the existing area absorb this with a new sub-file?

If the answer to all four is "no" and the new area is genuinely needed, add it via an explicit architectural decision (not a silent addition).

## 6. Layer 4 — Retrieval

> Source: Buggy Master Blueprint §30 (canonical integration, not rewrite).

### 6.1 Role

> Source: Buggy Master Blueprint §30 (canonical integration, not rewrite).

Retrieval exists to surface relevant knowledge without loading everything into context.

The system should avoid:

- loading all knowledge at startup
- giant raw transcripts
- massive context windows
- uncontrolled source dumping

Retrieval should be relevant, bounded, and traceable.

### 6.2 Retrieval Status (deferred)

> Source: Architecture Builder §39 + `architecture/file-contracts.md` §3 / §4 (deferred subsystem).

The retrieval layer is a **deferred implementation** in the canonical build order (phase 10). Its architectural boundary is fixed (search, metadata, index under `/retrieval/`); its implementation is not.

What this contract establishes now:

- the existence of the retrieval layer
- its purpose (bounded, relevant, traceable knowledge surfacing)
- the path `/retrieval/{search,metadata,index}/`

What this contract does NOT establish now:

- the retrieval algorithm
- the index schema
- the metadata schema
- the search semantics

> See GAP-KF-02 (the implementation details of the retrieval layer are an OPEN TODO).

## 7. Layer 5 — Skill Consumption

> Sources: Buggy Master Blueprint §22 + `architecture/agent-architecture-rules.md` §4.4 / §4.5 (canonical integration, not rewrite).

### 7.1 What a Skill May Reference

A skill may reference:

- a concept (via path under `/concepts/<area>/<file>.md`)
- a processed extraction (via path under `/knowledge/processed/<item>.md`)
- a source directly (when the source itself is the appropriate reference)

The skill should **generally prefer the most derived layer that covers the need** (concept > processed > source). Direct source references remain allowed when the source itself is the appropriate reference. The exact source-vs-processed-vs-concept selection policy is **deferred** (GAP-KF-06).

A skill may NOT:

- embed the full content of a source
- embed a processed extraction
- embed a concept
- duplicate the canonical content of any layer
- hold target-specific state (that lives in `/testing/<target>/`)

> Source: `architecture/agent-architecture-rules.md` §4.4 (canonical integration, not rewrite).

### 7.2 The `references/` Subfolder

> Source: `architecture/agent-architecture-rules.md` §4.5 (canonical integration, not rewrite).

A skill MAY have a `references/` subfolder. The semantic split is:

```
references/   = bounded supporting references, derived material,
                pointers to relevant contract / concept / artifact
                names. Lives next to the skill that uses it.

knowledge/    = canonical external source material
                (writeups, reports, blogs, research, docs).
                Lives under /knowledge/<source-type>/ and is the
                source of truth for source content.
```

`references/` must NOT duplicate canonical source material from `knowledge/`. If a skill needs to cite a writeup, it links to `/knowledge/writeups/...` (or via `/concepts/` / `/retrieval/`); it does not embed the source.

## 8. The Four Functions of Knowledge (Research Mode)

> Source: Sources Research Foundation (consensus across 12 source families) + Master Blueprint §11 (canonical integration, not rewrite).

Per Master Blueprint §11, Research Mode is a core part of Buggy. The knowledge flow supports it through four distinct functions. **All four are part of the same knowledge pipeline**, not separate systems.

```
1. RESEARCH & UNDERSTAND THE PROGRAM
   - Read sources / processed extractions / concepts
   - Build a model of the program, business, scope, technology stack

2. PATTERN EXTRACTION
   - Observe "the developer's mistake repeats" patterns
   - Generalize a heuristic that can be applied to other targets

3. HYPOTHESIS GENERATION
   - From a real observation, ask: "what's the related research?"
   - Build a workflow, test it, validate it

4. SKILL / METHODOLOGY IMPROVEMENT (informational only — see below)
   - Knowledge can inform research, hypothesis generation, and skill improvement.
   - When a methodology proves out, capture it as a Skill update.
   - When a methodology fails, capture it as an FP or lesson.
```

> Source: Buggy Master Blueprint §11 (canonical integration, not rewrite).

**Important boundary:** the knowledge flow **informs** skill / methodology improvement, but it does **not own** the improvement loop from real hunting outcomes. The learning pipeline is owned by `architecture/learning-flow.md`, which governs lessons, memory updates, and methodology improvement from real-hunt outcomes (validated findings, false positives, missed hypotheses, failed tests, regression outcomes, report outcomes). Successful and failed methodology during real hunting flows through the Learning Flow, not the Knowledge Flow.

The knowledge flow does not differentiate between "research" and "hunting". A hunting session can produce a hypothesis that triggers research, which produces a processed extraction, which produces a concept, which informs a skill. The pipeline is continuous; the **ownership boundary** is between what knowledge is (external / synthesized) and what memory is (real-hunt lessons).

## 9. Knowledge vs Memory

> Source: Buggy Master Blueprint §23 / §44 (canonical integration, not rewrite).

These are different systems. They must not be merged.

```
KNOWLEDGE                          MEMORY
─────────                          ──────
"What is known from external       "What did Buggy and the hunter
 material?"                         learn from real hunting?"

External sources                   Lessons from actual hunts
Authored by humans or by AI         Authored by humans or by AI
extraction from humans              from real outcomes

Lives in:                          Lives in:
- /knowledge/<source-type>/        - /memory/CONTEXT_LEDGER.md
- /knowledge/processed/            - /memory/methodology.md
- /concepts/<area>/                - /memory/patterns.md
                                    - /memory/FALSE_POSITIVE_DB.md
                                    - /memory/report-lessons.md
                                    - /memory/lessons/

Provenance:                        Provenance:
source URL / archive path          real-hunt event (finding, FP, miss)
```

> See `architecture/learning-flow.md` for the memory / learning pipeline.

The two systems may **reference** each other (e.g. a Concept may cite a memory/lessons entry as a "validated-in-practice" note) but they must not be merged into a single repository.

**Critical rule on cross-references:** when Knowledge references Memory (or vice versa), the reference is **a pointer, not a transfer**. A cross-reference MUST NOT:

- transfer ownership of the referenced content
- change the source of truth of the referenced content
- cause the referenced content to be reclassified into the referencing system
- make the referenced content re-discoverable only via the referencing system

In other words, after a Concept cites a memory note as "validated-in-practice", the memory note **remains** in `/memory/` and the Concept **remains** in `/concepts/`. Neither is moved, copied, or reclassified. Each keeps its own provenance and lifecycle.

## 10. The Notes Funnel vs The Knowledge Flow

> Source: Buggy Master Blueprint §14 + `architecture/validation-model.md` §3.2 (cross-reference, not duplication).

The **Notes Funnel** and the **Knowledge Flow** are different pipelines.

```
Notes Funnel            vs.        Knowledge Flow
──────────────                     ───────────────
Target-specific                    Cross-target / per-domain
NOTES → LEADS →                    Source → processed → concepts
PRIMITIVES →                        → retrieval → skills
FINDINGS → REPORTS
```

They interact at one specific point:

- a **confirmed finding** (output of the Notes Funnel) is one of the inputs to the **memory** pipeline (`/memory/`).
- a **concept** (output of the Knowledge Flow) may be referenced by a **skill** (consumed during hunting) but it is not a finding.

> A finding is not a concept. A concept is not a finding. The two pipelines must not be conflated.

## 11. Cross-References

### 11.1 Files That Read This Contract

- `architecture/learning-flow.md` — depends on this contract for the Knowledge Flow / Memory boundary.
- `/AGENTS.md` (steering layer that points to this contract)
- `.opencode/skills/<name>/SKILL.md` (each skill references concepts/retrieval per §7 of this contract)
- `knowledge/processed/<item>.md` (extraction format follows this contract)
- `concepts/<area>/<file>.md` (concept contract follows this contract)
- `templates/prompts/vulnerability-skill-template.md` (when authored; the vulnerability-class sub-schema lives in this file)
- `retrieval/**` (deferred; uses the architectural boundary from this contract)

### 11.2 Files This Contract Reads

- `architecture/file-contracts.md` (per-type contracts for /knowledge/ and /concepts/)
- `architecture/agent-architecture-rules.md` (Skill references/ contract)
- `architecture/validation-model.md` (the Notes Funnel vs Knowledge Flow distinction)

### 11.3 Files This Contract Does NOT Cover (Linked Out)

- `architecture/learning-flow.md` — the memory / lessons / FP-DB pipeline (separate by design)
- `runtime/opencode/loader.md` — how skills are loaded at runtime
- `runtime/tool-manifest.md` — which tools may interact with the knowledge layer

## 12. ⚠️ GAP NOTES

The following items are **OPEN TODOs** in the current architecture. They are intentionally not resolved here because the v6 source material did not provide enough specification to invent a contract without inventing architecture. Each gap is recorded with what is missing and where it should land when the missing specification becomes available.

### GAP-KF-01: Provenance header — final field-name mapping and optional fields

- **What's missing:** The canonical YAML field mapping for the provenance header in §3.3 and any additional optional metadata fields.
- **Why it's a gap:** `file-contracts.md` §4.7 already establishes the required provenance values: URL or source reference, retrieval date, type, and tags. The unresolved portion is the final field-name/schema mapping and any additional optional fields, not whether those required values are needed.
- **Where it should land:** this contract (§3.3) or a dedicated `templates/source-provenance.md`, once specified.
- **Status:** OPEN TODO — the required provenance values from `file-contracts.md` §4.7 remain mandatory. Do not invent additional required fields.

### GAP-KF-02: Retrieval implementation details

- **What's missing:** the retrieval algorithm, index schema, metadata schema, and search semantics for `/retrieval/{search,metadata,index}/`.
- **Why it's a gap:** the architectural boundary is fixed; the implementation is deferred to build order phase 10.
- **Where it should land:** this contract (§6.2) or a new `runtime/retrieval.md` once implementation begins.
- **Status:** OPEN TODO — do not invent the algorithm here.

### GAP-KF-03: Program Knowledge Pack schema

- **What's missing:** the fields, lifecycle, retrieval indexing, and provenance structure for the per-program knowledge pack that supports Research Mode.
- **Why it's a gap:** sources support the existence of a Program Knowledge Pack but do not specify its schema. It interacts with the knowledge flow (it consumes concepts and processed extractions) but is itself a per-program artifact, not a cross-program layer.
- **Where it should land:** `architecture/learning-flow.md` (since it lives at the target state) or a new `architecture/research-mode.md` once specified.
- **Status:** OPEN TODO — do not invent the schema here.

### GAP-KF-04: Concept synthesis threshold

- **What's missing:** the precise rule for "synthesized from multiple source-derived items" — how many source-material items, processed extractions, or a mix are required? What about a concept derived from one source + one prior concept? The exact threshold is intentionally not specified in the body of this contract.
- **Why it's a gap:** the multi-source rule is established (no single-source concepts) but the literal count is not.
- **Where it should land:** this contract (§5.3).
- **Status:** OPEN TODO — do not invent a hard count here.

### GAP-KF-05: Knowledge GC / retention policy

- **What's missing:** how long processed extractions and concepts live, how staleness is detected, and what happens when a source is removed.
- **Why it's a gap:** sources are immutable, but the upper layers may need a retention policy.
- **Where it should land:** `architecture/learning-flow.md` (the memory GC policy is a related concern) or this contract.
- **Status:** OPEN TODO — defer until the memory pipeline is specified.

### GAP-KF-06: When a skill should link to source vs processed vs concept

- **What's missing:** the decision rule for which layer a skill should reference.
- **Why it's a gap:** the layers exist; the rule "use the most-derived layer that covers the need" is implied but not formalized.
- **Where it should land:** this contract (§7.1) or `agent-architecture-rules.md` §4.4.
- **Status:** OPEN TODO — do not invent a hard rule here.

### GAP-KF-07: Knowledge vs Concept distinction at the sub-schema level

- **What's missing:** the sub-schema for `/concepts/heuristics/`, `/concepts/attack-patterns/`, `/concepts/false-positives/`, and `/concepts/prioritization/` — only `/concepts/vulnerability-classes/` has a fixed sub-schema.
- **Why it's a gap:** sources describe these areas but do not give them a fixed sub-schema.
- **Where it should land:** `templates/concept-area-schemas.md` (new template) when authored.
- **Status:** OPEN TODO — do not invent the schemas here.

### GAP-KF-08: AI extraction vs human extraction policy

- **What's missing:** whether the extractor is allowed to be AI-only, and what provenance / review requirements apply when AI extracts a processed extraction.
- **Why it's a gap:** sources support both human and AI extraction but do not specify the trust boundary between them.
- **Where it should land:** this contract (§4) and possibly `architecture/agent-security.md`.
- **Status:** OPEN TODO — do not invent an extraction trust policy here.

### GAP-KF-09: Notes Funnel ↔ Knowledge Flow interaction contract

- **What's missing:** the precise rule for when a confirmed finding becomes a Concept (vs staying in memory) — currently the two pipelines are kept separate by design, but the boundary cases (e.g. "this finding is actually a reusable pattern") are not specified.
- **Why it's a gap:** §10 establishes that the two pipelines are distinct, but does not specify the boundary case.
- **Where it should land:** this contract (§10) and `architecture/learning-flow.md`.
- **Status:** OPEN TODO — do not invent a promotion rule here.

### GAP-KF-10: Concept update / version policy

- **What's missing:** when a Concept is updated, what happens to the previous version, and how do skills detect that they should re-anchor.
- **Why it's a gap:** concepts are append-or-revise but the revision semantics are not specified.
- **Where it should land:** this contract (§5) or `file-contracts.md` §4.9.
- **Status:** OPEN TODO — do not invent a version policy here.

---

These gaps are recorded so that future work does not silently invent contracts where the architecture has not yet been specified. Each gap names what is missing, why it is missing, where the contract belongs, and the rule that the answer must follow.
```
