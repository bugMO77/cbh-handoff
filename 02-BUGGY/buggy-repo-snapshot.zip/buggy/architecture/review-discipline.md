# architecture/review-discipline.md

> **Status:** review
> **Version:** v0.2
> **Scope:** Defines the process discipline by which Buggy artifacts are prepared, reviewed, corrected, escalated, approved, and locked. Establishes the Builder / Reviewer / Architect / Project-Owner responsibility split, the required pre-build dependency extraction, the independent review model, the bounded-correction model, and the truthful evidence/status reporting rules. This contract governs **process**, not technical content.
> **Authority:** Architecture contract. This file is the authoring-governance dependency referenced by `runtime/tool-manifest.md` v1.5. It refines the review workflow implicitly used in that manifest's §10 Self-Application.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-architecture-rules.md`, `architecture/validation-model.md`, `architecture/agent-security.md`.
> **Depended on by:** `runtime/tool-manifest.md` v1.5 (declared in its header); any future architecture or runtime artifact that declares this review discipline as a dependency.
> **Related status:** `runtime/redaction.md` v1.0 remains FREEZE/unapproved. This contract does not reopen or modify it, and does not itself close any GAP.

> **Lock decision (2026-10-13):** LOCKED by explicit project-owner direction, following independent review dispositions (`PASS — READY TO LOCK` on v0.1; `REVISE — BOUNDED CORRECTION` then an accepted corrected candidate on v0.2) and the three bounded corrections recorded in the change summary at the end of this file. This is a **document/policy lock** only. It does not claim runtime enforcement, does not close any GAP, does not authorize any repository write, and does not change the state of any other artifact. The lifecycle `Status` field above (`review`) and this LOCKED decision are separate; the lock does not overwrite the lifecycle vocabulary of `architecture/file-contracts.md` §8.

> **Version note (v0.2 — status reconciliation only).**
>
> - `architecture/review-discipline.md` **v0.1 was explicitly locked by the project owner on 2026-10-13**. That lock is preserved as history; it is not revoked, overwritten, or re-decided by the existence of v0.2.
> - The current document is **v0.2**, which supersedes v0.1 as the current approved baseline (see the lock record `BUGGY-REVIEW-DISCIPLINE-v0.2-LOCK-RECORD.md`).
> - v0.2 exists solely to reconcile the document's **lifecycle Status metadata** with the separate lock decision, per `architecture/file-contracts.md` §8 (which does not include `LOCKED` in its lifecycle Status vocabulary) and §4.1 (which requires the architecture metadata block).
> - The full v0.1 lock record is preserved as a **separate artifact** (`BUGGY-REVIEW-DISCIPLINE-v0.1-LOCK-RECORD.md`). Section 10 of this document is a **historical summary** for context only; it is not a verbatim reproduction of that separate record.
> - No decision recorded in v0.2 changes the state of any other artifact, closes any GAP, resolves any `PROPOSED DECISION RD-*`, or authorizes any repository write.

---

## 1. Purpose

This contract defines the **process discipline** for authoring Buggy artifacts. It exists to make explicit:

- who may prepare a candidate, who reviews it, who escalates cross-contract decisions, and who approves or locks it;
- what a candidate must contain before it can be independently reviewed;
- how a review verdict is expressed and how it differs from an owner decision;
- how correction passes are bounded and when escalation is required instead of another pass;
- what evidence and status claims are permitted, and which claims are prohibited;
- how freeze and reopen are handled.

It does **not** define:

- any technical contract's content (`file-contracts.md`, `agent-architecture-rules.md`, `validation-model.md`, `knowledge-flow.md`, `learning-flow.md`, `agent-security.md` each own their subject matter);
- runtime tool gating (`runtime/tool-manifest.md`);
- redaction policy or protocol (`runtime/redaction.md`);
- model routing or operational IDs (`architecture/model-routing.md`, `runtime/model-routing.md`);
- the internal structure of skills, commands, or templates.

If a downstream artifact needs a process rule, it references this contract rather than duplicating it.

---

## 2. Role Boundaries

> Source: header and §10 of `runtime/tool-manifest.md` v1.5 name this discipline; the role names (Builder / Reviewer / Architect) are the ones used there. The project-owner role is implied throughout the owner-authorized lock records supplied in the current state.

Buggy distinguishes four roles. No role may silently perform another role's function.

### 2.1 Builder

A **Builder** prepares a candidate from explicit, source-backed requirements.

The Builder MUST:

- perform the pre-build dependency extraction defined in §3.2 before authoring;
- preserve all inherited invariants from upstream contracts;
- make no architectural decision that a source does not support;
- mark unsupported items as **PROPOSED — OWNER DECISION REQUIRED**;
- deliver the full candidate, not a patch fragment;
- include a change/source report, a self-check, and a truthful record of what was and was not performed;
- stop at the candidate stage; the Builder does not lock, freeze, approve, or reopen.

The Builder MUST NOT:

- modify or reopen a locked contract;
- claim repository writes, commits, test executions, or runtime verification;
- invent architectural decisions not present in a named source.

> Source: `runtime/tool-manifest.md` v1.5 header and §10, taken as the observed discipline the manifest itself followed.

### 2.2 Reviewer

A **Reviewer** independently checks a candidate against the specified sources, invariants, dependency graph, and acceptance criteria.

The Reviewer MUST:

- read the entire candidate, not excerpts;
- verify each source claim in the candidate against its cited source;
- verify that upstream contracts are not contradicted;
- test key edge cases in reasoning where applicable — including boundary conditions, cross-reference resolution, and contradiction checks against upstream contracts;
- report findings as blockers or non-blocking suggestions;
- return a bounded disposition (see §4);
- distinguish what it verified from what it could not verify.

The Reviewer MUST NOT:

- treat a Builder self-check as sufficient review;
- resolve a cross-contract conflict itself;
- change any artifact's lifecycle state, lock, freeze, approve, or reopen any artifact — a Reviewer produces a disposition, not a state change;
- manufacture findings where the candidate is consistent with its sources.

> The independence requirement mirrors the Validator independence established in `architecture/validation-model.md` §8.3: the reasoning path that produced the artifact is not the appropriate path to validate it.

### 2.3 Architect

An **Architect** handles cross-contract concerns that are outside the Reviewer's authority.

The Architect MUST:

- evaluate cross-contract consistency, dependency conflicts, and scope changes;
- identify decisions that need escalation to the project owner;
- apply the role/authority boundaries established in this contract: the Builder produces candidates, the Reviewer produces dispositions, the Architect escalates cross-contract concerns, and only the project owner approves, locks, freezes, or reopens an artifact;
- refuse to resolve an open GAP as a side effect of authoring.

The Architect MUST NOT:

- silently amend a locked contract;
- close or reassign a GAP on its own authority;
- turn an authoring task into an architecture-revision task;
- change any artifact's lifecycle state or authorize a lock, freeze, or reopen.

> Source: the role-boundary vocabulary follows `runtime/tool-manifest.md` v1.5 header and §10 and the artifact-type semantics established in `architecture/agent-architecture-rules.md` §13. The four-role division and the specific mapping of authority to the project owner are this contract's own operational rule; they are not claimed as a formally codified order in `architecture/file-contracts.md`.

### 2.4 Project Owner

The **project owner** is the sole authority for approval, lock, freeze, reopen, and any change to a locked artifact.

The distinction that this contract exists to protect:

- A Reviewer disposition — including `FREEZE — UNRESOLVED CONFLICT`, `PASS — READY TO LOCK`, or any other verdict — is a **recommendation**. It is recorded, but it does not itself change any artifact's lifecycle state, approve, lock, freeze, or reopen anything.
- The **owner alone** records:
  - the actual freeze decision (transition of a candidate to a FROZEN state);
  - the actual lock/approval decision;
  - the authorization to reopen a frozen or locked artifact;
  - the versioning of any such decision.

The owner's decisions are:

- explicit;
- versioned where a locked artifact is affected;
- recorded separately from any review verdict (see §4.3 and §5).

No role — including the Architect, the Reviewer, and any model — may infer owner authority from a review verdict, a self-check, or a draft.

> Source: every lock record supplied in the current state is an explicit owner decision (`runtime/tool-manifest.md` v1.5 lock record; `runtime/registry.json` v0.7-rev2 lock record). No such record grants any role the ability to substitute for owner authorization.

---

## 3. Workflow Stages

The stages below are the minimum. Where a source does not establish a specific detail, the omission is marked as **PROPOSED — OWNER DECISION REQUIRED** rather than filled in.

### 3.1 Intent and scope

Before work begins, the requester states:

- the artifact path;
- the requested change (new artifact, correction, or re-derivation);
- the expected output (candidate, review, plan, etc.);
- the excluded work (what this task is not).

> Source: the requesting prompts in the current state follow this pattern (`03-DEEPSEEK-AUTHORING-PROMPT-v1.0.txt`); the discipline is the one `runtime/tool-manifest.md` §10 Self-Application records having been followed.

### 3.2 Pre-build dependency extraction

Before authoring, the Builder MUST enumerate:

- upstream sources and their status evidence;
- downstream consumers (who reads or depends on this artifact);
- invariants inherited from upstream contracts;
- OPEN GAPs that affect the artifact;
- unresolved owner decisions that block a defensible draft;
- the authoritative source sections that will be cited.

The extraction is part of the candidate deliverable (see §3.4), not an optional step.

> Source: `runtime/tool-manifest.md` §10 Self-Application explicitly records "ran PRE-BUILD dependency extraction" and "preserved inherited invariants from the Phase 1 contracts". This stage operationalizes that observed practice.

### 3.3 Readiness check

If a required source body is unavailable, or if a source conflict is unresolved, the Builder MUST refuse to manufacture content. Instead the Builder:

- states the limitation;
- records the missing source or conflict;
- escalates per §3.7;
- does not author past the missing decision.

**PROPOSED — OWNER DECISION REQUIRED:** whether a formal readiness gate (a checkable artifact state) is required, or whether the current informal statement-of-limitation is sufficient. No source establishes a formal gate.

### 3.4 Candidate preparation

A candidate MUST include:

- valid architecture metadata per `architecture/file-contracts.md` §4.1. The required metadata fields in that section are `status`, `scope`, `depends-on`, and `depended-on-by`. An `authority` field may be included as a supplemental field where the artifact type benefits from it, but §4.1 does not itself require it;
- a `status` drawn from the lifecycle vocabulary of `architecture/file-contracts.md` §8. `LOCKED` is **not** a lifecycle `status` value; it is a separate owner decision recorded elsewhere (see §4.2, §5 item 4, and §10), and owner authorization to lock an artifact does not, by itself, add `LOCKED` to the lifecycle vocabulary or authorize its use in the `status` field;
- a `version` recorded separately from `status` when the artifact is versioned;
- the full artifact body (not a fragment or patch);
- a change/source report mapping each major rule to the source file and section that supports it;
- a self-check stating SATISFIED / NOT SATISFIED / NOT VERIFIED per requirement, with reasons;
- a truthful list of work not performed (no test execution, no repository write, no runtime verification).

> Source: the required metadata fields are stated in `architecture/file-contracts.md` §4.1. The lifecycle vocabulary, including the absence of `LOCKED` from it, is stated in `architecture/file-contracts.md` §8. The supplemental `authority` field is used by the existing architecture contract headers and by `runtime/tool-manifest.md` v1.5, but is not mandated by §4.1. The self-check vocabulary (SATISFIED / NOT SATISFIED / NOT VERIFIED) follows the pattern observed in the redaction review record (`10-runtime-redaction-v1.0-original-independent-review.md`, `12-runtime-redaction-v1.0-revised-candidate-from-DeepSeek.md` §11).

### 3.5 Independent review

An independent Reviewer compares the entire candidate against:

- the specified sources;
- the invariants of upstream contracts;
- the dependency graph;
- the acceptance criteria stated for the artifact.

The Reviewer produces a bounded verdict (§4) plus a list of findings. A finding is either:

- **blocking** — must be resolved or escalated before lock can be considered; or
- **non-blocking** — noted for future revision; does not block the current disposition.

> Source: the review model observed in the redaction review (`10-runtime-redaction-v1.0-original-independent-review.md`) distinguishes blocking findings from non-blocking notes.

### 3.6 Bounded correction

If the Reviewer's verdict requires correction, the correction request MUST identify:

- each finding by ID or heading;
- the exact scope of allowed change (only what the findings require);
- the constraint that unrelated parts of the artifact are not to be redesigned.

A correction pass is bounded by the findings it addresses. It is not an invitation to reopen the design.

**PROPOSED — OWNER DECISION REQUIRED:** whether a universal maximum number of correction passes exists. No supplied source establishes one. The rule of the redaction workflow — one bounded correction pass, then either lock or freeze — is observed in practice but is not stated as a universal cap.

If, after the authorized pass, a material contradiction remains, the correct next step is **escalation to the project owner** with a recommendation to consider freezing the artifact. A Reviewer may issue a `FREEZE — UNRESOLVED CONFLICT` disposition (§4.1), but that disposition alone does not transition the artifact's lifecycle state. Another writing pass is not the correct response.

> Source: the redaction disposition record shows the reviewer recommended freeze and stopped; the actual FREEZE state of the artifact was a subsequent owner-side disposition.

### 3.7 Escalation

The following MUST be escalated rather than resolved by the Builder or Reviewer:

- a conflict between two source-backed statements;
- a requested change to a locked artifact;
- a requested change to the scope of an existing contract;
- the possible closure, downgrade, or reassignment of an OPEN GAP;
- the introduction of a new artifact, capability, or source-of-truth;
- any decision not derivable from the supplied sources.

> Source: `runtime/tool-manifest.md` §10 records "did not silently resolve any architectural GAP"; the redaction FREEZE review (`13-runtime-redaction-independent-review-FREEZE.md`) shows the escalation of a cross-contract conflict to the owner rather than resolving it in-document.

### 3.8 Disposition

A disposition record distinguishes, at minimum:

1. review verdict (Reviewer output — a recommendation);
2. owner approval / lock decision (owner output — the authoritative transition);
3. repository transfer;
4. test execution;
5. runtime verification.

These five states are independent. A candidate may, for example, pass review and be owner-approved, without being transferred to the repository, and without any test having been executed. None of the five implies another.

> Source: `runtime/tool-manifest.md` lock record explicitly separates the policy lock from implementation, and the `runtime/registry.json` lock record separates lock from schema validation and repository commit.

### 3.9 Freeze and reopen

A **FROZEN** artifact is an unapproved candidate preserved for traceability. It:

- may not be used as a source of truth;
- may not be partially adopted;
- stays frozen until an explicit, versioned, owner-authorized reopening.

**Transition into FROZEN state:** the transition is an **owner decision**, not a reviewer verdict. A Reviewer may recommend `FREEZE — UNRESOLVED CONFLICT` (see §4.1), but the artifact only becomes FROZEN when the owner records that decision. Until then, the artifact remains in its prior lifecycle state (typically `review` or `draft`).

**Reopening:** only the owner may authorize reopening, and only through an explicit, versioned decision.

**PROPOSED — OWNER DECISION REQUIRED:** the exact "versioned" mechanism for reopening a frozen artifact (a new version number, a supersedes link, a named decision record, or another form) is not established by the supplied sources.

> Source: the redaction FREEZE disposition (`13-runtime-redaction-independent-review-FREEZE.md`, `14-DEEPSEEK-FREEZE-NOTICE.txt`) states the candidate remains unapproved and that any reopening is an explicit owner decision.

---

## 4. Review Verdicts

### 4.1 Formal Buggy review verdicts

The following four verdicts are Buggy's **formal review vocabulary**, adopted by explicit project-owner decision on 2026-10-13 (see §4.4). A Reviewer's disposition is one of these four.

- **`PASS — READY TO LOCK`** — no blocking findings remain; the Reviewer recommends that the owner consider a lock. This is a recommendation. It is not approval, not a lock, and not a state transition.

- **`REVISE — BOUNDED CORRECTION`** — blocking findings exist that a bounded correction pass can resolve. The verdict names the findings and limits the authorized scope of the pass. It does not itself authorize a redesign or an unbounded revision loop.

- **`FREEZE — UNRESOLVED CONFLICT`** — a material conflict or missing prerequisite prevents a defensible lock; the Reviewer recommends that authoring stop and that the conflict be escalated to the project owner. **This is a Reviewer recommendation only.** It does not itself freeze the artifact, does not change its lifecycle state, and does not authorize any subsequent action. The owner decides whether to record the freeze.

- **`NOT READY — SOURCES INSUFFICIENT`** — the available and mapped sources are too incomplete or unverified for a defensible review to be conducted. This is a review disposition only; it changes no lifecycle state and does not itself block or unblock anything beyond the Reviewer's recommendation to defer assessment.

> Source: `REVISE` and `FREEZE` are directly observed in the redaction review sequence (`10-runtime-redaction-v1.0-original-independent-review.md`, `13-runtime-redaction-independent-review-FREEZE.md`). `PASS` and `NOT READY` were previously proposed vocabulary in an earlier draft of this contract; they are now formal by explicit project-owner decision (see §4.4), not by prior source practice.

### 4.2 A verdict is not a state change

No Reviewer verdict — `PASS`, `REVISE`, `FREEZE`, or `NOT READY` — changes any artifact's lifecycle state. In particular:

- `PASS — READY TO LOCK` is a recommendation, not a lock.
- `FREEZE — UNRESOLVED CONFLICT` is a recommendation, not a freeze.
- Only explicit owner authorization establishes approval, lock, or freeze.

### 4.3 Verdict and owner decision are separate records

The review verdict and the owner decision are recorded separately. Neither replaces the other. A missing owner decision is not implicit approval. The verdict records what the Reviewer found and recommends; the owner record states what the owner decided.

### 4.4 Owner-decision record — formalization of the four verdicts (2026-10-13)

On **2026-10-13**, the project owner explicitly adopted the four verdict labels above — `PASS — READY TO LOCK`, `REVISE — BOUNDED CORRECTION`, `FREEZE — UNRESOLVED CONFLICT`, and `NOT READY — SOURCES INSUFFICIENT` — as Buggy's formal review vocabulary for this contract.

Scope of this decision:

- It formalizes the four verdict labels and the semantics stated in §4.1.
- It does **not** approve or lock this contract itself. That approval is a separate, later owner decision (see the lock decision in the header and the accompanying v0.2 lock record).
- It does **not** resolve, register, or reclassify any of the items recorded as `PROPOSED DECISION RD-01` through `RD-05` in §9. Those remain proposals only.
- It does **not** create, close, downgrade, or reassign any GAP.
- It does **not** alter `runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2, any of the reported locked architecture contracts, or `runtime/redaction.md` v1.0.
- It does **not** change the rule that a Reviewer verdict is a recommendation, not a lifecycle-state transition (§4.2, §4.3).

> Source: this record attributes the decision to explicit project-owner authorization on 2026-10-13. It does not claim that the historical source documents had already defined all four labels.

---

## 5. Evidence and Status Discipline

Every role in this contract is bound by the following:

1. A claim of file write, commit, diff, hash, test execution, or runtime verification requires direct evidence of that exact action. Absent evidence, the claim is not made.
2. A test that has not been run is **PROPOSED — NOT EXECUTED**, not "passing".
3. A policy rule is not evidence of runtime enforcement.
4. A document's metadata `status` is a **file-lifecycle value** per `architecture/file-contracts.md` §8 (e.g. `placeholder`, `draft`, `review`, `production`, `deprecated`, `superseded`). It is **not** the same as an explicit lock decision, a repository transfer, or a runtime-operational state. `LOCKED` is not one of the lifecycle Status values; it is a separate owner decision recorded elsewhere (see §3.4, §4.2, and §10).
5. A lock record that says "not implemented", "no schema validation", or "no commit" is honored as stated; the lock is a document/policy lock, not an operational one.
6. GAPs are not silently closed, downgraded, or reclassified. A GAP closes only through its owner's explicit decision and evidence.

> Source: the lifecycle status vocabulary is defined in `architecture/file-contracts.md` §8. The separation between the document's lifecycle status and the distinct states of an explicit lock decision, repository transfer, test execution, and runtime verification is established by the applicable owner lock records (`runtime/tool-manifest.md` v1.5 lock record; `runtime/registry.json` v0.7-rev2 lock record) and by explicit owner decisions. The self-check pattern is also present in the redaction review record.

---

## 6. Invariants This Contract Must Not Weaken

This contract MUST NOT be interpreted to:

- authorize any edit or reopening of a locked contract without an explicit, versioned owner decision;
- grant a Reviewer, a Builder, or a model the owner's lock, freeze, or reopen authority;
- treat any Reviewer verdict as itself changing an artifact's lifecycle state;
- permit a self-check to substitute for independent review;
- permit a review verdict to be treated as an owner decision;
- permit any GAP to be closed as a side effect of drafting;
- permit a material cross-contract conflict to be resolved without escalation;
- permit a written policy to be presented as an enforcement fact;
- permit a candidate to be described as LOCKED or production before explicit owner approval and, where applicable, repository transfer.

> Source: these constraints are individually supported by the supplied lock records, the redaction FREEZE disposition, and the accepted review discipline recorded in `runtime/tool-manifest.md` §10 Self-Application.

---

## 7. What This Contract Does NOT Cover

- The **content** of any other contract. Each contract owns its subject matter.
- **Runtime tool gating** — owned by `runtime/tool-manifest.md`.
- **Redaction policy or protocol** — owned by `runtime/redaction.md` (currently FREEZE).
- **Model routing** — architecture philosophy in `architecture/model-routing.md`; operational IDs and fallbacks in `runtime/model-routing.md`.
- **Validator technical independence mechanisms** — owned by `architecture/validation-model.md` §8; this contract only requires that the same separation apply to reviews of artifacts.
- **Repository mechanics** — commits, branches, and pushes are out of scope of this contract.
- **Test execution or automation** — out of scope; whether a test suite exists is a separate concern.
- **The exact lock-record format** — see §9.

---

## 8. Cross-References

- `architecture/file-contracts.md` §2, §4.1, §8, §9 — file ownership, architecture metadata requirements, lifecycle status vocabulary, change rules.
- `architecture/agent-architecture-rules.md` §13 — the underlying discipline references (this contract formalizes the process side; the agent contract owns the artifact-type semantics).
- `architecture/validation-model.md` §8 — Validator independence, from which the Reviewer independence rule is derived.
- `architecture/agent-security.md` §5, §8 — trust boundaries and outbound/disclosure constraints that the review process must respect.
- `runtime/tool-manifest.md` v1.5 — declared downstream consumer; cited as an observed example of the discipline. This contract does **not** declare the manifest as an upstream dependency.
- The owner-confirmed current state and Final Canonical Blueprint v3 — for the placement and ownership of artifacts.

---

## 9. Proposed Owner Decisions

The following items are not fully source-established. Each is a **proposal**, not a registered project GAP. They are recorded here for the owner's explicit decision. If the owner approves registering any of them as formal project GAPs, that registration is a separate decision and a separate record.

**None of the items below is a registered project GAP.** They do not carry `GAP-*` identifiers. They do not affect the status of any existing GAP anywhere in Buggy.

### PROPOSED DECISION RD-01: Formal readiness gate

- **Question:** is the readiness check in §3.3 a formal, checkable artifact state, or an informal statement-of-limitation?
- **Status:** proposal only — requires owner decision to register as anything further.

### PROPOSED DECISION RD-02: Universal correction-pass limit

- **Question:** does a universal numeric maximum exist for correction passes across all artifact types?
- **Status:** proposal only — requires owner decision. The observed practice (one bounded pass, then lock or freeze) is not elevated to a universal cap.

### PROPOSED DECISION RD-03: Reopen mechanism for a frozen artifact

- **Question:** what is the exact, versioned mechanism by which the owner authorizes reopening a frozen artifact?
- **Status:** proposal only — requires owner decision.

### PROPOSED DECISION RD-04: Lock-record format and location

- **Question:** is there a canonical lock-record format and location for all artifact types, or is each lock record ad hoc?
- **Status:** proposal only — requires owner decision. The supplied lock records (`runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2) are similar but not formally specified as a schema.

### PROPOSED DECISION RD-05: Reviewer independence mechanism

- **Question:** is Reviewer independence verified by a mechanism (different model identity, different context, different reviewer), or asserted by process?
- **Status:** proposal only — requires owner decision. `architecture/validation-model.md` §8.3 leaves the analogous Validator mechanism flexible; the same flexibility is preserved here.

---

## 10. Historical Summary — v0.1 Lock

This section is a **historical summary for context only**. The full, authoritative v0.1 lock record is maintained as a **separate artifact** (`BUGGY-REVIEW-DISCIPLINE-v0.1-LOCK-RECORD.md`). This section does not rewrite, revoke, or supersede that record.

**Decision date:** 2026-10-13
**Decision:** LOCKED by explicit project-owner authorization.
**Scope:** Document/policy baseline lock only.
**Repository transfer:** NOT performed as of that record.
**Tests/runtime verification:** NOT performed.

**Basis:** The owner authorized locking v0.1 after an independent review returned `PASS — READY TO LOCK`. Before the lock, two non-blocking review notes were addressed:

1. In §2.3, the authority-order reference was corrected to cite `architecture/file-contracts.md` §2 only; §9 was removed because it concerns creation/deletion rules.
2. In §3.5, the Reviewer's MUST list was expanded to require reasoning-based edge-case checks where applicable, including boundary conditions, cross-reference resolution, and contradictions against upstream contracts.

**What the lock means:** v0.1 was selected as the stable process-discipline baseline for Builder / Reviewer / Architect / Project-Owner work in Buggy.

**What the lock does not mean:**

- It does not close, open, downgrade, or reassign any GAP.
- `PROPOSED DECISION RD-01` through `RD-05` remain proposals, not registered GAPs.
- It does not alter `runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2, any of the six owner-reported locked architecture contracts, or any other artifact.
- It does not reopen `runtime/redaction.md` v1.0, which remains FREEZE/unapproved.
- It does not imply repository transfer, commit, test execution, or runtime verification.
- A Reviewer verdict remains a recommendation, not a lifecycle-state transition.

**Subsequent status reconciliation (v0.2):** `architecture/file-contracts.md` v1.3 §8 distinguishes lifecycle Status values from a separate lock decision and does not list `LOCKED` as a lifecycle Status value. v0.2 corrects the Status metadata without rewriting the historical v0.1 lock record. As of the v0.2 lock decision (2026-10-13), v0.2 supersedes v0.1 as the current approved baseline.

---

# Bounded Change / Source Report — v0.2 (final, locked)

This report lists:
(a) the changes v0.2 makes against the v0.1 locked baseline; and
(b) the three corrections applied during the final authorized bounded pass.

## (a) Changes in v0.2 vs. v0.1 locked baseline

| Change | Section | Source of the change |
|---|---|---|
| Header split into `Status:` + `Version:`; `LOCKED` recorded separately in a lock-decision blockquote | Header | Owner request + final correction 3. |
| Version note added, refined to reference §10 as summary and the separate v0.1 lock record artifact | Header | Owner request + prior RVD2-02 correction. |
| §3.4 metadata list corrected (required fields = `status`, `scope`, `depends-on`, `depended-on-by`; `authority` marked supplemental) | §3.4 | **Final correction 1.** |
| §3.4 lifecycle status wording tightened; `LOCKED` explicitly excluded from lifecycle `status`; owner lock does not override lifecycle vocabulary | §3.4 | **Final correction 3.** |
| §3.9 wording "typically `draft`" → "typically `review` or `draft`" | §3.9 | Consistency with v0.2 Status. |
| §2.3 attribution corrected — no longer claims a formally defined authority order in `file-contracts.md` §2; role boundaries described as this contract's own operational rule, with source-anchored boundaries from `agent-architecture-rules.md` §13 and `runtime/tool-manifest.md` v1.5 | §2.3 | **Final correction 2.** |
| §5 item 4 clarified: lifecycle vocabulary source is `file-contracts.md` §8; `LOCKED` is not a lifecycle value; separate states attributed to the applicable owner lock records | §5 item 4 | Prior RVD2-01 correction (retained). |
| §8 cross-reference list: `§5` removed; §4.1 description updated | §8 | Prior RVD2-01 correction (retained). |
| §10 retitled "Historical Summary"; states it is a summary, not a verbatim record, and references the separate v0.1 lock record artifact | §10 | Prior RVD2-02 correction (retained). |
| RD-06 removed (was present in an earlier draft of v0.2) | §9 | Prior RVD2-03 correction (retained). |

## (b) Final three corrections applied in this pass

1. **Metadata citation corrected (§3.4).** Required fields per `file-contracts.md` §4.1 now correctly listed as `status`, `scope`, `depends-on`, `depended-on-by`. `Authority` marked supplemental, not required.
2. **Authority-order attribution corrected (§2.3).** Removed the unsupported claim that `file-contracts.md` §2 defines a formal authority order. The four-role/authority mapping is now stated as this contract's own operational rule, with source anchoring to `agent-architecture-rules.md` §13 and `runtime/tool-manifest.md` v1.5.
3. **Lifecycle `Status` vs `LOCKED` made unambiguous (§3.4, header, §5 item 4).** Header split into `Status: review` and `Version: v0.2`; `LOCKED` recorded in a separate lock-decision blockquote. §3.4 now states explicitly that owner authorization to lock does not itself add `LOCKED` to the lifecycle vocabulary or authorize its use in the `status` field.

**No other edits.** §§1, 2.1, 2.2, 2.4, 3.1–3.3, 3.5–3.8, 4, 6, 7 unchanged except where noted. `Depends on` unchanged. Verdict vocabulary (§4.1, §4.4) unchanged. `PROPOSED DECISION RD-01` through `RD-05` unchanged.

| Rule | Source |
|---|---|
| Role names Builder / Reviewer / Architect | `runtime/tool-manifest.md` v1.5 header + §10 |
| Project-owner-only lock / approval / freeze / reopen | Supplied lock records (`runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2) |
| Pre-build dependency extraction and inherited invariants | `runtime/tool-manifest.md` §10 |
| Do not modify locked contracts; do not silently resolve GAPs | `runtime/tool-manifest.md` §10 |
| Bounded correction; lock requires explicit owner direction | `runtime/tool-manifest.md` §10 + v1.5 lock record |
| Lifecycle `Status` vocabulary; absence of `LOCKED` from it | `architecture/file-contracts.md` §8 |
| Required metadata fields | `architecture/file-contracts.md` §4.1 |
| Supplemental `authority` field | Observed in practice in `agent-architecture-rules.md`, `agent-security.md`, `validation-model.md`, `knowledge-flow.md`, `learning-flow.md`, and `runtime/tool-manifest.md` headers — but not mandated by §4.1 |
| Cross-reference rules | `architecture/file-contracts.md` §5 |
| Change discipline | `architecture/file-contracts.md` §9 |
| Reviewer independence (analogous to Validator) | `architecture/validation-model.md` §8.3 |
| Role/authority boundaries | This contract's own operational rule; anchored by `runtime/tool-manifest.md` v1.5 header + §10 and `agent-architecture-rules.md` §13 |
| Verdicts `REVISE`, `FREEZE` | Observed in redaction review sequence |
| Verdicts `PASS`, `NOT READY` (formalization) | Explicit project-owner decision, 2026-10-13 (see §4.4) |
| Trust-boundary constraints on outbound information | `architecture/agent-security.md` §5, §8 |

---

# Self-Check (required before locking)

| # | Check | Result | Reason |
|---|---|---|---|
| 1 | Metadata citation no longer overstates required fields in `file-contracts.md` §4.1 | **SATISFIED** | §3.4 now lists required fields as `status`, `scope`, `depends-on`, `depended-on-by`; `authority` explicitly marked supplemental. |
| 2 | Authority-order wording no longer misattributes a formal order to `file-contracts.md` §2 | **SATISFIED** | §2.3 no longer claims a formally defined authority order in §2; the rule is stated as this contract's own operational rule with source anchoring to `agent-architecture-rules.md` §13 and `runtime/tool-manifest.md` v1.5. |
| 3 | `Status` is a valid lifecycle value; `Version` recorded separately as `v0.2`; `LOCKED` appears only as a distinct owner decision/state | **SATISFIED** | Header reads `Status: review` and `Version: v0.2`; `LOCKED` appears in a separate lock-decision blockquote and in §10's historical summary, never in the `status` field. §3.4, §5 item 4 explicitly state `LOCKED` is not a lifecycle value and that owner lock authorization does not add it to the vocabulary. |
| 4 | All four approved review verdicts exactly defined | **SATISFIED** | §4.1 defines all four: `PASS — READY TO LOCK`, `REVISE — BOUNDED CORRECTION`, `FREEZE — UNRESOLVED CONFLICT`, `NOT READY — SOURCES INSUFFICIENT`. |
| 5 | v0.2 corrections retained: historical v0.1 lock handling; reviewer FREEZE vs owner decision; proposed decisions vs registered GAPs; bounded scope | **SATISFIED** | §10 preserves the v0.1 lock as a summary with the separate artifact referenced. §2.4, §4.2, §4.3, §6 preserve the FREEZE-vs-owner separation. §9 keeps RD-01…RD-05 as proposals only, not registered GAPs. RD-06 was removed and the version scope is limited to status reconciliation + the three authorized corrections. |
| 6 | No existing GAP was closed, modified, or silently reclassified | **SATISFIED** | No GAP references were altered. `GAP-TM-11`, `GAP-AS-02`, `GAP-AS-08`, `GAP-TM-17`, `GAP-VM-09` and all other source-recorded GAPs remain unchanged. |
| 7 | No other locked contract was changed or reopened | **SATISFIED** | No edit to `runtime/tool-manifest.md` v1.5, `runtime/registry.json` v0.7-rev2, the six architecture contracts, `runtime/redaction.md`, or any routing file. |
| 8 | No repository write, commit, runtime test, or implementation verification is claimed | **SATISFIED** | Header lock decision states "document/policy lock only"; the accompanying lock record will also state this. Work-Not-Performed statement below. |

**All eight checks passed.** Therefore the owner's authorization recorded in the current instruction is applied: v0.2 is LOCKED, and v0.2 supersedes v0.1 as the current approved baseline.
