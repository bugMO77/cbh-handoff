# file-contracts.md

> **Status:** production v1.3
> **Scope:** Defines how every file in Buggy is owned, written, read, and referenced.
> **Authority:** Architecture contract. Binds all other files.
> **Depends on:** nothing (this is the root contract).
> **Depended on by:** every other file in the system.

---

## 1. Purpose of This Document

This file defines **how files work** in Buggy. It does not define what any individual file contains — that is the job of:

- `architecture/agent-architecture-rules.md` for skills/agents/commands
- `architecture/validation-model.md` for gates
- `architecture/knowledge-flow.md` for knowledge handling
- `architecture/learning-flow.md` for memory and learning
- `architecture/agent-security.md` for security constraints
- `architecture/model-routing.md` (design) and `runtime/model-routing.md` (ops) for model selection
- `templates/*` for the structure of specific file types

This file defines the **shape of the system around files**: ownership, paths, contracts between files, and when a file may be created, modified, or removed.

## 2. Core Principles

```
1. Every file has exactly one owner (subsystem / role).
2. Every file has exactly one source of truth (the file itself; do not duplicate).
3. File type determines which contracts apply. Not every file needs every contract.
4. Metadata is per-type, not universal. We do not turn Markdown into a database.
5. Cross-references go through paths or named contracts, never by duplicating content.
6. A file's lifecycle matches its type: some are immutable, some are append-only, some are full-edit.
7. If two files need the same content, one of them is wrong. Use include / reference, not copy.
```

## 3. File Type Taxonomy

Buggy recognizes the following file types. Each has a canonical path location, an owner, a lifecycle, and a small set of type-specific metadata when needed.

| Type | Path Pattern | Owner | Lifecycle |
|---|---|---|---|
| Top-level config | `/README.md`, `/AGENTS.md`, `/prioritization.md`, `/opencode.json`, `/package.json` | project root | versioned |
| Architecture contract | `/architecture/*.md` | architecture owner | versioned, append-or-revise |
| Runtime contract | `/runtime/*.md`, `/runtime/*.json`, `/runtime/opencode/*.md` | runtime owner | versioned, append-or-revise |
| Template | `/templates/*.md` | templates owner | append-or-revise |
| Vulnerability skill template | `/templates/prompts/vulnerability-skill-template.md` | templates owner | append-or-revise |
| Skill | `/.opencode/skills/<skill-name>/SKILL.md` (+ optional scripts/ references/) | skill author | versioned |
| Command | `/.opencode/commands/<command-name>.md` | command author | versioned |
| Agent | `/.opencode/agents/<agent-name>.md` (rare) | agent author | versioned |
| Knowledge source | `/knowledge/<source-type>/<item>.md` | knowledge curator | immutable + provenance |
| Knowledge processed | `/knowledge/processed/<item>.md` | knowledge curator | append |
| Concept | `/concepts/<area>/<file>.md` | concept author | append-or-revise |
| Memory | `/memory/<file>.md`, `/memory/lessons/*.md` | memory owner | append-oriented, revisable, compactable, traceable history |
| Testing target state | `/testing/<root-domain>/...` | target owner (hunter) | versioned, append |
| Run report | `/testing/<root-domain>/runs/run-NNN/...` | run owner | immutable after run |
| Finding | `/testing/<root-domain>/findings/<finding-id>/...` | finding author | append |
| Learning engine | `/learning_engine/*` | learning owner | versioned, **deferred** |
| Automation | `/automation/*` | automation owner | versioned, **deferred** |
| Retrieval | `/retrieval/*` | retrieval owner | versioned, **deferred** |
| Script | `/scripts/*` | script owner | versioned, **deferred** |
| Wordlist | `/wordlists/*` | hunter | append |
| Log | `/logs/*` | system | append, rotation |
| CI workflow | `/.github/workflows/*` | CI owner | versioned |

> Files marked **deferred** exist in the tree as skeletons. Their **architectural boundaries are fixed now** (what each subsystem is and is not for); their **implementation contracts are deferred** until the architecture and runtime contracts are written and the relevant skills/commands that depend on them exist. So the tree defines the role, not the implementation.

## 4. Per-Type Contracts (lightweight, not bureaucratic)

Each file type inherits a small set of contracts. The metadata listed below is **the maximum**, not a starting point. A file may declare less if its type does not need it.

### 4.1 Architecture contract (`/architecture/*.md`)

```
Owner:     architecture owner
Source of truth: itself
Readers:   every subsystem
Writers:   architecture owner (or human-approved)
Lifecycle: append-or-revise; never silently rewrite
Required metadata block: status, scope, depends-on, depended-on-by
  Declared in a canonical blockquote at the top of the file
  (e.g. `> **Status:** ...`). This is the canonical metadata
  format for architecture contracts; it is NOT YAML frontmatter
  and is not subject to YAML parsing. See §8 for status values.
Allowed:   design rules, contracts, decision records, definitions
Forbidden: implementation details, payload dumps, run output
Cross-references: by relative path, by contract name
```

> The metadata block format is the **type-specific** metadata form for architecture contracts. Other file types (skills, commands, agents) use lightweight YAML frontmatter only where their type requires it. Per the core principles (§2), we do not impose a universal metadata schema on every file.

### 4.2 Runtime contract (`/runtime/*.md`, `*.json`, `opencode/*`)

```
Owner:     runtime owner
Source of truth:
  /runtime/registry.json          — canonical inventory of available tools
                                    (paths, capabilities, verification state)
  /runtime/tool-manifest.md       — operational tool-call policy
                                    (gating, invocation constraints)
  /runtime/model-routing.md       — operational model IDs, mappings, fallbacks
  /runtime/redaction.md           — redaction protocol
Readers:   skills, commands, scripts
Writers:   runtime owner
Lifecycle: versioned, append-or-revise
Allowed:   tool inventory (registry), tool-call policy (manifest),
           model IDs and mappings, MCP config, redaction protocol,
           loader behavior
Forbidden: scoring logic, methodology, run output
```

> The split with `architecture/model-routing.md` is intentional: that file holds design philosophy and constraints; `/runtime/model-routing.md` holds model IDs, mappings, and fallbacks. **No duplication of route tables.**

> The split between `/runtime/registry.json` (tool inventory) and `/runtime/tool-manifest.md` (tool-call policy) is intentional: the registry declares *what tools exist and in what state*; the manifest declares *how and when those tools may be invoked*. Neither may absorb the other's responsibility.

### 4.3 Template (`/templates/*.md`)

```
Owner:     templates owner
Source of truth: itself (the canonical template)
Readers:   skill authors, run authors, target owners
Writers:   templates owner
Lifecycle: append-or-revise
Required sections: (per template — defined inside the template body)
Allowed:   reusable structure with placeholders
Forbidden: target-specific data, run output, finding content
```

> A template is **copied/instantiated** into target state (e.g. `templates/ledger.md` → `testing/example.com/ledger.md`). After instantiation, the **target artifact is the source of truth** for that target — not the template. The template remains the canonical reusable form, but the target owns its own copy and may diverge as the hunt evolves. This is what "templates are REUSED, not imported" means in practice.

### 4.4 Skill (`/.opencode/skills/<skill-name>/SKILL.md`)

```
Owner:     skill author
Source of truth: SKILL.md
Readers:   commands, agents, the runtime
Writers:   skill author (human-reviewed)
Lifecycle: versioned; production skills may be deprecated, not silently changed
Required frontmatter: name, status, depends-on-skills, depends-on-templates, version
Optional: scripts/ subdir for deterministic helpers,
          references/ for bounded supporting references, derived material,
          and pointers to relevant contracts, concepts, or artifacts
Allowed:   methodology, decision trees, tool invocations, evidence requirements
Forbidden: large reusable payload dumps (those belong in /wordlists/, not in skills),
           target-specific state (that goes in /testing/<target>/),
           run output (that goes in /testing/<target>/runs/ or /logs/),
           architecture decisions (those go in /architecture/),
           test-specific payloads (those go in the relevant evidence/poc/request artifact),
           canonical source material (that lives in /knowledge/<source-type>/),
           full copies of concepts or processed extractions
```

> A skill is **methodology**, not a knowledge database. Deep knowledge lives in `/concepts/`, `/knowledge/processed/`, and `/retrieval/`. A skill references them; it does not embed them.

> `references/` holds bounded supporting references — derived material, pointers to contracts, concepts, or artifacts the skill relies on. It is **not** a place for canonical external source material. Sources live in `/knowledge/<source-type>/` with provenance. This distinction matches `agent-architecture-rules.md` §4.5 and `knowledge-flow.md` §7.2.

### 4.5 Command (`/.opencode/commands/<command-name>.md`)

```
Owner:     command author
Source of truth: itself
Readers:   the user (via OpenCode), agents
Writers:   command author
Lifecycle: versioned
Required frontmatter: name, trigger, inputs, outputs, depends-on-skills
Allowed:   workflow entry point, phase ordering, completion checks
Forbidden: methodology content (delegate to skills),
           target state mutation (delegate to skills)
```

### 4.6 Agent (`/.opencode/agents/<agent-name>.md`) — rare

```
Owner:     agent author
Source of truth: itself
Lifecycle: versioned
Required frontmatter: name, role, isolated-context (yes/no), owns-skills, model-routing-ref
Allowed:   isolated-context role description; explicit "few agents" justification
Forbidden: per-vulnerability agents; large system prompts; payload lists
```

> Agents are **roles**, not workers. They get their own context only when isolation is justified. Coordinator and Solver are **roles played by the main agent + isolated execution contexts**, not separate agent files.

### 4.7 Knowledge source (`/knowledge/<source-type>/<item>.md`)

```
Owner:     knowledge curator
Source of truth: itself (with provenance header)
Readers:   knowledge consumers, /knowledge/processed/ extractors
Writers:   knowledge curator
Lifecycle: immutable once committed; corrections are new files with `supersedes` link
Required: provenance (URL or source reference, retrieval date, type, tags)
Allowed:   raw source material (writeups, reports, blog posts, research, docs, tips)
Forbidden: edits to "improve" — preserve the source; commentary goes elsewhere
```

### 4.8 Knowledge processed (`/knowledge/processed/<item>.md`)

```
Owner:     knowledge curator
Source of truth: itself
Lifecycle: append; supersedes links to older versions
Required: source-provenance (links to /knowledge/<source-type>/...),
          extraction date, extractor (human/AI)
Allowed:   structured extraction — patterns, cases, techniques, prerequisites,
          validation, impact, false positives, provenance
Forbidden: full copies of source material (link instead)
```

### 4.9 Concept (`/concepts/<area>/<file>.md`)

```
Owner:     concept author
Source of truth: itself
Lifecycle: append-or-revise
Allowed:   synthesized reusable knowledge derived from multiple sources
Forbidden: single-source claims (those stay in /knowledge/processed/),
           per-target notes (those stay in /testing/<target>/)
```

> `/concepts/vulnerability-classes/<class>/` uses a fixed sub-schema (methodology, patterns, scenarios, edge-cases, false-positives, validation, sources). The canonical schema lives in `/templates/prompts/vulnerability-skill-template.md` (to be created at templates phase).

### 4.10 Memory (`/memory/*.md`, `/memory/lessons/*.md`)

```
Owner:     memory owner
Source of truth: itself
Lifecycle: append-oriented, revisable when needed, compactable.
          Historical changes remain traceable.
          External source material stays immutable; this is about
          our own memory and lessons, not /knowledge/.
          Memory maintenance / GC policy is defined by the
          designated maintenance mechanism, established during
          the scripts / implementation phase. This contract does
          not bind memory to any specific script name.
Allowed:   lessons from real hunts, FP patterns, methodology improvements,
          report lessons, system context (CONTEXT_LEDGER only)
Forbidden: target-specific data (lives in /testing/<target>/),
           source-derived knowledge (lives in /knowledge/),
           design decisions (live in /architecture/ or conversation)
```

> The three ledgers are **separate by design** and must never be merged:
> - `/templates/ledger.md` = reusable template
> - `/testing/<target>/ledger.md` = canonical target ledger
> - `/memory/CONTEXT_LEDGER.md` = persistent system/hunting context

### 4.11 Testing target state (`/testing/<root-domain>/...`)

```
Owner:     target owner (the hunter responsible for this target)
Source of truth: this directory subtree
Lifecycle: versioned, append; never modify past run reports (immutable history)
Allowed:   everything needed to resume a hunt — scope, identities, recon, app-map,
          endpoints, runs, OOB callbacks, regression state, hypotheses, findings
Forbidden: cross-target data (each target owns its own state),
           methodology (use skills/commands),
           source knowledge (use /knowledge/)
```

> The canonical target layout is defined in `Final Canonical Blueprint v3`. It is preserved exactly: `scope.md`, `agent-briefing.md`, `target-config.md`, `ledger.md`, `notes-funnel.md`, `coverage-map.md`, `identities/`, `research/`, `recon/`, `app-map/`, `endpoints/`, `urls/`, `subdomains/`, `runs/`, `oob/`, `regression/`, `requests/`, `responses/`, `screenshots/`, `scripts/`, `scans/`, `wordlists/`, `hypotheses/`, `evidence/`, `findings/`. Do not rename `coverage-map.md` to `coverage.md`; do not replace `notes-funnel.md` with a generic `notes/` directory.

### 4.12 Run report (`/testing/<root-domain>/runs/run-NNN/...`)

```
Owner:     run author
Source of truth: this run's directory
Lifecycle: IMMUTABLE after the run is declared complete
  (Run-specific lifecycle state: closed. This is not a generic
   file-status value and does not belong in §8's status vocabulary.)
Allowed:   run-report.md (tried / worked / failed / skipped), coverage-snapshot.md,
          supporting evidence, logs
Forbidden: edits after closure (corrections = new run or explicit addendum)
```

> A Run's `closed` state is a property of the Run's own lifecycle, not a status of the file type itself. A closed Run report is immutable; corrections are made via a new Run or an explicit addendum, not by editing the closed report.

### 4.13 Finding (`/testing/<root-domain>/findings/<finding-id>/...`)

```
Owner:     finding author
Source of truth: this finding's directory
Lifecycle: append; candidate → validated → reported → triaged; do not delete
Allowed:   candidate.md, validation-report.md, finding.md, finding.json,
          poc/, regression.md
Forbidden: destructive rewriting of the original reported state.
          The reported artifacts stay. Corrections, new evidence,
          retesting results, and regression outcomes are recorded as
          new artifacts/revisions inside the same finding directory.
```

### 4.14 Deferred types (learning_engine, automation, retrieval, scripts)

These exist in the tree as **skeletons** and are explicitly **not** part of the V1 implementation. They will be filled in only after the architecture and runtime contracts, templates, skills, and commands that depend on them are written. When implementation begins, the contracts above for runtime/template/etc. apply.

The split is:

- **Architectural boundary (fixed now):** what each subsystem is and is not for. The tree already names this:
  - `automation/` = monitoring pipeline (snapshot/diff/notify), not autonomous forever-hunting.
  - `retrieval/` = knowledge retrieval layer, single source of truth for search/metadata/index.
  - `learning_engine/` = learning from real hunts (findings, FPs, runs, miss analysis).
  - `scripts/` = execution helpers (preflight, registries, tests, update flow).
  No subsystem may quietly grow a new role at implementation time. The role is set here.
- **Implementation contract (deferred):** detailed type-level contracts (e.g. what fields a learning_engine/core/*.py module exposes, what the registry schema looks like, what audit_learning_engine.py actually checks). These are written when the relevant phase begins, after the architecture and runtime contracts they consume exist.

## 5. Cross-Reference Rules

```
- A file may reference another file by relative path. Path must remain stable.
- A file may reference a contract by name (e.g. "validation-model.md §4").
- A file must NEVER duplicate content owned by another file. Use reference.
- A skill must NEVER embed a reusable payload list. Reusable payload collections live in /wordlists/; large reusable payload dumps must not be embedded in Skills or Commands.
- A skill must NEVER embed source material. Sources go in /knowledge/.
- A target subtree must NEVER reference another target's state.
- The three ledgers must NEVER be merged or duplicated.
- Frontmatter (where used) must be plain YAML, no exotic types, no code execution.
```

## 6. Path Semantics

```
/                       = project root; only top-level config files live here.
/.opencode/             = OpenCode operational layer (skills, agents, commands).
                         Other subsystems must not live here.
/architecture/          = contracts and design rules. Source of truth for design.
/runtime/               = operational contracts. Source of truth for ops.
/templates/             = reusable structures, no target data.
/knowledge/             = external sources + processed extraction. Provenance required.
/concepts/              = synthesized knowledge from multiple sources.
/memory/                = lessons from real hunts; system context. No target data.
/testing/<root>/        = per-target state. Each target owns its subtree.
/learning_engine/       = deferred to build order phase 10.
/automation/            = deferred to build order phase 10.
/retrieval/             = deferred to build order phase 10.
/scripts/               = deferred to build order phase 10.
/wordlists/, /logs/     = append-only, possibly rotated.
```

## 7. Reuse vs Duplication Rules

```
- If two files contain the same authoritative content, one of them is wrong
  UNLESS the duplication is explicitly defined as an instantiated copy or
  derived artifact (e.g. a template copy in /testing/<target>/). Reference
  the other; do not silently copy.
- Templates are REUSED (copied/instantiated per target with placeholders filled); they are not imported.
- After instantiation, the target artifact (e.g. `testing/<root>/ledger.md`) becomes the target's source of truth. The template stays the canonical reusable form but no longer "drives" the live artifact.
- Architecture contracts are REFERENCED (one source of truth); they are not copied.
- Skills may reference /concepts/ and /knowledge/processed/ by path; they do not embed.
- Reusable payload collections live in /wordlists/; they are not duplicated.
- Large reusable payload dumps must not be embedded in Skills or Commands.
- Test-specific payloads may exist inside the relevant evidence/poc/request artifact
  in /testing/<target>/findings/ or /testing/<target>/evidence/.
```

## 8. Lifecycle and Status

Some file types carry a `status` field. The values are:

```
placeholder  = file exists structurally but holds no real content yet
draft        = first real write, under review
review       = ready for human review
production   = approved and in use
deprecated   = do not extend the artifact; reference its replacement where applicable
superseded   = a newer artifact formally replaces the older one; the older
               artifact remains immutable, and the newer artifact identifies
               the older one through the `supersedes:` link
```

Not every file needs a status. The minimum set: architecture contracts, runtime contracts, skills, commands, agents, templates.

The actual lifecycle of each storage type is:

```
Knowledge source  → immutable
Target state      → mutable working state (scope, identities, recon,
                    app-map, coverage-map, target-config, etc.
                    may be revised as the hunt evolves)
Closed run report → immutable (corrections = new run or explicit addendum)
Reported finding  → original reported state preserved; new evidence,
                    corrections, retests, regression outcomes are
                    recorded as new artifacts/revisions in the same
                    finding directory (per §4.13)
Memory            → append-oriented (revisable, compactable, traceable
                    history). External source material stays immutable.
```

Status is rarely needed for any of these storage types because the lifecycle is implicit in the directory or filename. Status fields are reserved for files that go through a draft → review → production progression.

> A **Run's `closed` state** (§4.12) is a property of the Run's own lifecycle and is NOT one of the generic `status` values above. A closed Run is immutable; corrections follow the new-run or addendum rule.

## 9. Creation and Deletion Rules

```
- A new file is created when a new file type is needed, OR when a new instance of an
  existing type is needed (e.g. a new target gets a new /testing/<root>/ subtree).
- A new file MUST match its type's contract above.
- A new file MUST NOT duplicate an existing file.

- Deleting a status-bearing, managed artifact (a type that uses the §8 `status`
  field) requires: status = deprecated/superseded AND no live references.
  The retirement is recorded through the artifact's own type-appropriate
  change mechanism. The record location must match the artifact type; there
  is no single universal deletion log.

- Immutable-lifecycle artifacts (committed knowledge sources, closed Run
  reports, original reported finding artifacts) are not deleted through the
  generic rule above. Their corrections and retirements follow their own
  type contracts — for example a newer file that carries a `supersedes:`
  link to the older file.

- Append-oriented artifacts (Memory, Wordlists) follow their own type
  contracts for maintenance. Memory is revisable and compactable per §4.10,
  with its maintenance/GC mechanism defined by the designated mechanism at
  the scripts/implementation phase. Wordlists follow append semantics. The
  generic deletion rule above does not apply to these types.

- Rotation-managed storage (e.g. /logs/) follows its own rotation lifecycle,
  not the generic deletion rule above.

- Renaming a status-bearing, managed artifact is a deletion + creation.
  Update all references. Renaming does not apply to immutable-lifecycle
  artifacts; those require a newer artifact with a `supersedes:` link to
  the older one.

- If the correct type-specific change record for a retirement is not
  specified by the relevant type contract, report the limitation rather
  than inventing a universal deletion log.
```

## 10. What This Contract Intentionally Does NOT Define

```
- The internal structure of a finding (lives in /templates/finding.md).
- The internal structure of a run report (lives in /templates/run-report.md).
- The internal structure of a skill (lives in /templates/prompts/vulnerability-skill-template.md,
  plus type-specific contracts in /architecture/agent-architecture-rules.md).
- The 7-question validation gate (lives in /architecture/validation-model.md).
- Model routing decisions (lives in /architecture/model-routing.md for policy,
  /runtime/model-routing.md for ops).
- Tool gating rules (lives in /runtime/tool-manifest.md).
- Knowledge flow and extraction (lives in /architecture/knowledge-flow.md).
- Learning flow (lives in /architecture/learning-flow.md).
- Agent security (lives in /architecture/agent-security.md).
- AGENTS.md content (lives in /AGENTS.md, written after this and after
  /architecture/agent-architecture-rules.md).
```

These are explicitly out of scope here to keep this file small and reusable.
