# learning-flow.md

> **Status:** review v1.1
> **Scope:** Defines how Buggy learns from real hunting outcomes — how findings, false positives, missed hypotheses, failed tests, regression outcomes, and report outcomes flow into memory, lessons, methodology improvements, and the (deferred) learning engine.
> **Authority:** Architecture contract. Refines `architecture/file-contracts.md` §4.10 (memory) and §3 / §4.14 (deferred subsystems) for the learning / memory pipeline.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-architecture-rules.md`, `architecture/validation-model.md`, `architecture/knowledge-flow.md`
> **Depended on by:** `/memory/**/*.md`, `learning_engine/**` (when implemented), the deferred memory maintenance mechanism, `.opencode/skills/report-writer/SKILL.md` (report lessons), `.opencode/skills/regression/SKILL.md` (regression outcomes), `.opencode/skills/validator/SKILL.md` (FP / validation lessons), `/AGENTS.md`

---

## 1. Purpose

This contract defines:

- the learning pipeline — how real-hunt outcomes enter memory
- the structure of `/memory/` and the role of each memory file
- the three ledgers and their separation (per `file-contracts.md` §4.10)
- the architectural boundary of the (deferred) Learning Engine
- how Run Comparison and Miss Analysis work at the architecture level
- how regression outcomes flow into memory
- how memory improves methodology over time
- the boundary between this contract and `architecture/knowledge-flow.md`

This contract does NOT define:

- the per-type memory contract (lives in `file-contracts.md` §4.10)
- the per-type finding / run / regression contract (lives in `file-contracts.md` §4.11 / §4.12 / §4.13)
- the Learning Engine implementation (deferred to build order phase 10)
- the notes funnel structure for a target (lives in `architecture/validation-model.md` §3.2)
- the Knowledge Flow layers (lives in `architecture/knowledge-flow.md`)

If a downstream file needs a rule established here, it references this contract rather than duplicating it.

## 2. The Learning Pipeline

> Source: Buggy Master Blueprint §23 (canonical integration, not rewrite).

Buggy learns from real hunting outcomes, not from generic external knowledge. The pipeline is:

```
┌──────────────────────────────────────────────────────────────┐
│  REAL HUNTING OUTCOMES                                       │
│                                                              │
│  - Validated findings        (from validation-model.md)      │
│  - Rejected candidates      (from validation-model.md)      │
│  - Missed hypotheses         (from run comparison)           │
│  - Failed tests              (from run reports)              │
│  - Regression outcomes       (from regression skill)         │
│  - Report outcomes           (from report-writer + triage)   │
│  - Run comparison deltas     (from compare-runs)             │
└─────────────────────┬────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│  INGESTION                                                   │
│  learning_engine/ingestion/{finding,triage}.py (deferred)   │
│                                                              │
│  - normalizes the outcome                                     │
│  - preserves provenance                                      │
│  - attaches to target / run / finding context                │
└─────────────────────┬────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│  LESSONS                                                     │
│  /memory/lessons/<item>.md                                   │
│                                                              │
│  - reusable lessons (independent of any single target)      │
│  - linked to the originating finding / run / report          │
└─────────────────────┬────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│  MEMORY                                                      │
│  /memory/CONTEXT_LEDGER.md                                   │
│  /memory/methodology.md                                      │
│  /memory/patterns.md                                         │
│  /memory/FALSE_POSITIVE_DB.md                                │
│  /memory/report-lessons.md                                   │
│                                                              │
│  - persistent system / hunting context                       │
│  - the actual "what Buggy has learned"                       │
└─────────────────────┬────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│  METHODOLOGY IMPROVEMENT                                     │
│                                                              │
│  - a Skill is updated                                         │
│  - a Concept is added or revised                              │
│  - a heuristic is added to /concepts/heuristics/             │
│  - a gate / threshold is tuned                                │
│  - a workflow command is added or revised                     │
└──────────────────────────────────────────────────────────────┘
```

> Source: Buggy Master Blueprint §17 (canonical integration, not rewrite).

This pipeline is the **only** path by which learning-derived memory is updated, and the **only** path by which methodology is changed from real-hunt outcomes.

Knowledge Flow may create or revise Concepts from external-derived knowledge according to its own contract. Learning Flow owns changes that are triggered by real-hunt outcomes.

## 3. The Three Ledgers (separation)

> Sources: Buggy Master Blueprint §24 + `architecture/file-contracts.md` §4.10 (canonical integration, not rewrite).

The three ledgers are **separate by design** and must never be merged:

```
┌────────────────────────┬─────────────────────────────────────┐
│  Reusable template     │  /templates/ledger.md               │
│  (canonical form)      │  Owner: templates owner             │
│                        │  Lifecycle: append-or-revise        │
│                        │  Used to instantiate target ledgers │
├────────────────────────┼─────────────────────────────────────┤
│  Target-specific       │  /testing/<target>/ledger.md        │
│  (per-hunt state)      │  Owner: target owner (hunter)       │
│                        │  Lifecycle: append                  │
│                        │  Mutable working state              │
├────────────────────────┼─────────────────────────────────────┤
│  Persistent system /   │  /memory/CONTEXT_LEDGER.md          │
│  hunting context       │  Owner: memory owner                │
│  (cross-hunt memory)   │  Lifecycle: append-oriented,        │
│                        │    revisable, compactable           │
└────────────────────────┴─────────────────────────────────────┘
```

> Source: Buggy Master Blueprint §24 (canonical integration, not rewrite).

They have **different ownership, different scope, and different lifecycle**. They are not interchangeable. The full lifecycle and forbidden contents of each are in `file-contracts.md` §4.10 — this contract only establishes the **separation** and the **role** of each.

## 4. Memory Structure

> Source: Buggy Master Blueprint §23 (canonical integration, not rewrite).

`/memory/` contains the following canonical files. **No other files may be added inside `/memory/`** without an explicit architectural decision.

```
memory/
├── CONTEXT_LEDGER.md       # persistent system / hunting context
├── FALSE_POSITIVE_DB.md    # actual FP patterns observed in real hunts
├── patterns.md             # patterns validated through real experience
├── methodology.md          # process improvements from real hunts
├── report-lessons.md       # accepted / rejected / weak reports
└── lessons/                # reusable learned lessons (per-lesson file)
```

> The per-type contract for each memory file is in `file-contracts.md` §4.10. This contract defines the **role** of each.

### 4.1 Role of Each Memory File

> Source: Buggy Master Blueprint §23 (canonical integration, not rewrite).

| File | Role | Source of content |
|---|---|---|
| `CONTEXT_LEDGER.md` | The persistent cross-hunt context. What the hunter / Buggy knows about its own state. | Any real-hunt outcome, system event, or operator input. |
| `FALSE_POSITIVE_DB.md` | The actual FP patterns that have bitten us. | Rejected candidates (per `validation-model.md` §3.2) that were once believed to be findings. |
| `patterns.md` | Patterns validated through experience. | Multiple findings or rejections that confirm a pattern. |
| `methodology.md` | Process improvements. | After-action notes from completed hunts and runs. |
| `report-lessons.md` | Lessons from the report-writing + triage loop. | Accepted / rejected / weak reports. |
| `lessons/` | Reusable per-lesson files. | One lesson per file, with provenance. |

### 4.2 What Memory Is NOT

> Source: Buggy Master Blueprint §23 / §44 (canonical integration, not rewrite).

Memory is **not**:

- a second knowledge repository (that is `/knowledge/` + `/concepts/`)
- a target-specific store (that is `/testing/<target>/`)
- a dump of raw transcripts
- a place for design decisions (those live in `/architecture/` or in conversation)
- a place for source-derived material (that is `/knowledge/`)

> Cross-system boundary with Knowledge Flow: see `architecture/knowledge-flow.md` §9. The two systems may **reference** each other as a pointer, not a transfer.

## 5. From Outcome to Lesson — The Ingestion Contract

> Source: Buggy Master Blueprint §17 (canonical integration, not rewrite).

### 5.1 What Triggers Ingestion

A real-hunt outcome becomes a memory lesson when it meets **all** of the following:

```
- it is a validated finding, OR a rejected candidate (per validation-model.md),
  OR a missed hypothesis from run comparison,
  OR a failed test from a run report,
  OR a regression outcome,
  OR a report outcome (accepted, rejected, weak),
  OR a run comparison delta that reveals a missed or changed pattern.
- it carries enough provenance to be reused: target, run id, finding id (if any),
  date, what was tried, what the result was, why.
- it generalizes beyond the originating target (a per-target event alone is not
  a lesson; the lesson is the pattern, not the instance).
```

### 5.2 What Ingestion Produces

Ingestion produces:

- a per-lesson file at `/memory/lessons/<item>.md` (when a reusable lesson is extracted)
- an update to one of the canonical memory files (when the lesson updates a known pattern / methodology / FP / report pattern)
- **never** a copy of the originating finding / run / report (those stay in `/testing/<target>/`)

### 5.3 What Ingestion Does NOT Do

Ingestion does NOT:

- rewrite or destroy the originating finding / run / report (per `file-contracts.md` §4.13)
- transfer ownership of the originating content to memory
- create a duplicate of the originating content
- create memory entries that are not rooted in a real-hunt outcome

> The ingestion scripts (`learning_engine/ingestion/finding.py`, `triage.py`) are **deferred** to build order phase 10. The architectural contract above is what they must conform to.

## 6. Run Comparison (architectural boundary)

> Sources: Buggy Master Blueprint §27 + Architecture Builder (compare-runs) (canonical integration, not rewrite).

### 6.1 Why Run Comparison Exists

LLM runs are not deterministic. Two runs over the same target with the same prompt may:

- discover different endpoints
- rank findings differently
- miss different hypotheses
- report different severities

> Source: Buggy Master Blueprint §27 (canonical integration, not rewrite).

Run comparison exists to make these differences **visible** rather than hidden.

### 6.2 What Run Comparison Produces

Run comparison produces:

- a per-target comparison record at `/testing/<target>/runs/comparison.md`
- miss analysis at `/testing/<target>/runs/<run-id>/miss-analysis.md`
- (optionally) a memory lesson when a missed hypothesis or coverage gap generalizes across targets

### 6.3 What Run Comparison Does NOT Do

Run comparison does NOT:

- re-run a past run (it analyzes existing run reports, not re-execution)
- modify closed run reports (per `file-contracts.md` §4.12)
- produce a "consensus" finding from multiple runs (the validation model is the gate, not voting)

> The implementation scripts (`learning_engine/run_comparison/compare.py`, `miss_analysis.py`) are **deferred** to build order phase 10.

## 7. Miss Analysis (architectural boundary)

> Sources: Buggy Master Blueprint §29 + Architecture Builder §9.3 (canonical integration, not rewrite).

### 7.1 What Miss Analysis Is

Miss analysis is the explicit practice of looking at what a run **did not find** and asking why. The possible answers form a taxonomy:

```
- the run did not test the right surface
  (coverage gap → update coverage-map.md)
- the run tested the right surface but with the wrong hypothesis
  (methodology gap → update methodology.md, possibly a concept)
- the run tested the right surface with the right hypothesis, but
  the validator rejected the candidate
  (FP gap → update FALSE_POSITIVE_DB.md; do not update the validator)
- the run never reached this surface at all
  (coverage / priority gap → update coverage-map.md or prioritization.md)
- the program scope itself changed externally
  (scope.md is updated only from an actual scope change,
  not from miss analysis)
- the run missed it for an unknown reason
  (capture the unknown; do not invent a reason)
```

> Source: Synthesis from Architecture Builder §9.3 + Buggy Master Blueprint §29 (canonical integration, not rewrite).

### 7.2 The "Do Not Invent a Reason" Rule

> Source: Buggy Master Blueprint §17 (canonical integration, not rewrite).

LLM confidence is not proof. When a miss has no clear cause, the architecture requires recording the **unknown** rather than inventing a cause. Inventing a cause corrupts the miss analysis and pollutes memory.

## 8. Regression Outcomes (boundary with `regression` skill)

> Source: Buggy Master Blueprint §28 (canonical integration, not rewrite).

### 8.1 What Counts as a Regression Outcome

A regression outcome is recorded when:

- a previously fixed finding is observed to be reproducible again
- a previously absent pattern appears in a new run
- a previously closed-no-finding surface becomes a finding in a new run

### 8.2 Where Regression Outcomes Land

- The regression finding (if any) lives at `/testing/<target>/findings/<finding-id>/` per `file-contracts.md` §4.13 (a new candidate.md, finding.md, regression.md).
- The original reported state is preserved per `file-contracts.md` §4.13.
- If the regression reveals a generalizable lesson (e.g. "Bypass X always re-opens finding Y"), a memory lesson is created at `/memory/lessons/`.

### 8.3 The Regression Bot (deferred)

> Source: Synthesis from Buggy Master Blueprint §28 + Architecture Builder (canonical integration, not rewrite).

A periodic check that takes known fixes, attempts to break them, and records outcomes.

- **Architectural boundary:** fixed (concept + boundary per `validation-model.md` §11).
- **Implementation:** **deferred** to build order phase 10 (lives under `automation/` and `learning_engine/`, not invented here).

## 9. False-Positive Learning (the `FALSE_POSITIVE_DB.md`)

> Source: Buggy Master Blueprint §16 / §23 (canonical integration, not rewrite).

### 9.1 The Role of the FP DB

> Source: Buggy Master Blueprint §16 (canonical integration, not rewrite).

The FP DB exists so the same false positive does not get re-investigated forever. FPs are an asset, not a waste product.

### 9.2 FP DB Format (working contract)

> Source: Synthesis from Buggy Master Blueprint §16 + `file-contracts.md` §4.10 (canonical integration, not rewrite).

Each FP entry must record at minimum:

```
- the candidate that was rejected (with link to its candidate.md if it exists)
- the FP pattern (what made it look real but it wasn't)
- the rejection reason (which gate caught it)
- the source(s) of the lesson (link to the originating finding directory
  or run report)
- the date observed
- the target (if it generalized beyond the target)
```

> See GAP-LF-01 (the exact FP DB schema and query patterns are an OPEN TODO; the fields above are the working minimum).

## 10. The Whac-A-Mole / Dual-Run / Self-Improving Loop

> Sources: Buggy Master Blueprint §17 (Learning Loop) + Sources Research Foundation (canonical integration, not rewrite).

### 10.1 The Whac-A-Mole Principle

> Source: Synthesis (Rules Producer §17 + Sources Research Foundation).

Every AI mistake is **a lesson candidate** — but not every AI mistake is a lesson. The distinction is the **generalization gate** (per §5.1: a lesson must generalize beyond the originating target).

Illustrative categories:

- a learning-relevant false positive → an FP-DB entry
- a missed hypothesis that generalizes → a run-comparison + miss-analysis entry
- a learning-relevant failed test → a methodology.md entry
- a regression that generalizes → a regression.md + (optionally) a memory lesson
- an inflated report that generalizes → a report-lessons.md entry
- an under-rated report that generalizes → a report-lessons.md entry

The architecture requires that every **learning-relevant or repeatable** error produces a memory artifact or lesson candidate. One-off, target-specific errors remain in the target / run artifacts unless they produce a reusable lesson or a system-context update. Errors that don't produce memory entries (where they should) are the errors that repeat.

### 10.2 The Dual-Run Improvement Loop

> Source: Synthesis (Sources Research Foundation + Buggy Master Blueprint §17).

When a methodology is not yet stable, run it twice in parallel:

- Run A: the current methodology (the hardcoded path)
- Run B: free exploration (the same objective, no prescribed path)

Compare the two:

- B found something A missed → extract the pattern, update the skill
- A found something B missed → extract the pattern, update the skill
- Both found the same thing → convergence signal; not proof of stability
- They diverged → investigate the divergence before updating either

The comparison is done by run comparison (§6). The methodology update is done by the same Skill / Concept update path as any other lesson.

### 10.3 Self-Improving Methodology

> Source: Synthesis (Sources Research Foundation + Rules Producer §17).

A Skill, Concept, or heuristic can be updated when:

- a memory lesson records a pattern that the current Skill / Concept fails to capture
- a Whac-A-Mole cycle identifies a repeatable error
- a Dual-Run comparison reveals a divergence in stable methodology
- a known-fix regression surfaces a new bypass

> The Skill / Concept update itself is governed by `architecture/agent-architecture-rules.md` and `architecture/knowledge-flow.md` §5. This contract establishes the **trigger** for updates, not the update mechanism.

## 11. Memory GC Policy

> Source: `architecture/file-contracts.md` §4.10 (referenced, not duplicated) + Buggy Master Blueprint §23 (canonical integration, not rewrite).

### 11.1 Lifecycle Class

Memory is:

- append-oriented (new lessons and new pattern entries are added)
- revisable when needed (a lesson can be edited, an FP pattern can be refined)
- compactable (long memory files can be summarized; historical changes remain traceable)

This is established in `file-contracts.md` §4.10.

### 11.2 Where the Policy Lives

The maintenance mechanism (compaction, summarization, retention) is **deferred** to build order phase 10. Its implementation boundary and owning runtime mechanism are not defined yet.

This contract establishes the **lifecycle class** (append-oriented, revisable, compactable) and the **architectural boundary** (memory has a GC policy). The implementation of that policy is not in this contract and is intentionally not bound to a specific script name.

## 12. The Boundary with Knowledge Flow

> Source: `architecture/knowledge-flow.md` §9 (referenced, not duplicated).

The boundary is:

- **Knowledge** answers "What is known from external material?"
- **Memory** answers "What did Buggy and the hunter learn from real hunting?"

The two systems may **reference** each other as a pointer, not a transfer. A Concept may cite a memory lesson as "validated-in-practice"; a memory entry may cite a Concept as "informed by external pattern". Neither is moved or reclassified.

The full rules are in `architecture/knowledge-flow.md` §9.

## 13. Cross-References

### 13.1 Files That Read This Contract

- `/AGENTS.md` (steering layer that points to this contract)
- `/memory/CONTEXT_LEDGER.md`, `FALSE_POSITIVE_DB.md`, `patterns.md`, `methodology.md`, `report-lessons.md` (each is governed by this contract)
- `/memory/lessons/` (each per-lesson file is governed by this contract)
- `.opencode/skills/validator/SKILL.md` (FP outcomes feed memory)
- `.opencode/skills/report-writer/SKILL.md` (report outcomes feed memory)
- `.opencode/skills/regression/SKILL.md` (regression outcomes feed memory)
- `learning_engine/ingestion/finding.py`, `triage.py` (when implemented; must conform to this contract)
- `learning_engine/run_comparison/compare.py`, `miss_analysis.py` (when implemented; must conform to this contract)
- the deferred memory maintenance mechanism (when implemented; must conform to this contract)

### 13.2 Files This Contract Reads

- `architecture/file-contracts.md` (per-type contracts for memory, target state, finding, run, regression)
- `architecture/agent-architecture-rules.md` (skill / concept update rules)
- `architecture/validation-model.md` (validation pipeline produces the inputs)
- `architecture/knowledge-flow.md` (cross-system boundary)

### 13.3 Files This Contract Does NOT Cover (Linked Out)

- `architecture/agent-security.md` — threat model for agents (covers a different concern)
- `architecture/severity-model.md` (if authored) — finding severity scoring
- `runtime/registry.json` — operational registry of memory scripts
- `retrieval/**` (deferred) — when implemented, may use the memory indexes

## 14. ⚠️ GAP NOTES

The following items are **OPEN TODOs** in the current architecture. They are intentionally not resolved here because the v6 source material did not provide enough specification to invent a contract without inventing architecture. Each gap is recorded with what is missing and where it should land when the missing specification becomes available.

### GAP-LF-01: False Positive DB exact schema

- **What's missing:** the precise fields, query patterns, retention policy, and provenance structure for the FP DB.
- **Why it's a gap:** sources support the architectural need for an FP knowledge database, but the schema is not specified.
- **Where it should land:** this contract (§9.2) once the schema is finalized; or a dedicated `templates/false-positive.md` (new template).
- **Status:** OPEN TODO — the working minimum in §9.2 is a starting point, not a final schema.

### GAP-LF-02: Learning Engine implementation details

- **What's missing:** the exact fields of `learning_engine/core/*.py` modules, the storage schema (`learning_engine/memory/learning.db`), and the audit script's checks.
- **Why it's a gap:** the architectural boundary is fixed (finding ingestion, FP ingestion, run comparison, miss analysis, pattern extraction, lesson storage). The implementation is deferred to build order phase 10.
- **Where it should land:** this contract (§5.3 / §6.3) or a dedicated `runtime/learning-engine.md` once implementation begins.
- **Status:** OPEN TODO — do not invent the implementation here.

### GAP-LF-03: Run Comparison scoring / equivalence policy

- **What's missing:** the policy for declaring two runs "equivalent" or "divergent". What counts as a meaningful difference? How is coverage delta measured?
- **Why it's a gap:** the principle is established (run comparison reveals differences). The exact policy is not.
- **Where it should land:** this contract (§6) once the policy is finalized.
- **Status:** OPEN TODO — do not invent a scoring policy here.

### GAP-LF-04: Miss analysis taxonomy (the "why missed" categories)

- **What's missing:** whether the working taxonomy in §7.1 is exhaustive. Are there other "why missed" categories? Should the categories be formal status fields?
- **Why it's a gap:** sources support the practice of miss analysis but did not give an exhaustive taxonomy.
- **Where it should land:** this contract (§7) once the taxonomy is finalized.
- **Status:** OPEN TODO — the categories in §7.1 are a working starting point, not a closed taxonomy.

### GAP-LF-05: When a memory lesson becomes a Concept

- **What's missing:** the precise rule for promoting a reusable memory lesson derived from real-hunt outcomes to a Concept. Memory is persistent cross-hunt learning, not a per-target store; Concepts are synthesized reusable knowledge. When is a pattern "generalized enough" for promotion?
- **Why it's a gap:** the boundary is established (Knowledge vs Memory in `knowledge-flow.md` §9), but the promotion rule is not.
- **Where it should land:** this contract (§5) and `architecture/knowledge-flow.md` §10.
- **Status:** OPEN TODO — do not invent a promotion rule here.

### GAP-LF-06: Memory ↔ Skill update protocol

- **What's missing:** the exact protocol for updating a Skill / Concept from a memory lesson. Which skills can be updated automatically (with human review)? Which require explicit human action?
- **Why it's a gap:** the trigger is established (memory lesson → skill update). The protocol (who, when, with what review) is not.
- **Where it should land:** this contract (§10.3) and `architecture/agent-architecture-rules.md` §4.
- **Status:** OPEN TODO — do not invent a protocol here.

### GAP-LF-07: Pattern promotion threshold

- **What's missing:** how many observations make a pattern (1? 2? a cohort?). When does a "potential pattern" become a "validated pattern" in `patterns.md`?
- **Why it's a gap:** the file exists but the promotion rule is not.
- **Where it should land:** this contract (§4 / §10).
- **Status:** OPEN TODO — do not invent a threshold here.

### GAP-LF-08: Severity model

- **What's missing:** the canonical severity model used to score a finding. This affects report lessons and prioritization.
- **Why it's a gap:** sources emphasized "severity ≠ vulnerability type" but did not pick a scoring system. (Same gap as GAP-VM-10 in `validation-model.md`.)
- **Where it should land:** this contract or a dedicated `architecture/severity-model.md`.
- **Status:** OPEN TODO — do not invent a severity model here.

### GAP-LF-09: Whac-A-Mole taxonomy

- **What's missing:** an exhaustive list of error categories that must produce a memory entry. The list in §10.1 is illustrative, not closed.
- **Why it's a gap:** the principle is established (every error produces memory). The category list is not.
- **Where it should land:** this contract (§10.1).
- **Status:** OPEN TODO — the categories in §10.1 are a working starting point, not a closed list.

### GAP-LF-10: Dual-Run convergence rule

- **What's missing:** when two parallel runs converge (find the same things), when is that signal "methodology is stable" vs "both runs missed the same thing"?
- **Why it's a gap:** the principle is established (dual-run improvement). The convergence rule is not.
- **Where it should land:** this contract (§10.2) once the rule is finalized.
- **Status:** OPEN TODO — do not invent a rule here.

---

These gaps are recorded so that future work does not silently invent contracts where the architecture has not yet been specified. Each gap names what is missing, why it is missing, where the contract belongs, and the rule that the answer must follow.
