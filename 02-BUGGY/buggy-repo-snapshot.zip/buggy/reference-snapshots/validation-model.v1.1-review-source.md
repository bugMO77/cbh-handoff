# validation-model.md

> **Status:** review v1.1
> **Scope:** Defines how Buggy moves a suspicious observation from "could be a finding" to "confirmed finding worth reporting". Establishes the validation pipeline, the 7-question gate, the False Positive / Evidence / Proof gates, the Validator model, and the Exploit Gate.
> **Authority:** Architecture contract. Refines `architecture/file-contracts.md` for validation, finding, and evidence semantics.
> **Depends on:** `architecture/file-contracts.md`, `architecture/agent-architecture-rules.md`
> **Depended on by:** `.opencode/skills/validator/SKILL.md`, `.opencode/skills/report-writer/SKILL.md`, `.opencode/skills/regression/SKILL.md`, `.opencode/skills/xss/SKILL.md`, `.opencode/skills/access-control/SKILL.md`, `templates/finding.md`, `templates/hypothesis.md`, `templates/notes-funnel.md`, `templates/coverage-map.md`, `/AGENTS.md`, `architecture/agent-security.md`, `architecture/learning-flow.md`, `runtime/tool-manifest.md`

---

## 1. Purpose

This contract defines:

- the validation pipeline that a candidate must pass before becoming a finding
- the 7-question gate that every candidate must answer
- the False Positive Gate
- the Evidence Standard
- the Proof Gate
- the Validator model
- the Exploit Gate
- how regression is handled

This contract does NOT define:

- the internal structure of a finding directory (lives in `templates/finding.md` per `file-contracts.md` §4.13)
- the internal structure of a hypothesis (lives in `templates/hypothesis.md`)
- the validator skill's implementation details (lives in `.opencode/skills/validator/SKILL.md`)
- tool gating rules (lives in `runtime/tool-manifest.md`)
- scope enforcement at network/proxy level (lives in `runtime/opencode/`)

If a downstream file needs a rule established here, it references this contract rather than duplicating it.

## 2. Core Philosophy

> Source: Buggy Master Blueprint §3 (canonical integration, not rewrite).

Buggy enforces three non-negotiable separations:

```
AI may:
  - generate hypotheses
  - identify suspicious behavior
  - suggest attack paths
  - prioritize possibilities
  - interpret observations
  - reason over existing evidence

AI output alone does not establish a vulnerability.

Runtime produces evidence.
Security claims must ultimately be grounded in runtime evidence.

The hunter remains responsible for deciding:
  - whether behavior is actually vulnerable
  - whether the target is in scope
  - whether a security boundary was crossed
  - whether evidence is sufficient
  - whether an alternative explanation exists
  - whether the issue is reportable
  - how the final report should be interpreted
```

The three separations are not stylistic. They are how Buggy prevents AI hallucination from becoming a reported finding.

## 3. Validation Pipeline

> Source: Buggy Master Blueprint §13 (canonical integration, not rewrite) + §15.

### 3.1 Pipeline Overview

The intended validation lifecycle is:

```
Research
   ▼
Scope Verification
   ▼
Identity Setup
   ▼
Surface Discovery
   ▼
Function Mapping
   ▼
Hypothesis Generation
   ▼
Targeted Testing
   ▼
Runtime Validation
   ▼
Evidence Collection
   ▼
Triage
   ▼
Reporting
   ▼
Regression
   ▼
Learning
```

### 3.2 Candidate → Finding Flow

Within the broader lifecycle, the validation sub-pipeline for a single candidate is:

```
Observation
   ↓
Hypothesis (artifact: templates/hypothesis.md)
   ↓
Proof Gate (runtime decides — see §7)
   ↓
False Positive Gate (see §5)
   ↓
Evidence Standard (see §6)
   ↓
Validator (see §8)
   ↓
Exploit Gate (see §9)
   ↓
Human review
   ↓
   ├── Confirmed finding → Report
   │
   └── Rejected candidate → stops the reporting path; the rejected
       candidate may continue through the learning / FP-knowledge
       flow (see §5 and `architecture/learning-flow.md`)
```

> **Note:** the canonical finding lifecycle per `architecture/file-contracts.md` §4.13 remains `candidate → validated → reported → triaged`. A **rejected candidate** is NOT a finding state — it is a candidate that did not pass validation. Only a **confirmed finding** continues into reporting.

> Source: Buggy Master Blueprint §15 (canonical integration, not rewrite).

The following are **separate concerns** within this sub-pipeline:

- **False Positive Gate**
- **Evidence Gate**
- **Validator**
- **Human review**
- **Reportability assessment**

They are not folded into one "validation check". Each gate has its own purpose; conflating them is a known cause of false positives.

> **Note on sequencing:** the diagram above shows a **conceptual dependency flow**, not a mandatory execution order. It is intentionally not enforced as strict sequencing. Whether gates run sequentially or in parallel is left to the validator skill and is tracked as **GAP-VM-08** in §14.

### 3.3 State-Based Completion

> Source: Buggy Master Blueprint §13 / §37 (canonical integration, not rewrite).

Completion is state-based. It is not "the model said it is finished."

The rule is:

> No candidate may be **promoted past** a gate whose required artifact is missing.

This rule does **not** require that gates execute in a strict sequence. It only prevents promotion past an unresolved gate. The order in which gates are tested, and whether they run sequentially or in parallel, is governed by the validator skill (and is itself an OPEN TODO per GAP-VM-08).

## 4. The 7-Question Gate

> Source: Buggy Master Blueprint §15 (canonical integration, not rewrite).

Every candidate must answer each of the seven question concepts below before it can be called a finding.

> **Note on phrasing:** the seven **question concepts** are canonical (taken from Master Blueprint §15). The wording shown below is a **working / operational phrasing** maintained as a starting point; it is not the literal source wording. The final literal phrasing of each question is tracked as **GAP-VM-01** in §14.

The seven concepts are:

```
1. SCOPE
   Is the target/action in scope?

2. REPRODUCIBILITY
   Is the behavior reproducible?

3. AUTHORIZATION CONTEXT
   Is the authorization / session context correct
   (i.e. did the test use real, valid credentials/identity for the claim)?

4. SECURITY BOUNDARY
   What exact security boundary was crossed?

5. EVIDENCE
   Is there sufficient evidence
   (request/response, identity diff, OOB, screenshot, etc.)?

6. ALTERNATIVE EXPLANATION
   Is there a credible alternative explanation
   that would make this NOT a security issue?

7. IMPACT
   Is the security impact actually demonstrated
   (not just "could be abused in theory")?
```

**Application rule:**

> LLM confidence is never proof.

Each question is a **state-based check**, not a model self-assessment. The candidate's answers must be backed by:

```
- recorded evidence artifacts
- explicit verification steps
- reproducible execution
- documented authorization context
```

A "no" or "unclear" answer to any of the seven is **a blocker** against promotion. The candidate may not skip the gate.

> See GAP-VM-01 below for items not yet specified by sources (which gate each question belongs to, and the literal phrasing if the final answer requires).

## 5. False Positive Gate

> Source: Buggy Master Blueprint §15 / §16 (canonical integration, not rewrite).

### 5.1 Concept

A suspicious behavior is **not automatically** a security issue.

The False Positive Gate exists to actively distinguish real vulnerabilities from:

- false positives
- rejected hypotheses
- alternative explanations
- misleading observations
- failed reproductions
- non-impactful behaviors

> Source: Buggy Master Blueprint §16 (canonical integration, not rewrite).

### 5.2 FP Knowledge as a First-Class Asset

> Source: Buggy Master Blueprint §16 (canonical integration, not rewrite).

Buggy must actively preserve and learn from false positives. They are not a waste product; they are training data for future prioritization and validation.

Where FP knowledge is stored:

```
- memory/FALSE_POSITIVE_DB.md        (system-level FP patterns)
- /memory/lessons/                   (individual FP cases with provenance)
- per-target artifacts under the canonical finding directory
  (per file-contracts.md §4.13 — revisions and new
  evidence live inside the same finding folder, not in a new
  top-level path)
```

> See GAP-VM-02 (the literal 10-question FP gate is an OPEN TODO; sources mentioned the count but did not provide the list).

## 6. Evidence Standard

> Source: Buggy Master Blueprint §18 (canonical integration, not rewrite).

### 6.1 Definition

Evidence is **concrete and reproducible**. It is the recorded proof that the runtime produced when the candidate was tested.

### 6.2 Acceptable Evidence Types

Concrete evidence types include:

```
- request/response pair
- authorization difference (between Account A and Account B performing the same action)
- identity comparison (cross-account verification)
- state transition (before/after a privileged action)
- browser observation (rendered behavior, devtools state, JS console output)
- OOB callback (with correlation ID and timestamp)
- repeatable reproduction (executed more than once with consistent result)
- asset (screenshot, video, HAR file)
```

### 6.3 Evidence Principles (Working Draft)

The items below are **source-derived evidence principles** drawn from Master Blueprint §18. They are **not** the final "10 Evidence Standard requirements" — those are tracked as **GAP-VM-03** in §14 and are intentionally not invented here.

Source-derived evidence principles (working draft):

```
- Evidence should be reproducible from the artifacts in the finding folder.
- Evidence should be correlatable with: solver / execution context,
  iteration, request, payload, callback.
- Evidence should not have explicit redaction that hides a critical detail
  (correlatable identifiers may be tokenized, not removed).
- Evidence should be stored inside the canonical per-target finding
  directory or its defined sub-artifacts.
```

> The final Evidence Standard (literal 10 requirements) will replace this section once GAP-VM-03 is resolved. Until then, treat the items above as **principles**, not as the final pass/fail check.

## 7. Proof Gate

> Source: Buggy Master Blueprint §17 (canonical integration, not rewrite).

### 7.1 Concept

The Proof Gate enforces one separation:

```
AI reasoning        ≠    Runtime proof
```

The AI may say: "this looks like an authorization bypass."

That does **not** mean the system may say: "confirmed."

Confirmation requires appropriate runtime evidence.

### 7.2 What the Proof Gate Decides

The Proof Gate decides **one** thing:

- whether the AI's hypothesis has a corresponding runtime execution / result
  (i.e. the hypothesis has been demonstrated in the runtime, not merely reasoned about)

### 7.3 What the Proof Gate Does NOT Decide

The Proof Gate does NOT decide:

- whether the resulting evidence is **sufficient** for validation / reporting (this is the Evidence Standard, §6)
- whether the finding is reportable (downstream, see §10)
- whether the bug is impactful (this is the Exploit Gate, §9)
- whether the FP gate passes (this is §5)

These are flagged as separate concerns within the sub-pipeline.

> See GAP-VM-04 (the implementation mechanism of the Proof Gate is an OPEN TODO; the principle is established, the wiring to runtime is not).

## 8. Validator Model

> Source: Buggy Master Blueprint §3.3 / §8.4 + Rules Producer §12 (canonical integration, not rewrite).

### 8.1 Role

The Validator is responsible for **independent validation where practical**.

The Validator's job is to **challenge the initial hypothesis** instead of merely confirming it.

### 8.2 Why Independence Matters

> Source: Buggy Master Blueprint §3.3 (canonical integration, not rewrite).

The hunter (and the model that produced the hypothesis) is not the appropriate evaluator for that same hypothesis. Confirmation by the same reasoning path that produced the suspicion is not validation; it is rationalization.

### 8.3 Independence Requirements

The Validator must be **operationally independent from the hypothesis-producing path where practical**. The specific mechanism of independence is flexible; concrete implementation details are deferred to `runtime/model-routing.md`, the validator skill, and the runtime contracts.

Possible independence mechanisms include, but are not limited to:

```
- different model identity
- different isolated execution context
- different reasoning prompt (one that asks "what would falsify this
  finding" rather than "is this finding valid")
- different reviewer (human or other agent)
- different evidence-set (e.g. a fresh replay rather than the original
  capture)
```

The exact choice, combination, and enforcement of these mechanisms is **deferred** to the runtime architecture. The architectural requirement here is only: the Validator must not be the same reasoning path that produced the hypothesis.

### 8.4 Output

The Validator produces a **validation report** that records:

```
- the hypothesis under test
- the test steps attempted
- whether the behavior was reproduced
- alternative explanations considered
- the verdict (confirmed / not-confirmed / needs-more-evidence)
- the evidence artifacts referenced
```

The exact schema is defined by `templates/validation-report.md` (when that template is authored; see GAP-VM-05).

## 9. Exploit Gate

> Source: Buggy Master Blueprint §13 + Sources Research Foundation (consensus across 12 source families).

### 9.1 Concept

Once the applicable validation checks have produced their required artifacts, the Exploit Gate assesses the maximum realistic impact.

The Exploit Gate is not a duplicate of the 7-question gate. It is an additional check that addresses a different failure mode: **reporting a finding without demonstrating exploitability**.

### 9.2 Chaining

Chaining is part of impact assessment:

```
- Can this finding chain with another observation to escalate?
  (e.g. Self-XSS + CSRF → stored XSS → ATO)
- Can the finding escalate privilege?
- Does the finding expose a route to a higher-severity outcome?
```

### 9.3 Decision

The Exploit Gate produces one of:

```
- DEMONSTRATED — exploit chain executed end-to-end with evidence
- THEORETICAL — plausible chain but not executed; document the unexecuted steps
- NONE — no exploitable chain beyond the direct impact
```

### 9.4 Relationship to Report

```
- DEMONSTRATED → write up with full chain in finding.md
- THEORETICAL  → write up; be explicit about what was not executed
- NONE         → write up the direct impact only; do not inflate
```

## 10. Reportability Assessment

> Source: Buggy Master Blueprint §3.3 / §15 (canonical integration, not rewrite).

After the Exploit Gate, the hunter performs the Reportability Assessment:

```
- is the impact real and reportable?
- does the report include the necessary evidence?
- is the reproduction clear enough for a triager to verify?
- is the title accurate (no marketing language, no inflated severity)?
```

The Reportability Assessment is the final human-side decision before the report is dispatched. AI assistance may help draft, but the final go/no-go is human.

> The internal structure of a report is defined by `templates/finding.md` and the report-writer skill. This contract defines only the gate that triggers the report, not the report itself.

## 11. Regression Handling

> Source: Buggy Master Blueprint §28 (canonical integration, not rewrite).

### 11.1 Scope of Regression

Regression applies to two distinct things:

```
- target behavior       — did the target change behavior after a fix?
- previously assessed findings — did a previously-fixed issue regress?
```

### 11.2 Preservation of Historical Evidence

A retest must NOT destroy historical evidence.

When regression is observed:

```
- the original reported state is preserved (per file-contracts.md §4.13)
- the new evidence is recorded as a new artifact inside the same finding directory
- the regression timeline is preserved
- the regression finding (if any) gets its own candidate.md and finding.md
```

### 11.3 Regression Bot (concept)

> Source: Sources Research Foundation.

A periodic check that:

```
- takes known fixes
- attempts to break them (using CVE + research + bypass knowledge)
- records outcomes as new evidence
- alerts if a known fix no longer holds
```

> The implementation of the Regression Bot is deferred (build order phase 10). The skill `regression` defines the methodology; the automation is a separate concern.

## 12. Coverage Map (the cross-cutting concern)

> Source: Buggy Master Blueprint §26 (canonical integration, not rewrite).

The Coverage Map tracks what has and has not been tested, at the dimensionality:

```
surface × function × identity × trust boundary × vulnerability class × tested/untested
```

The Coverage Map is an **external artifact**, not model memory. It is updated by the runtime as candidates move through the pipeline.

> See GAP-VM-06 (the literal schema and update procedure for the Coverage Map is an OPEN TODO).

The Coverage Map interacts with the validation pipeline as follows (working draft, NOT a hard completion algorithm):

```
- an untested function is a candidate for hypothesis
- a tested function with no result is an open work item
- a tested function with a confirmed finding is closed-via-finding
- a tested function with no finding is closed-no-finding
```

> **Note on completion:** the relationship between coverage state and target-level completion is **intentionally not enforced as a hard rule here**. Coverage state **may** contribute to target-level completion decisions once the completion policy is specified — this is tracked as **GAP-VM-06** in §14. Do not treat coverage state as a pass/fail completion gate until that gap is resolved.

## 13. Cross-References

### 13.1 Files That Read This Contract

- `architecture/agent-security.md` — depends on this contract.
- `architecture/learning-flow.md` — depends on this contract.
- `runtime/tool-manifest.md` — references §8 for Validator independence.
- `/AGENTS.md` (steering layer that points to this contract)
- `.opencode/skills/validator/SKILL.md` (implements the Validator model per this contract)
- `.opencode/skills/report-writer/SKILL.md` (consumes confirmed findings)
- `.opencode/skills/regression/SKILL.md` (uses §11 of this contract)
- `.opencode/skills/xss/SKILL.md` and `.opencode/skills/access-control/SKILL.md` (consume the gates)
- `templates/finding.md` (artifact for confirmed findings)
- `templates/hypothesis.md` (artifact for hypotheses)
- `templates/notes-funnel.md` (uses NOTES → LEADS → PRIMITIVES → FINDINGS → REPORTS per Master Blueprint §14)
- `templates/coverage-map.md` (artifact for §12 Coverage Map)

### 13.2 Files This Contract Reads

- `architecture/file-contracts.md` (file ownership, lifecycle, paths, per-type contracts)
- `architecture/agent-architecture-rules.md` (Agent / Skill / Command boundaries, Validator role)

### 13.3 Files This Contract Does NOT Cover (Linked Out)

- `architecture/agent-security.md` — prompt injection / tool poisoning / MCP trust (covered separately)
- `architecture/knowledge-flow.md` — how FP knowledge flows into /memory
- `architecture/learning-flow.md` — how findings/FPs become memory lessons
- `architecture/model-routing.md` + `runtime/model-routing.md` — which model runs the Validator
- `runtime/tool-manifest.md` — which tools are mandatory vs optional for validation steps

## 14. ⚠️ GAP NOTES

The following items are **OPEN TODOs** in the current architecture. They are intentionally not resolved here because the v6 source material did not provide enough specification to invent a contract without inventing architecture. Each gap is recorded with what is missing and where it should land when the missing specification becomes available.

### GAP-VM-01: 7-question gate — detailed failure-mode mapping

- **What's missing:** which of the 7 questions belong to which sub-gate (FP Gate vs Evidence Gate vs Proof Gate vs Exploit Gate), and the literal phrasing of each gate's questions.
- **Why it's a gap:** Master Blueprint §15 names the 7 questions, but does not specify which sub-gate each belongs to or the literal phrasing.
- **Where it should land:** this contract or `architecture/agent-architecture-rules.md`'s Validator skill, once the Gate-level question lists are finalized.
- **Status:** OPEN TODO — do not invent the gate mapping here.

### GAP-VM-02: Exact False Positive Gate questions (literal 10)

- **What's missing:** the literal list of 10 FP Gate questions.
- **Why it's a gap:** sources mentioned "10 FP questions" but did not provide the literal list.
- **Where it should land:** this contract (§5) once the questions are finalized by the hunter.
- **Status:** OPEN TODO — do not invent the 10 questions here.

### GAP-VM-03: Exact Evidence Standard requirements (literal 10)

- **What's missing:** the literal list of 10 Evidence Standard requirements.
- **Why it's a gap:** sources mentioned "10 evidence requirements" but did not provide the literal list.
- **Where it should land:** this contract (§6) once the requirements are finalized.
- **Status:** OPEN TODO — do not invent the 10 requirements here.

### GAP-VM-04: Proof Gate implementation

- **What's missing:** the runtime wiring that decides "confirmed". What capability runs it (Playwright? Burp? a target-specific script?), how the gate is enforced at runtime, what the boundary types are.
- **Why it's a gap:** the principle "AI ≠ proof, runtime = proof" is established; the implementation mechanism is not.
- **Where it should land:** `runtime/opencode/` plus this contract (§7) once specified.
- **Status:** OPEN TODO — do not invent an implementation here.

### GAP-VM-05: Validator output schema (validation-report.md template)

- **What's missing:** the exact fields of `validation-report.md` (which the validator skill produces).
- **Why it's a gap:** §8.4 specifies what the Validator records, but the exact schema is not given.
- **Where it should land:** `templates/validation-report.md` (new template) plus this contract.
- **Status:** OPEN TODO — sketch the schema only when validator skill production begins.

### GAP-VM-06: Coverage Map schema and update procedure

- **What's missing:** the literal schema for coverage state, the update procedure when a finding is confirmed, and the relationship between coverage state and target prioritization.
- **Why it's a gap:** the principle is established in §12; the schema is not.
- **Where it should land:** `templates/coverage-map.md` plus this contract (§12) once specified.
- **Status:** OPEN TODO — do not invent a schema here.

### GAP-VM-07: Regression Bot automation

- **What's missing:** the schedule, the bypass knowledge sources, and the alerting flow for the Regression Bot.
- **Why it's a gap:** §11 names the concept; the implementation is deferred to build order phase 10.
- **Where it should land:** `automation/` (deferred) plus `regression` skill.
- **Status:** OPEN TODO — defer per build order.

### GAP-VM-08: Gate sequencing / parallelism

- **What's missing:** whether gates must be strictly sequential (one passes before the next starts) or whether Evidence and FP can be tested in parallel.
- **Why it's a gap:** §3.2 shows a linear flow, but real hunting benefits from parallel checks.
- **Where it should land:** this contract (§3) or the validator skill once decided.
- **Status:** OPEN TODO — do not invent the sequence rule here.

### GAP-VM-09: Validator model identity

- **What's missing:** which model (or model class) is allowed to be the Validator, and how model routing for validation is configured.
- **Why it's a gap:** §8.3 requires model independence, but the operational model ID is left to runtime configuration.
- **Where it should land:** `runtime/model-routing.md` plus this contract.
- **Status:** OPEN TODO — do not invent a model policy here.

### GAP-VM-10: Severity model

- **What's missing:** the canonical severity model used to score a finding (e.g. CVSS, Bugcrowd VRT, HackerOne severity, custom). Severity is not the same as impact, but the Impact Gate feeds severity.
- **Why it's a gap:** sources emphasized "severity ≠ vulnerability type" but did not provide the severity model.
- **Where it should land:** this contract (new section) or a dedicated `architecture/severity-model.md`.
- **Status:** OPEN TODO — do not invent a severity model here.

---

These gaps are recorded so that future work does not silently invent contracts where the architecture has not yet been specified. Each gap names what is missing, why it is missing, where the contract belongs, and the rule that the answer must follow.